package com.vortexx.player.audio.dsp

import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.ln

/**
 * The combined magnitude response of the 10-band EQ, computed from the same
 * filter coefficients the audio thread uses. Neighbouring bands overlap, so
 * two +9 dB bands can lift a frequency by more than 9 dB; headroom based on
 * the single largest band would then still clip.
 */
object EqResponse {

    data class Peak(val gainDb: Double, val frequencyHz: Double)

    private const val LOW_HZ = 20.0
    private const val HIGH_HZ = 20_000.0
    private const val POINTS = 512

    /**
     * Highest gain of the whole EQ curve (preamp excluded) at [sampleRate],
     * on a 512-point log grid from 20 Hz up to 0.45 × sample rate plus every
     * band centre. Bands switched off at this rate are left out, as in the
     * audio path. Returns 0 dB at [LOW_HZ] when nothing boosts.
     */
    fun peak(bandGainsDb: List<Float>, sampleRate: Int = 48_000): Peak {
        val filters = ArrayList<BiquadCoefficients>(GraphicEqBands.COUNT)
        for (band in 0 until GraphicEqBands.COUNT) {
            val gain = bandGainsDb[band]
            if (gain == 0f || !GraphicEqBands.isUsable(band, sampleRate)) continue
            filters += BiquadCoefficients().apply {
                setPeaking(sampleRate, GraphicEqBands.CENTRES_HZ[band], GraphicEqBands.OCTAVE_Q, gain.toDouble())
            }
        }
        var best = Peak(0.0, LOW_HZ)
        if (filters.isEmpty()) return best
        val top = minOf(HIGH_HZ, GraphicEqBands.MAX_CENTRE_FRACTION * sampleRate)
        val step = (ln(top) - ln(LOW_HZ)) / (POINTS - 1)
        fun check(frequency: Double) {
            var sum = 0.0
            for (filter in filters) sum += filter.magnitudeDb(frequency, sampleRate)
            if (sum > best.gainDb) best = Peak(sum, frequency)
        }
        for (i in 0 until POINTS) check(exp(ln(LOW_HZ) + i * step))
        for (band in 0 until GraphicEqBands.COUNT) {
            if (GraphicEqBands.isUsable(band, sampleRate)) check(GraphicEqBands.CENTRES_HZ[band])
        }
        return best
    }

    /**
     * Preamp that keeps a full-scale signal at the EQ's loudest frequency
     * below 0 dBFS: minus the combined peak, rounded up to 0.1 dB and limited
     * to the preamp range. If the curve boosts more than 12 dB, −12 dB is not
     * enough and the clip counter will still report overs.
     */
    fun autoPreampDb(bandGainsDb: List<Float>, sampleRate: Int = 48_000): Float {
        val peak = peak(bandGainsDb, sampleRate).gainDb
        if (peak <= 0.0) return 0f
        val rounded = ceil(peak * 10.0 - 1e-9) / 10.0
        return (-rounded).toFloat().coerceAtLeast(-GraphicEqBands.MAX_PREAMP_DB)
    }
}
