# Stage A0 — Media3 1.11.1, PlaybackEngine and DSP proof

Package: `VortexX-A0r4.zip` · version 0.2.0-a0 (versionCode 2).

Status: **Written**. Nothing below is Compiled, Unit-tested or Device-tested until the CI run and the phone check are recorded in `docs/BUILD_STATUS.md`.

## What A0 contains

| Part | Where |
|---|---|
| Media3 standardised on 1.11.1 (latest stable, released 2026-09-10). None of the APIs removed since 1.6 are used. | `gradle/libs.versions.toml` |
| `PlaybackEngine`: builds the music ExoPlayer with the VORTEX X processor, applies DSP or battery-offload mode, reports the mode Media3 actually opened, measures latency | `audio/engine/PlaybackEngine.kt` |
| DSP core: preamp, 10 peaking filters (ISO octave centres 31.5 Hz–16 kHz, ±12 dB), click-free ramps and bypass, clip counter, stereo peak/RMS meters, load meter | `audio/dsp/` (plain Kotlin) |
| Media3 integration: `VortexAudioProcessor` inside `DefaultAudioSink` via `VortexRenderersFactory` | `audio/media3/` |
| Output diagnostics: decoder, input format, DSP format, output encoding/rate/channels/offload, buffer size, two measured delays, route (exact on Android 13+), route changes, underruns, offload support | `AudioDiagnostics`, `LatencyTracker` |
| Audio Lab A0 screen: status, meters, bypass, mode, preamp, 10 faders, signal path, device report | `feature/studio/StudioScreen.kt` |
| CI: build steps in the zip (`ci-build.sh`), DSP measurement table on the Summary page, signing key from a GitHub secret | `.github/scripts/`, `docs/phone-build/build-from-zip.yml` |
| UI fixes: Settings search scrolls with the list, header subtitles wrap, side cutouts in landscape, widths on tablets, OLED black | Settings, top bar, app root, theme |

## How the audio path is wired

Media3 decodes to PCM, `DefaultAudioSink` runs its processors, then writes to the output. `VortexAudioProcessor` is one of those processors. It accepts 16-bit and float PCM, 1–8 channels, any sample rate, and returns the same format. For anything else, or in battery mode, it reports itself inactive with a reason and audio passes untouched.

Media3 runs no processors for encoded passthrough (e.g. AC-3 to an HDMI receiver) or hardware offload. `PlaybackEngine.status` therefore comes from the output Media3 reports (`onAudioTrackInitialized`) plus the processor's own report, never from the setting alone:

| Output Media3 opened | Processor | Lab shows |
|---|---|---|
| PCM | active, DSP on | DSP · Active |
| PCM | active, DSP off | DSP · Bypassed |
| PCM | inactive | DSP · Not applied (with the processor's reason) or Off: battery mode |
| Offload | — | DSP · Bypassed: offload |
| Encoded (passthrough) | — | DSP · Bypassed: passthrough |
| Nothing open | — | DSP · Idle |

In battery mode the engine also hands the processor the settings with the DSP off, so a stream that is already playing as PCM fades to bypass within 20 ms (bit-exact afterwards) instead of staying processed until the next track; the Lab shows "Off: battery mode".

Dolby-encoded files (AC-3, E-AC-3, E-AC-3 JOC, AC-4) are not rejected: they play through whatever decoder or passthrough the phone offers, and the Lab shows that the DSP is not applied when the output is encoded. VORTEX X's processing is its own DSP and is never labelled Dolby or Atmos.

## Buffer size versus latency

The Signal path panel shows three separate rows:

| Row | What it is | Source |
|---|---|---|
| Output buffer size | Capacity of the AudioTrack buffer Media3 allocated, in ms. **Not a delay.** | `AudioTrackConfig.bufferSize` ÷ bytes per second |
| Change-to-ear delay | How far the processor's last finished sample is ahead of the playback position. An EQ change made now is heard after about this long. Median of the last 9 samples, taken every 0.5 s while the Lab is open and music plays. | Processor head (`StreamMetadata.positionOffsetUs` + frames processed) − `player.currentPosition`, ÷ speed |
| Output start latency | Time from the player starting to play to the first sample leaving the output, at the last play. | Media3 `onAudioPositionAdvancing` playout-start time − time `isPlaying` became true |

Samples outside 0–5000 ms (for example while a track changes) are discarded and counted as "Rejected latency samples". Until a value is measured the row says so; nothing is estimated.

## What CI measures (JVM tests, every build)

Each test prints `DSP-MEASURE|metric|value|limit|PASS/FAIL` before it asserts. The run's Summary page shows these as the **DSP measurements** table. They are measured on the CI machine from real sample buffers, not on a phone.

| Test | Claim it checks | Limit |
|---|---|---|
| `DspChainTest.everyBandHitsItsGainAtCentre_44_1_48_96kHz` | Every band at +6, −6 and +12 dB, at 44.1, 48 and 96 kHz: steady-state gain at the band centre | ±0.5 dB |
| `flatChainIsBitTransparent` | Flat EQ, 0 dB preamp leaves every sample identical | 0 changed |
| `bypassIsBitTransparentEvenWithEqSet` | Bypass leaves every sample identical | 0 changed |
| `stereoChannelsStayIndependentAndMonoWorks` | No leakage into a silent channel; mono at +6 dB | 0 leakage; 6 ± 0.5 dB |
| `formatChangeRetunesFilters` | 44.1 → 96 kHz switch keeps the 1 kHz band at +6 dB | 6 ± 0.5 dB |
| `bypassToggleIsClickFree` | Largest sample step across the bypass crossfade ÷ the music's own largest step | ≤ 1.05× |
| `gainAndPreampChangesAreRamped` | Sudden +12 dB / −6 dB requests: largest step ÷ final slope | ≤ 1.10× |
| `zeroAlgorithmicLatency` | Impulse response at sample 0 (no look-ahead) | > 0.5 |
| `clipCounterSeesOversAndHeadroomRemovesThem` | Overs counted on a hot signal; −6 dB preamp removes them | > 0; 0 |
| `metersReportPeakAndRmsPerChannel` | Peak and RMS per channel | ≤ 1 % error |
| `bandsNearNyquistAreSwitchedOff` | 16 kHz band off at 22.05 kHz; signal untouched | 0 changed |
| `loadMeterReportsShareOfRealTime` | Load arithmetic | exact |
| `processingPathDoesNotAllocate` | Heap allocated over 5 000 stereo buffers, including a parameter change | < 1024 bytes |
| `processingSpeedOnCiMachine` | CPU time for 48 kHz stereo with all 10 bands active, as % of real time (CI machine; the phone figure is the Lab's "DSP load") | < 25 % |
| `VortexAudioProcessorTest` (10) | Heap allocated over 5 000 buffers of mixed sizes after an equivalent warm-up (< 1024 bytes); 16-bit and float flat paths bit-exact; +6 dB boost reaches the expected 16-bit peak; 24-bit input and battery mode leave the processor inactive with a reason; 44.1 kHz stereo → 96 kHz mono switch; buffer-ms maths; processor head position exact (150 000 µs after 7 200 frames at 48 kHz); inactive processor reports no position | as listed |
| `DspStatusAndParametersTest` (5) | DSP never shown active for offload/passthrough; bypass, battery mode and unsupported formats reported separately; band storage round-trips | — |
| `EqResponseTest` (4) | Combined EQ curve: one +12 dB band peaks at 12 dB; 125 + 250 Hz at +9 dB peak above 9 dB; a 0.9 FS sine at that peak clips with −9 dB preamp and does not clip with Auto headroom; curves above 12 dB are limited to −12 dB | as listed |
| `LatencyTrackerTest` (7) | Start latency = playout − play; playouts after a seek are ignored; implausible values rejected; change-to-ear = head − position ÷ speed; median of recent samples; track-change samples rejected; new output restarts the window | — |

Before packaging, the DSP algorithm was also run as a line-by-line Python port against the same limits: band error 0.0 dB at all three rates, bypass and ramp transitions at 1.00× the steady-state slope, 2 991 clipped samples hot and 0 with headroom, 16-bit boost peak 13 075. That port is a cross-check, not CI evidence.

## Signing and app data

- No private key is in the repository or the zip. `app/build.gradle.kts` signs debug builds with the keystore named by the environment variable `VORTEX_DEBUG_KEYSTORE`, if it exists; otherwise with the machine's default debug key.
- The phone workflow's `create-signing-key` task generates the key on GitHub's runner and offers it once, as a private artifact kept for 1 day. Stored as the repository secret `VORTEX_DEBUG_KEYSTORE_B64`, it is decoded into the runner's temporary folder for each build and deleted after.
- The Summary page says **Signing: fixed key** or **Signing: temporary key**.
- From the first fixed-key build on, new APKs install over old ones and keep playlists, favourites, settings and Audio Lab values. The Phase 1 APK was signed with a temporary CI key, so it must be uninstalled once before the first fixed-key build; that one time, its data is lost.

## Working versus unfinished (A0 scope)

| In A0 (code written) | Not in A0 (later stages; not shown in the UI) |
|---|---|
| Preamp, 10-band graphic EQ, bypass, clip counter, stereo peak/RMS meters, DSP load | Parametric EQ, presets, compressor/limiter, crossfeed, loudness normalisation (A2) |
| DSP or battery-offload mode; offload/passthrough/format reported from Media3 | Per-route automatic profiles (A2) |
| Signal path: decoder, formats, output, buffer size, change-to-ear delay, output start latency, route, underruns, offload support | Spectrum analyser and frequency-response plot (A2) |
| Settings persist across restarts | Flagship Home control centre and full music player redesign (A1) |
| CI DSP measurement table | Video audio processing; video engine (A3) |

## Device checklist (Vortex's phone)

Record phone model and Android version first. Mark each ✅ or ❌ and write the number where asked.

| # | Check | Expected |
|---|---|---|
| 1 | Uninstall the Phase 1 build once, install the A0 APK | App opens, library loads |
| 2 | Play a song, open Home → Audio Lab | Status "DSP · Active"; meters move with the music |
| 3 | Drag 63 Hz to +9 dB | Bass clearly louder; fader readout +9.0 |
| 4 | Tap Flat | Sound returns to original |
| 5 | Switch DSP on ↔ Bypass ten times while playing | No clicks or pops |
| 6 | Several bands +12 dB on a loud song | Clip light turns red, "clipped" count rises |
| 7 | Tap "Auto headroom" (it accounts for neighbouring bands adding up) | Preamp goes negative; no new clips, unless the curve is above +12 dB |
| 8 | Read Signal path | Decoder, Input, DSP format, Output, Output buffer size, Route filled. Write down: buffer size ___ ms, change-to-ear ___ ms, output start ___ ms |
| 9 | Plug/unplug wired headphones or connect Bluetooth | Route updates; "Route changes" increases; no crash. Write down change-to-ear on Bluetooth ___ ms |
| 10 | Select Battery offload while a song plays | EQ stops within a moment, no click; status "Off: battery mode". After the next song: "Bypassed: offload" if Offload support says yes |
| 11 | Select DSP (PCM) again, skip to the next song | Status returns to Active |
| 12 | Lock the phone for 2 minutes while playing | Music continues; meters resume after unlock |
| 13 | 30 minutes playing, screen off, DSP on | Write down Underruns ___ |
| 14 | During playback | Write down DSP load: avg ___ %, worst ___ % |
| 15 | Close the app and reopen | EQ, preamp, bypass and mode are as you left them |
| 16 | After the next fixed-key build: install it over A0 | Installs without uninstalling; EQ settings still there |

## Known limitations of A0

- The Audio Lab processes the music player only; video playback is not processed.
- Battery mode bypasses the DSP at once, but hardware offload itself only starts when Media3 next opens the output (usually the next song); the Lab always shows the mode Media3 actually opened.
- The route is exact on Android 13+; before that it is the most likely output among those connected, marked "estimated".
- Output start latency comes from Media3's derived playout-start time, which Media3 documents as approximate.
- Change-to-ear delay is measured only while the Lab is open and the processor is in the path (DSP on or bypassed, PCM output).
- Battery impact, long-run underruns and processing load on the phone are device measurements still to be taken (checklist 13–14).
