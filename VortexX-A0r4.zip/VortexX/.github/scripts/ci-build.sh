#!/usr/bin/env bash
# VORTEX X CI build. Runs the Gradle steps, writes the job summary and fails if a
# required step failed. It lives inside the project, so the workflow file in the
# phone repository does not need editing when the build steps change.
#
# usage: ci-build.sh <project_dir> <logs_dir>
# env:   RUN_LINT=1      also run lintDebug (report only, never fails the run)
#        KEY_B64         the VORTEX_DEBUG_KEYSTORE_B64 secret (optional; decoded here)
#        SIGNING         fixed | temporary | invalid, if the workflow already decided it
#        GITHUB_OUTPUT   receives assemble=<outcome> for the APK upload step
set -uo pipefail

DIR="$(cd "${1:?project dir}" && pwd)"
LOGS="${2:?logs dir}"
mkdir -p "$LOGS"
LOGS="$(cd "$LOGS" && pwd)"
cd "$DIR"
chmod +x gradlew

# Debug signing key from the repository secret, when the workflow passes it as KEY_B64.
# It is written to a temporary folder outside the project and deleted when the script ends.
if [ -z "${SIGNING:-}" ]; then
  if [ -n "${KEY_B64:-}" ]; then
    KEYDIR="$(mktemp -d "${RUNNER_TEMP:-/tmp}/vxkey.XXXXXX")"
    trap 'rm -rf "$KEYDIR"' EXIT
    KEYFILE="$KEYDIR/vortex-debug.keystore"
    printf '%s' "$KEY_B64" | tr -d ' \r\n\t' | base64 -d > "$KEYFILE" 2>/dev/null || true
    if keytool -list -keystore "$KEYFILE" -storepass android -alias androiddebugkey > /dev/null 2>&1; then
      export VORTEX_DEBUG_KEYSTORE="$KEYFILE"
      SIGNING=fixed
    else
      rm -f "$KEYFILE"
      SIGNING=invalid
      echo "::warning::Secret VORTEX_DEBUG_KEYSTORE_B64 is not a valid keystore: this APK uses a temporary key."
    fi
  else
    SIGNING=temporary
    echo "::warning::Secret VORTEX_DEBUG_KEYSTORE_B64 is not set: this APK uses a temporary key."
  fi
fi
unset KEY_B64
export SIGNING

STEP=skipped
gradle_step() { # <title> <task> <log file>
  echo "::group::$1"
  ./gradlew --stacktrace "$2" 2>&1 | tee "$LOGS/$3"
  local rc=${PIPESTATUS[0]}
  echo "::endgroup::"
  if [ "$rc" -eq 0 ]; then STEP=success; else STEP=failure; echo "::warning::$1 failed (exit $rc)"; fi
}

ASSEMBLE=skipped UNIT=skipped ANDROIDTEST=skipped LINT=skipped
gradle_step "Build debug APK" assembleDebug 1-assembleDebug.log
ASSEMBLE=$STEP
if [ "$ASSEMBLE" = success ]; then
  gradle_step "JVM unit tests" testDebugUnitTest 2-testDebugUnitTest.log
  UNIT=$STEP
  gradle_step "Compile instrumentation tests" assembleDebugAndroidTest 3-assembleDebugAndroidTest.log
  ANDROIDTEST=$STEP
  if [ "${RUN_LINT:-0}" = 1 ]; then
    gradle_step "Lint (report only)" lintDebug 4-lintDebug.log
    LINT=$STEP
  fi
fi

if [ -n "${GITHUB_OUTPUT:-}" ]; then
  echo "assemble=$ASSEMBLE" >> "$GITHUB_OUTPUT"
fi

ASSEMBLE=$ASSEMBLE UNIT=$UNIT ANDROIDTEST=$ANDROIDTEST LINT=$LINT \
  bash "$DIR/.github/scripts/ci-summary.sh" "$DIR" "$LOGS"

echo "assembleDebug=$ASSEMBLE testDebugUnitTest=$UNIT assembleDebugAndroidTest=$ANDROIDTEST lintDebug=$LINT"
if [ "$ASSEMBLE" != success ] || [ "$UNIT" != success ] || [ "$ANDROIDTEST" != success ]; then
  echo "::error::Build or tests failed. Open the run's Summary for the Errors box."
  exit 1
fi
