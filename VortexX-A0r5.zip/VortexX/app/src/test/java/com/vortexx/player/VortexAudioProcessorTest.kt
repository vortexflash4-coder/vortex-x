package com.vortexx.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import com.vortexx.player.audio.dsp.DspHost
import com.vortexx.player.audio.dsp.DspParameters
import com.vortexx.player.audio.dsp.LoadMeter
import com.vortexx.player.audio.dsp.MeterBus
import com.vortexx.player.audio.dsp.ProcessorFormat
import com.vortexx.player.audio.media3.AudioEncodings
import com.vortexx.player.audio.media3.VortexAudioProcessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

/** The Media3 processor around the DSP chain: formats, activation rules and the PCM conversion. */
@Suppress("DEPRECATION") // AudioProcessor.flush() is deprecated in Media3 1.11 in favour of flush(StreamMetadata).
class VortexAudioProcessorTest {

    private class FakeHost(
        override var parameters: DspParameters = DspParameters(),
        override var processingAllowed: Boolean = true,
    ) : DspHost {
        override val meters = MeterBus()
        override val load = LoadMeter()
        var lastFormat: ProcessorFormat? = null
        var lastReason: String? = null
        var lastPositionUs: Long = DspHost.UNKNOWN_POSITION_US
        override fun onProcessorConfigured(format: ProcessorFormat?, reason: String?) {
            lastFormat = format
            lastReason = reason
        }
        override fun onProcessedPosition(positionUs: Long) {
            lastPositionUs = positionUs
        }
    }

    private fun pcm16(frames: Int, channels: Int, sampleRate: Int, freq: Double, amplitude: Double): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(frames * channels * 2).order(ByteOrder.nativeOrder())
        for (i in 0 until frames) {
            val v = (amplitude * 32767 * sin(2 * PI * freq * i / sampleRate)).toInt().toShort()
            for (c in 0 until channels) buffer.putShort(v)
        }
        buffer.flip()
        return buffer
    }

    private fun drain(processor: VortexAudioProcessor): ByteBuffer {
        val out = processor.getOutput()
        val copy = ByteBuffer.allocate(out.remaining()).order(ByteOrder.nativeOrder())
        copy.put(out)
        copy.flip()
        return copy
    }

    private fun start(processor: VortexAudioProcessor, sampleRate: Int, channels: Int, encoding: Int): AudioProcessor.AudioFormat {
        val result = processor.configure(AudioProcessor.AudioFormat(sampleRate, channels, encoding))
        processor.flush()
        return result
    }

    @Test
    fun flat16BitStereoIsBitExact() {
        val host = FakeHost()
        val processor = VortexAudioProcessor(host)
        start(processor, 48_000, 2, C.ENCODING_PCM_16BIT)
        assertTrue(processor.isActive)
        val input = pcm16(2048, 2, 48_000, 997.0, 0.8)
        val reference = input.duplicate().order(ByteOrder.nativeOrder())
        processor.queueInput(input)
        val output = drain(processor)
        assertEquals(reference.remaining(), output.remaining())
        var changed = 0
        val total = reference.remaining() / 2
        val ref = reference.duplicate().order(ByteOrder.nativeOrder())
        val out = output.duplicate().order(ByteOrder.nativeOrder())
        while (ref.hasRemaining()) if (ref.getShort() != out.getShort()) changed++
        DspMeasure.record("Media3 processor, 16-bit PCM, flat: changed samples", "$changed of $total", "0", changed == 0)
        while (reference.hasRemaining()) assertEquals(reference.getShort(), output.getShort())
        assertEquals(ProcessorFormat(48_000, 2, "PCM 16-bit"), host.lastFormat)
    }

    @Test
    fun floatPcmPassesThroughFlatExactly() {
        val processor = VortexAudioProcessor(FakeHost())
        start(processor, 96_000, 1, C.ENCODING_PCM_FLOAT)
        val input = ByteBuffer.allocateDirect(1024 * 4).order(ByteOrder.nativeOrder())
        for (i in 0 until 1024) input.putFloat((0.5 * sin(2 * PI * 440.0 * i / 96_000)).toFloat())
        input.flip()
        val reference = input.duplicate().order(ByteOrder.nativeOrder())
        processor.queueInput(input)
        val output = drain(processor)
        while (reference.hasRemaining()) assertEquals(reference.getFloat(), output.getFloat(), 0f)
    }

    @Test
    fun eqBoostChangesThe16BitOutput() {
        val host = FakeHost(parameters = DspParameters().withBand(5, 6f))
        val processor = VortexAudioProcessor(host)
        start(processor, 44_100, 2, C.ENCODING_PCM_16BIT)
        val input = pcm16(44_100, 2, 44_100, 1000.0, 0.2)
        processor.queueInput(input)
        val output = drain(processor)
        var peak = 0
        while (output.hasRemaining()) peak = maxOf(peak, kotlin.math.abs(output.getShort().toInt()))
        // 0.2 full scale boosted by +6 dB is about 0.4 full scale (13 100 of 32 767).
        DspMeasure.record("Media3 processor, 16-bit: 0.2 FS 1 kHz sine with +6 dB band, output peak", "$peak", "12000–14500 (≈ 13075)", peak in 12_000..14_500)
        assertTrue("peak $peak", peak in 12_000..14_500)
    }

    @Test
    fun unsupportedEncodingLeavesProcessorInactiveWithReason() {
        val host = FakeHost()
        val processor = VortexAudioProcessor(host)
        val result = start(processor, 48_000, 2, C.ENCODING_PCM_24BIT)
        assertEquals(AudioProcessor.AudioFormat.NOT_SET, result)
        assertFalse(processor.isActive)
        assertNull(host.lastFormat)
        assertTrue(host.lastReason!!.contains("16-bit or float"))
    }

    @Test
    fun batteryModeLeavesProcessorInactive() {
        val host = FakeHost(processingAllowed = false)
        val processor = VortexAudioProcessor(host)
        start(processor, 48_000, 2, C.ENCODING_PCM_16BIT)
        assertFalse(processor.isActive)
        assertTrue(host.lastReason!!.contains("Battery mode"))
    }

    @Test
    fun formatChangeFrom44kStereoTo96kMonoKeepsWorking() {
        val host = FakeHost(parameters = DspParameters().withBand(5, 3f))
        val processor = VortexAudioProcessor(host)
        start(processor, 44_100, 2, C.ENCODING_PCM_16BIT)
        processor.queueInput(pcm16(1024, 2, 44_100, 1000.0, 0.1))
        assertEquals(1024 * 2 * 2, drain(processor).remaining())

        start(processor, 96_000, 1, C.ENCODING_PCM_16BIT)
        assertTrue(processor.isActive)
        processor.queueInput(pcm16(1024, 1, 96_000, 1000.0, 0.1))
        assertEquals(1024 * 2, drain(processor).remaining())
        assertNotNull(host.lastFormat)
        assertEquals(96_000, host.lastFormat!!.sampleRate)
        assertEquals(1, host.lastFormat!!.channelCount)
    }

    @Test
    fun outputBufferMillisecondsFromTrackConfig() {
        // 48 kHz stereo 16-bit: 192 000 bytes per second, so 96 000 bytes = 500 ms.
        assertEquals(500, AudioEncodings.bufferMillis(C.ENCODING_PCM_16BIT, 96_000, 48_000, 2))
        assertNull(AudioEncodings.bufferMillis(C.ENCODING_E_AC3, 96_000, 48_000, 6))
        assertTrue(AudioEncodings.isLinearPcm(C.ENCODING_PCM_FLOAT))
        assertFalse(AudioEncodings.isLinearPcm(C.ENCODING_AC3))
    }

    @Test
    fun processedPositionFollowsTheFramesActuallyProcessed() {
        // The change-to-ear readout compares this position with the player's position,
        // so it must count exactly the frames that left the processor.
        val host = FakeHost()
        val processor = VortexAudioProcessor(host)
        start(processor, 48_000, 2, C.ENCODING_PCM_16BIT)
        assertEquals(0L, host.lastPositionUs) // flush() = StreamMetadata.DEFAULT, offset 0
        processor.queueInput(pcm16(4_800, 2, 48_000, 440.0, 0.1))
        drain(processor)
        assertEquals(100_000L, host.lastPositionUs) // 4 800 frames at 48 kHz = 100 ms
        processor.queueInput(pcm16(2_400, 2, 48_000, 440.0, 0.1))
        drain(processor)
        val position = host.lastPositionUs
        DspMeasure.record("Processor head after 4800 + 2400 frames at 48 kHz", "$position µs", "150000 µs", position == 150_000L)
        assertEquals(150_000L, position)
        processor.flush()
        assertEquals(0L, host.lastPositionUs)
    }

    @Test
    fun inactiveProcessorReportsNoPosition() {
        val host = FakeHost()
        val processor = VortexAudioProcessor(host)
        start(processor, 48_000, 2, C.ENCODING_PCM_16BIT)
        processor.queueInput(pcm16(4_800, 2, 48_000, 440.0, 0.1))
        drain(processor)
        start(processor, 48_000, 2, C.ENCODING_PCM_24BIT)
        assertEquals(DspHost.UNKNOWN_POSITION_US, host.lastPositionUs)
    }

    @Test
    fun processingPathDoesNotAllocateAfterWarmUp() {
        // Same sizes and transitions in warm-up as in the measured loop, so only steady-state allocations count.
        val counter = AllocationCounter.create()
        org.junit.Assume.assumeTrue("allocation counter not available on this JVM", counter != null)
        counter!!
        val host = FakeHost()
        val processor = VortexAudioProcessor(host)
        start(processor, 48_000, 2, C.ENCODING_PCM_16BIT)
        val small = pcm16(512, 2, 48_000, 440.0, 0.3)
        val large = pcm16(4_096, 2, 48_000, 440.0, 0.3)
        val boosted = DspParameters().withBand(5, 6f).withPreamp(-6f)
        fun pass(i: Int) {
            host.parameters = if (i % 1000 == 500) boosted else host.parameters
            val input = if (i % 2 == 0) small else large
            input.rewind()
            processor.queueInput(input)
            processor.getOutput()
        }
        repeat(5_000) { pass(it) }
        val overhead = counter.overheadBytes()
        // Three measured rounds. A per-buffer allocation (16 bytes or more) shows up as at least
        // 80 000 bytes in every round; a one-off allocation by the JVM itself (JIT, class loading)
        // shows up in one round only. The gate is the lowest round; all three are reported.
        val rounds = LongArray(3)
        for (r in rounds.indices) {
            val before = counter.bytes()
            repeat(5_000) { pass(it) }
            rounds[r] = (counter.bytes() - before - overhead).coerceAtLeast(0)
        }
        val lowest = rounds.min()
        DspMeasure.record(
            "Media3 processor (16-bit, 512/4096-frame buffers): heap per 5000 buffers after warm-up, 3 rounds",
            "${rounds.joinToString(" / ")} bytes (lowest $lowest)",
            "lowest < 1024 bytes",
            lowest < 1024,
        )
        assertTrue("allocated ${rounds.joinToString()} bytes", lowest < 1024)
    }
}

