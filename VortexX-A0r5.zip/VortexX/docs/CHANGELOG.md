# Changelog

## 0.2.0-a0 revision 2 — 2026-11-11 — final A0 order

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Added
- `audio/engine/PlaybackEngine`: builds the music ExoPlayer (renderers with the VORTEX X processor, attributes, analytics), applies DSP or battery-offload mode, exposes `status` decided from Media3's opened output, and `latency`.
- `audio/engine/LatencyTracker`: change-to-ear delay (processor head − playback position ÷ speed, median of 9) and output start latency (Media3 playout start − play start), with 0–5000 ms plausibility and a rejected count.
- `VortexAudioProcessor` overrides `onFlush(StreamMetadata)` (Media3 1.11) and reports the stream position of the last processed sample.
- DSP measurement lines in the JVM tests and a **DSP measurements** table on the CI Summary page. New tests: `LatencyTrackerTest` (7), `processingSpeedOnCiMachine`, two processor position tests.
- `.github/scripts/ci-build.sh`: Gradle steps run from the zip, so the phone workflow file rarely needs editing.
- `create-signing-key` task in `docs/phone-build/build-from-zip.yml`, and `.github/workflows/create-debug-key.yml` for Route B.
- Package A0r5: first CI run (build #3, A0r4) compiled the app and both test sources; 67 of 68 unit tests passed. The processor allocation test measured exactly 1024 bytes once over 5000 buffers; it now measures three rounds and gates on the lowest, reporting all three. Phone signing moved to a key kept in the Actions cache (no manual secret).
- Package A0r4: three issues found by the draft review in PR #1, fixed here: battery mode now bypasses a stream that is already playing as PCM (20 ms fade, status "Off: battery mode"); Auto headroom uses the combined EQ curve (`EqResponse`), because neighbouring boosts add up; EQ faders are at least 56 dp wide and scroll sideways. The processor also works in bounded 1024-frame chunks with a buffer allocated once, clamps float output to full scale, and has its own allocation test.
- Package A0r3: the phone workflow is shortened to one job (it can be opened as a pre-filled GitHub "new file" link), and `ci-build.sh` decodes the signing secret itself (temporary folder, deleted on exit).

### Changed
- Signing: the committed `app/vortex-debug.keystore` is removed. Debug builds are signed with the key from the secret `VORTEX_DEBUG_KEYSTORE_B64`, decoded to the runner's temporary folder and deleted after the build. The Summary says whether the key was fixed or temporary.
- Audio Lab: "Output buffer" is now "Output buffer size … capacity (not latency)", followed by the two measured delays.
- `PlaybackService` uses `PlaybackEngine` instead of building the player itself.
- Media3 is standardised on 1.11.1 in the version catalog and every doc.

## 0.2.0-a0 — 2026-11-11 — Stage A0: Media3 1.11.1 and DSP proof

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Added
- `audio/dsp/`: `DspChain` (preamp, 10 peaking filters at ISO octave centres, gain ramps of 0.25 dB per 32 frames, 20 ms bypass crossfade, clip counter), `BiquadCoefficients` (RBJ cookbook), `DspParameters`, lock-free `MeterBus` and `LoadMeter`, `DspHost`.
- `audio/media3/`: `VortexAudioProcessor` (16-bit and float PCM, 1–8 channels), `VortexRenderersFactory` (adds it to `DefaultAudioSink`), `AudioEncodings`.
- `audio/engine/`: `AudioEngine` (settings, persistence, DSP/battery mode), `AudioDiagnostics` (Media3 analytics + audio-device callback), `DspStatusResolver`.
- Audio Lab A0 screen (replaces the Audio Studio report): status, stereo peak/RMS meters with clip light, bypass, output mode, preamp, 10 faders, signal path, device report.
- Instrument controls: `EqFader`, `PrecisionSlider`, `StereoLevelMeter`, `SegmentedSelector`, `StatusLed`, `ReadoutGrid`.
- (Replaced in revision 2) a committed debug keystore and its signing config.
- JVM tests: `DspChainTest` (13), `VortexAudioProcessorTest` (7), `DspStatusAndParametersTest` (5).
- `docs/STAGE_A0.md`.

### Changed
- Media3 upgraded to 1.11.1.
- `PlaybackService` builds the player with `VortexRenderersFactory`, attaches the diagnostics listener, tracks routes and applies the offload preference.
- Settings: the search field is the list's first item; the top bar shows "Detail level: …" and the level's description sits under the level chips; "Reset to defaults" no longer clears Audio Lab values.
- Top bar subtitles wrap to two lines. Navigation keeps clear of side display cutouts. List screens are width-capped and centred on tablets.
- Theme: true black background (#000000) and darker surfaces.
- Version 0.1.0-phase1 → 0.2.0-a0 (versionCode 2).

## 2026-11-11 — Phase 1 review pass

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Changed
- `.github/workflows/android-ci.yml`: every Gradle step now writes its full log to `ci-logs/`. The run always ends with a job summary and a logs artifact, even when the build fails. The run is still marked failed when `assembleDebug`, `testDebugUnitTest` or `assembleDebugAndroidTest` fails. Unit tests and the instrumentation-test compile run only after the APK builds, so the Errors box shows the first real failure.
- Artifacts: `vortex-x-debug-apk` (unchanged). `vortex-x-logs-and-reports` replaces `vortex-x-reports` and now also contains the Gradle logs.
- `feature/music/CollectionScreen.kt`: `SongActionsHost` is called directly instead of inside an empty `Box` (no behaviour change; removed unused import).
- `README.md`: phone-only build instructions now cover the zip-upload route.

### Added
- `.github/scripts/ci-summary.sh`: job summary with "APK built" (name + size) or "APK was not built", unit-test counts with failed test names, and an Errors box trimmed to `file:line`. Up to 10 errors also appear as annotations on the run page.
- `docs/phone-build/build-from-zip.yml`: workflow for a repository that contains only the project ZIP. Uploading the ZIP from a phone browser builds the APK with the same checks and summary.
- `docs/BUILD_STATUS.md`, `docs/CHANGELOG.md`.

### Static review result
No definite compile error found in the 57 Kotlin files, the manifest or the resources. This does not prove the project compiles; the first CI run decides.
