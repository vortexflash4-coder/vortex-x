pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VortexX"
include(":app")

// Optional FFmpeg decoder pack. .github/scripts/ci-ffmpeg.sh fetches the Media3 module sources,
// builds or restores FFmpeg and writes ffmpeg/READY; without it the app builds without the pack.
if (java.io.File(rootDir, "ffmpeg/READY").exists()) {
    include(":ffmpeg")
}
