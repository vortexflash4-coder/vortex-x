package com.vortexx.player

import com.vortexx.player.audio.engine.DecoderPack
import com.vortexx.player.feature.diagnostics.decoderPackLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The decoder-pack report must never claim a decoder that did not load. */
class DecoderPackTest {

    @Test
    fun onTheJvmThePackNeverReportsLoadedFormats() {
        // No Android native libraries here: whether or not the classes are on the classpath,
        // nothing may be reported as decodable by the pack.
        val status = DecoderPack.status()
        assertFalse(status.loaded)
        assertEquals(DecoderPack.Formats.size, status.formats.size)
        assertTrue(status.formats.none { it.pack })
    }

    @Test
    fun formatListHasTheCinemaCodecsAndUniqueMimeTypes() {
        val mimes = DecoderPack.Formats.map { it.mimeType }
        assertEquals(mimes.size, mimes.toSet().size)
        assertTrue(mimes.containsAll(listOf("audio/ac3", "audio/eac3", "audio/vnd.dts", "audio/true-hd", "audio/alac")))
    }

    @Test
    fun statusLineSaysExactlyWhatHappened() {
        val none = DecoderPack.Status(included = false, loaded = false, version = null, formats = emptyList())
        val notLoaded = none.copy(included = true)
        val active = notLoaded.copy(loaded = true, version = "6.0")
        assertEquals("Not included in this build", decoderPackLine(none))
        assertEquals("Included, but its native library did not load on this phone", decoderPackLine(notLoaded))
        assertEquals("Active · FFmpeg 6.0", decoderPackLine(active))
    }
}
