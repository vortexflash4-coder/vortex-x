package com.vortexx.player.feature.home

import androidx.compose.ui.graphics.graphicsLayer
import com.vortexx.player.ui.navigation.ShortsRoute
import com.vortexx.player.ui.designsystem.components.VideoThumbnail
import com.vortexx.player.ui.designsystem.motion.reveal
import com.vortexx.player.ui.designsystem.motion.rememberRevealState
import com.vortexx.player.ui.designsystem.motion.rememberHeroZoom
import com.vortexx.player.ui.designsystem.motion.pressClickable
import com.vortexx.player.ui.designsystem.motion.AmbientGlow
import com.vortexx.player.feature.shorts.shortsFrom
import com.vortexx.player.feature.shorts.ShortsLaunch
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vortexx.player.audio.engine.AudioDiagnostics
import com.vortexx.player.audio.engine.AudioFormatLabels
import com.vortexx.player.audio.engine.AudioPathState
import com.vortexx.player.audio.engine.DspStatus
import com.vortexx.player.audio.engine.PlaybackEngine
import com.vortexx.player.core.util.Format
import com.vortexx.player.data.library.MediaLibraryRepository
import com.vortexx.player.data.repo.WatchHistoryRepository
import com.vortexx.player.domain.library.LibraryLogic
import com.vortexx.player.domain.model.LibraryState
import com.vortexx.player.domain.model.Song
import com.vortexx.player.domain.model.SongCollection
import com.vortexx.player.domain.model.Video
import com.vortexx.player.domain.model.dataOrNull
import com.vortexx.player.domain.playback.ResumePolicy
import com.vortexx.player.feature.nowplaying.CoverArt
import com.vortexx.player.feature.nowplaying.SignalChips
import com.vortexx.player.feature.nowplaying.routeLine
import com.vortexx.player.feature.video.VideoCard
import com.vortexx.player.feature.video.VideoItemUi
import com.vortexx.player.playback.NowPlaying
import com.vortexx.player.playback.PlaybackConnection
import com.vortexx.player.playback.PlaybackUiState
import com.vortexx.player.playback.PositionSnapshot
import com.vortexx.player.ui.designsystem.components.BrandHeader
import com.vortexx.player.ui.designsystem.components.HeaderIconButton
import com.vortexx.player.ui.designsystem.components.InlineNotice
import com.vortexx.player.ui.designsystem.components.MetaChip
import com.vortexx.player.ui.designsystem.components.PlayCircleButton
import com.vortexx.player.ui.designsystem.components.PrimaryButton
import com.vortexx.player.ui.designsystem.components.ProgressLine
import com.vortexx.player.ui.designsystem.components.ScreenMargin
import com.vortexx.player.ui.designsystem.components.SecondaryButton
import com.vortexx.player.ui.designsystem.components.SectionTitle
import com.vortexx.player.ui.designsystem.components.ShelfCard
import com.vortexx.player.ui.designsystem.components.SongCover
import com.vortexx.player.ui.designsystem.instrument.InstrumentText
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing
import com.vortexx.player.ui.navigation.CollectionRoute
import com.vortexx.player.ui.navigation.MusicRoute
import com.vortexx.player.ui.navigation.SettingsRoute
import com.vortexx.player.ui.navigation.StudioRoute
import com.vortexx.player.ui.navigation.VideosRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import java.time.LocalTime
import javax.inject.Inject

data class HomeUiState(
    val loading: Boolean = true,
    val songCount: Int = 0,
    val videoCount: Int = 0,
    val musicDurationMs: Long = 0L,
    val allSongs: List<Song> = emptyList(),
    val recentlyAdded: List<Song> = emptyList(),
    /** Albums ordered by their newest file; the first one is the featured album. */
    val newestAlbums: List<SongCollection> = emptyList(),
    val continueWatching: List<VideoItemUi> = emptyList(),
    /** Newest short videos (up to three minutes) for the Shorts shelf. */
    val shorts: List<Video> = emptyList(),
    val libraryError: String? = null,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val library: MediaLibraryRepository,
    watchHistory: WatchHistoryRepository,
    private val playback: PlaybackConnection,
    playbackEngine: PlaybackEngine,
    diagnostics: AudioDiagnostics,
    private val shortsLaunch: ShortsLaunch,
) : ViewModel() {

    val playbackState: StateFlow<PlaybackUiState> = playback.state
    val position: Flow<PositionSnapshot> = playback.positionUpdates(intervalMs = 500L)
    val status: StateFlow<DspStatus> = playbackEngine.status
    val path: StateFlow<AudioPathState> = diagnostics.state

    fun togglePlayPause() = playback.togglePlayPause()
    fun next() = playback.next()
    fun rescan() = library.refresh()

    val uiState: StateFlow<HomeUiState> = combine(library.songs, library.videos, watchHistory.all) { songs, videos, history ->
        val songList = songs.dataOrNull().orEmpty()
        val videoList = videos.dataOrNull().orEmpty()
        val videosById = videoList.associateBy { it.id }
        val continueWatching = history.mapNotNull { entry ->
            val video = videosById[entry.videoId] ?: return@mapNotNull null
            val fraction = ResumePolicy.continueWatchingFraction(entry.positionMs, video.durationMs) ?: return@mapNotNull null
            VideoItemUi(video, fraction)
        }.take(10)
        HomeUiState(
            loading = songs is LibraryState.Loading && videos is LibraryState.Loading,
            songCount = songList.size,
            videoCount = videoList.size,
            musicDurationMs = songList.sumOf { it.durationMs },
            allSongs = songList,
            recentlyAdded = songList.sortedByDescending { it.dateAddedSec }.take(12),
            newestAlbums = LibraryLogic.albums(songList)
                .sortedByDescending { album -> album.songs.maxOf { it.dateAddedSec } }
                .take(12),
            continueWatching = continueWatching,
            shorts = shortsFrom(videoList).take(12),
            libraryError = (songs as? LibraryState.Failed)?.message ?: (videos as? LibraryState.Failed)?.message,
        )
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), HomeUiState())

    fun shuffleAll() = playback.shuffleAll(uiState.value.allSongs)

    fun playRecent(index: Int) = playback.playSongs(uiState.value.recentlyAdded, index)

    fun playAlbum(album: SongCollection) = playback.playSongs(album.songs, 0)

    /** Shorts opens at this video. */
    fun openShort(videoId: Long) = shortsLaunch.request(videoId)
}

/** Greeting from the phone's clock. */
internal fun greetingFor(hour: Int): String = when (hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Late night"
}

@Composable
fun HomeScreen(
    onNavigate: (Any) -> Unit,
    onPlayVideo: (Video) -> Unit,
    onOpenNowPlaying: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val playback by viewModel.playbackState.collectAsStateWithLifecycle()
    val position by viewModel.position.collectAsStateWithLifecycle(initialValue = PositionSnapshot())
    val status by viewModel.status.collectAsStateWithLifecycle()
    val path by viewModel.path.collectAsStateWithLifecycle()
    val greeting = remember { greetingFor(LocalTime.now().hour) }
    val revealState = rememberRevealState()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val shelfCard = if (maxWidth >= 600.dp) 168.dp else 140.dp
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = VortexSpacing.xxl),
        ) {
            item(key = "header") {
                Box {
                    AmbientGlow(Modifier.matchParentSize())
                    BrandHeader(
                        title = greeting,
                        subtitle = librarySubtitle(state),
                        modifier = Modifier.reveal(revealState, "header"),
                    ) {
                        HeaderIconButton(Icons.Rounded.Settings, "Settings", onClick = { onNavigate(SettingsRoute) })
                    }
                }
            }

            val error = state.libraryError
            if (error != null) {
                item(key = "error") {
                    InlineNotice(
                        text = "Library could not be read: $error",
                        modifier = Modifier.padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm),
                    )
                }
            }

            val nowPlaying = playback.nowPlaying
            val featured = state.newestAlbums.firstOrNull()
            if (nowPlaying != null) {
                item(key = "deck") {
                    NowPlayingDeck(
                        nowPlaying = nowPlaying,
                        isPlaying = playback.isPlaying,
                        position = position,
                        durationMs = playback.durationMs,
                        status = status,
                        formatLine = AudioFormatLabels.describe(path.input),
                        routeLine = routeLine(path.route),
                        onOpen = onOpenNowPlaying,
                        onTogglePlay = viewModel::togglePlayPause,
                        onNext = viewModel::next,
                        onOpenAudioLab = { onNavigate(StudioRoute) },
                        modifier = Modifier
                            .reveal(revealState, "deck", order = 1)
                            .padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm),
                    )
                }
            } else if (featured != null) {
                item(key = "featured") {
                    FeaturedAlbum(
                        album = featured,
                        onPlay = {
                            viewModel.playAlbum(featured)
                            onOpenNowPlaying()
                        },
                        onShuffleAll = {
                            viewModel.shuffleAll()
                            onOpenNowPlaying()
                        },
                        onOpen = { onNavigate(CollectionRoute(featured.type.name, featured.key, featured.title)) },
                        modifier = Modifier
                            .reveal(revealState, "featured", order = 1)
                            .padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm),
                    )
                }
            } else if (!state.loading && state.songCount == 0 && state.videoCount == 0 && error == null) {
                item(key = "empty") {
                    EmptyLibraryCard(
                        onRescan = viewModel::rescan,
                        modifier = Modifier.padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm),
                    )
                }
            }

            if (state.songCount > 0) {
                item(key = "quick") {
                    Row(
                        Modifier
                            .reveal(revealState, "quick", order = 2)
                            .padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm),
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.sm),
                    ) {
                        PrimaryButton(
                            text = "Shuffle all",
                            onClick = {
                                viewModel.shuffleAll()
                                onOpenNowPlaying()
                            },
                            icon = Icons.Rounded.Shuffle,
                            modifier = Modifier.weight(1f),
                        )
                        SecondaryButton(
                            text = "Audio Lab",
                            onClick = { onNavigate(StudioRoute) },
                            icon = Icons.Rounded.Equalizer,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            if (state.shorts.isNotEmpty()) {
                item(key = "shorts-title") {
                    SectionTitle(
                        "Shorts",
                        actionLabel = "Watch",
                        onAction = { onNavigate(ShortsRoute) },
                        modifier = Modifier.reveal(revealState, "shorts-title", order = 3),
                    )
                }
                item(key = "shorts-row") {
                    LazyRow(
                        modifier = Modifier.reveal(revealState, "shorts-row", order = 3),
                        contentPadding = PaddingValues(horizontal = ScreenMargin),
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.md),
                    ) {
                        items(state.shorts, key = { it.id }) { video ->
                            ShortCard(
                                video = video,
                                onClick = {
                                    viewModel.openShort(video.id)
                                    onNavigate(ShortsRoute)
                                },
                                modifier = Modifier.width(128.dp),
                            )
                        }
                    }
                }
            }

            if (state.continueWatching.isNotEmpty()) {
                item(key = "cw-title") {
                    SectionTitle("Continue watching", actionLabel = "All videos", onAction = { onNavigate(VideosRoute) })
                }
                item(key = "cw-row") {
                    LazyRow(
                        modifier = Modifier.reveal(revealState, "cw-row", order = 4),
                        contentPadding = PaddingValues(horizontal = ScreenMargin),
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.md),
                    ) {
                        items(state.continueWatching, key = { it.video.id }) { item ->
                            VideoCard(item, onClick = { onPlayVideo(item.video) }, modifier = Modifier.width(250.dp))
                        }
                    }
                }
            }

            if (state.recentlyAdded.isNotEmpty()) {
                item(key = "recent-title") {
                    SectionTitle("Recently added", actionLabel = "See all", onAction = { onNavigate(MusicRoute) })
                }
                item(key = "recent-row") {
                    LazyRow(
                        modifier = Modifier.reveal(revealState, "recent-row", order = 4),
                        contentPadding = PaddingValues(horizontal = ScreenMargin),
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.md),
                    ) {
                        items(state.recentlyAdded.size, key = { state.recentlyAdded[it].id }) { index ->
                            val song = state.recentlyAdded[index]
                            ShelfCard(
                                title = song.title,
                                subtitle = song.artist,
                                onClick = {
                                    viewModel.playRecent(index)
                                    onOpenNowPlaying()
                                },
                                onClickLabel = "Play ${song.title}",
                                modifier = Modifier.width(shelfCard),
                            ) { mod -> SongCover(song, mod, cornerRadius = 14.dp) }
                        }
                    }
                }
            }

            if (state.newestAlbums.size > 1) {
                item(key = "albums-title") {
                    SectionTitle("Albums on this phone", actionLabel = "See all", onAction = { onNavigate(MusicRoute) })
                }
                item(key = "albums-row") {
                    LazyRow(
                        modifier = Modifier.reveal(revealState, "albums-row", order = 5),
                        contentPadding = PaddingValues(horizontal = ScreenMargin),
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.md),
                    ) {
                        items(state.newestAlbums, key = { it.key }) { album ->
                            val cover = album.coverSong
                            ShelfCard(
                                title = album.title,
                                subtitle = album.subtitle,
                                onClick = { onNavigate(CollectionRoute(album.type.name, album.key, album.title)) },
                                onClickLabel = "Open ${album.title}",
                                modifier = Modifier.width(shelfCard),
                            ) { mod ->
                                if (cover != null) SongCover(cover, mod, cornerRadius = 14.dp) else Box(mod.background(VortexColors.Card))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun librarySubtitle(state: HomeUiState): String = when {
    state.loading -> "Reading your library…"
    state.songCount == 0 && state.videoCount == 0 -> "Nothing found on this phone yet"
    else -> buildString {
        append(LibraryLogic.pluralize(state.songCount, "song"))
        append(" · ")
        append(LibraryLogic.pluralize(state.videoCount, "video"))
        if (state.musicDurationMs > 0) {
            append(" · ")
            append(Format.longDuration(state.musicDurationMs))
        }
    }
}

/** Newest album on the phone, full-bleed artwork with a scrim and the play actions. */
@Composable
private fun FeaturedAlbum(
    album: SongCollection,
    onPlay: () -> Unit,
    onShuffleAll: () -> Unit,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(24.dp)
    val cover = album.coverSong
    val zoom = rememberHeroZoom()
    Box(
        modifier
            .fillMaxWidth()
            .heightIn(max = 440.dp)
            .aspectRatio(1.1f)
            .clip(shape)
            .border(1.dp, VortexColors.Divider, shape)
            .clickable(role = Role.Button, onClickLabel = "Open ${album.title}", onClick = onOpen),
    ) {
        if (cover != null) {
            SongCover(
                cover,
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoom
                        scaleY = zoom
                    },
                cornerRadius = 0.dp,
                initialsSize = 96.sp,
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.25f),
                        0.4f to Color.Transparent,
                        0.62f to VortexColors.Background.copy(alpha = 0.55f),
                        1f to VortexColors.Background.copy(alpha = 0.97f),
                    ),
                ),
        )
        MetaChip(
            "NEWEST ON THIS PHONE",
            accent = true,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(VortexSpacing.lg),
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(VortexSpacing.lg),
        ) {
            Text(
                album.title,
                style = MaterialTheme.typography.headlineMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${album.subtitle} · ${LibraryLogic.pluralize(album.songs.size, "song")} · ${Format.longDuration(album.totalDurationMs)}",
                style = MaterialTheme.typography.bodyMedium,
                color = VortexColors.TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(VortexSpacing.md))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(VortexSpacing.sm)) {
                PrimaryButton("Play album", onClick = onPlay, icon = Icons.Rounded.PlayArrow)
                SecondaryButton("Shuffle all", onClick = onShuffleAll, icon = Icons.Rounded.Shuffle)
            }
        }
    }
}

/** Portrait card on the Home Shorts shelf. */
@Composable
private fun ShortCard(video: Video, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .aspectRatio(9f / 16f)
            .pressClickable(onClickLabel = "Play ${video.title}", clipShape = shape, onClick = onClick)
            .border(1.dp, VortexColors.Divider, shape),
    ) {
        VideoThumbnail(video, Modifier.fillMaxSize(), cornerRadius = 0.dp)
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.85f))),
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(VortexSpacing.sm),
        ) {
            Text(
                video.title,
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                Format.duration(video.durationMs),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.75f),
            )
        }
    }
}

@Composable
private fun EmptyLibraryCard(onRescan: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(VortexColors.Card)
            .border(1.dp, VortexColors.Divider, shape)
            .padding(VortexSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = VortexColors.Accent, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(VortexSpacing.md))
        Text("No music or videos found", style = MaterialTheme.typography.titleMedium)
        Text(
            "Copy files to this phone (Music, Download, Movies) and they appear here.",
            style = MaterialTheme.typography.bodyMedium,
            color = VortexColors.TextSecondary,
        )
        Spacer(Modifier.height(VortexSpacing.md))
        SecondaryButton("Scan again", onClick = onRescan, icon = Icons.Rounded.Refresh)
    }
}

/**
 * Home control-centre deck: what is playing, how it reaches the ears (DSP
 * state, stream format, output route) and the main controls. Every value
 * comes from the player, Media3 or Android.
 */
@Composable
private fun NowPlayingDeck(
    nowPlaying: NowPlaying,
    isPlaying: Boolean,
    position: PositionSnapshot,
    durationMs: Long,
    status: DspStatus,
    formatLine: String?,
    routeLine: String?,
    onOpen: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onOpenAudioLab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    0f to VortexColors.Accent.copy(alpha = 0.26f),
                    0.55f to VortexColors.Card,
                    1f to VortexColors.Card,
                ),
            )
            .border(1.dp, VortexColors.Accent.copy(alpha = 0.35f), shape)
            .clickable(role = Role.Button, onClickLabel = "Open player", onClick = onOpen)
            .padding(VortexSpacing.lg),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CoverArt(nowPlaying, Modifier.size(88.dp), cornerRadius = 16.dp, compact = true)
            Spacer(Modifier.width(VortexSpacing.md))
            Column(Modifier.weight(1f)) {
                Text(if (isPlaying) "NOW PLAYING" else "PAUSED", style = InstrumentText.label.copy(color = VortexColors.Accent))
                Text(nowPlaying.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(nowPlaying.artist, style = MaterialTheme.typography.bodySmall, color = VortexColors.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            PlayCircleButton(isPlaying = isPlaying, onClick = onTogglePlay, size = 56.dp)
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = VortexColors.TextPrimary)
            }
        }
        Spacer(Modifier.height(VortexSpacing.md))
        val duration = if (position.durationMs > 0) position.durationMs else durationMs
        val fraction = if (duration > 0) (position.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
        ProgressLine(fraction)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            Text(Format.duration(position.positionMs), style = InstrumentText.readoutSmall)
            Spacer(Modifier.weight(1f))
            Text(if (duration > 0) Format.duration(duration) else "--:--", style = InstrumentText.readoutSmall)
        }
        Spacer(Modifier.height(VortexSpacing.sm))
        SignalChips(status = status, formatLine = formatLine, routeLine = routeLine, onOpenAudioLab = onOpenAudioLab)
    }
}
