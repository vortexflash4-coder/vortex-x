package com.vortexx.player.audio.engine

import android.media.MediaCodecList

/**
 * The optional FFmpeg decoder pack (Media3 decoder_ffmpeg). Media3 adds its
 * renderer by reflection when the class is in the APK, after the phone's own
 * decoders, so it is used only for formats the phone cannot decode itself.
 * This object answers the same question for the screens, also by reflection,
 * so the app builds and runs with or without the pack.
 */
object DecoderPack {

    data class AudioFormat(val label: String, val mimeType: String)

    /** Formats the pack is built for (see .github/scripts/ci-ffmpeg.sh). */
    val Formats = listOf(
        AudioFormat("Dolby Digital (AC-3)", "audio/ac3"),
        AudioFormat("Dolby Digital Plus (E-AC-3)", "audio/eac3"),
        AudioFormat("DTS", "audio/vnd.dts"),
        AudioFormat("DTS-HD", "audio/vnd.dts.hd"),
        AudioFormat("Dolby TrueHD", "audio/true-hd"),
        AudioFormat("ALAC", "audio/alac"),
        AudioFormat("FLAC", "audio/flac"),
        AudioFormat("Opus", "audio/opus"),
        AudioFormat("Vorbis", "audio/vorbis"),
        AudioFormat("MP3", "audio/mpeg"),
        AudioFormat("AAC", "audio/mp4a-latm"),
        AudioFormat("AMR-NB", "audio/3gpp"),
        AudioFormat("AMR-WB", "audio/amr-wb"),
        AudioFormat("G.711 μ-law", "audio/g711-mlaw"),
        AudioFormat("G.711 A-law", "audio/g711-alaw"),
    )

    data class FormatSupport(val format: AudioFormat, val phone: Boolean, val pack: Boolean) {
        val playable: Boolean get() = phone || pack
    }

    data class Status(
        /** The pack's classes are in this APK. */
        val included: Boolean,
        /** Its native library loaded on this phone. */
        val loaded: Boolean,
        val version: String?,
        val formats: List<FormatSupport>,
    )

    private const val LIBRARY_CLASS = "androidx.media3.decoder.ffmpeg.FfmpegLibrary"

    /** True when this APK was built with the pack (cheap; safe on the main thread). */
    val included: Boolean by lazy { runCatching { Class.forName(LIBRARY_CLASS) }.isSuccess }

    /** Reads the pack and the phone's decoders. Touches MediaCodecList: call off the main thread. */
    fun status(): Status {
        val library = runCatching { Class.forName(LIBRARY_CLASS) }.getOrNull()
        val loaded = library != null && callStatic(library, "isAvailable") == true
        val version = if (loaded) callStatic(library!!, "getVersion") as? String else null
        val phoneTypes = phoneDecoderTypes()
        val formats = Formats.map { format ->
            val pack = loaded && callStatic(library!!, "supportsFormat", format.mimeType) == true
            FormatSupport(format, phone = format.mimeType in phoneTypes, pack = pack)
        }
        return Status(included = library != null, loaded = loaded, version = version, formats = formats)
    }

    private fun callStatic(owner: Class<*>, name: String, vararg args: String): Any? = runCatching {
        val types = Array<Class<*>>(args.size) { String::class.java }
        owner.getMethod(name, *types).invoke(null, *args)
    }.getOrNull()

    private fun phoneDecoderTypes(): Set<String> = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { !it.isEncoder }
            .flatMap { info -> info.supportedTypes.map { it.lowercase() } }
            .toSet()
    }.getOrDefault(emptySet())
}
