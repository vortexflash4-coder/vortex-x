package com.vortexx.player.ui.designsystem.motion

import androidx.compose.ui.graphics.Shape
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.vortexx.player.ui.designsystem.theme.VortexColors
import kotlinx.coroutines.delay

/**
 * Remembers which items have already played their entrance, so scrolling an
 * item out and back in does not replay it. One per screen.
 */
class RevealState internal constructor() {
    internal val seen = HashSet<Any>()
}

@Composable
fun rememberRevealState(): RevealState = remember { RevealState() }

/**
 * Entrance motion: fade in and rise 28 dp, staggered by [order]. Plays once
 * per [key] per screen. Compose scales animation time with the system
 * animator setting, so "Remove animations" makes it instant.
 */
@Composable
fun Modifier.reveal(state: RevealState, key: Any, order: Int = 0): Modifier {
    val firstTime = remember(key) { state.seen.add(key) }
    val progress = remember(key) { Animatable(if (firstTime) 0f else 1f) }
    LaunchedEffect(key) {
        if (progress.value < 1f) {
            delay(order.coerceAtMost(8) * 70L)
            progress.animateTo(1f, tween(durationMillis = 460, easing = FastOutSlowInEasing))
        }
    }
    return this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 28.dp.toPx()
    }
}

/**
 * Clickable that shrinks slightly while pressed (cards, covers, big buttons).
 * With [clipShape] the content and the press ripple are clipped to it.
 */
@Composable
fun Modifier.pressClickable(
    onClickLabel: String? = null,
    role: Role = Role.Button,
    clipShape: Shape? = null,
    pressedScale: Float = 0.96f,
    onClick: () -> Unit,
): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 700f),
        label = "pressScale",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
            if (clipShape != null) {
                shape = clipShape
                clip = true
            }
        }
        .clickable(
            interactionSource = source,
            indication = LocalIndication.current,
            onClickLabel = onClickLabel,
            role = role,
            onClick = onClick,
        )
}

/** Slow "Ken Burns" zoom for hero artwork: 1.0 → [maxScale] and back over [periodMs]. */
@Composable
fun rememberHeroZoom(maxScale: Float = 1.08f, periodMs: Int = 14_000): Float {
    val transition = rememberInfiniteTransition(label = "heroZoom")
    val zoom by transition.animateFloat(
        initialValue = 1f,
        targetValue = maxScale,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing), RepeatMode.Reverse),
        label = "heroZoomValue",
    )
    return zoom
}

/** A soft red light drifting behind a header. Decoration only; draws nothing else. */
@Composable
fun AmbientGlow(modifier: Modifier = Modifier, color: Color = VortexColors.Accent) {
    val transition = rememberInfiniteTransition(label = "ambientGlow")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "ambientGlowDrift",
    )
    Canvas(modifier) {
        val centre = Offset(size.width * (0.2f + 0.6f * drift), size.height * 0.15f)
        val radius = size.maxDimension * 0.75f
        drawRect(
            Brush.radialGradient(
                colors = listOf(color.copy(alpha = 0.26f), color.copy(alpha = 0.06f), Color.Transparent),
                center = centre,
                radius = radius,
            ),
        )
    }
}
