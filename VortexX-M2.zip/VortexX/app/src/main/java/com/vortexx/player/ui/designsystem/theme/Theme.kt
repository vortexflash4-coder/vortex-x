package com.vortexx.player.ui.designsystem.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.CompositionLocalProvider
import android.content.res.AssetManager
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Central design tokens for VORTEX X (docs/design/DESIGN_SYSTEM.md). */
object VortexColors {
    val Background = Color(0xFF08090B)
    val Surface = Color(0xFF101114)
    val Card = Color(0xFF14161A)
    val CardRaised = Color(0xFF1B1D22)
    val Accent = Color(0xFFF43F46)
    val AccentActive = Color(0xFFFF5A60)
    val AccentPressed = Color(0xFFD8333A)
    val AccentContainer = Color(0xFF3A1014)
    val TextPrimary = Color(0xFFF4F5F7)
    val TextSecondary = Color(0xFF969CA8)
    val Divider = Color(0xFF272A30)
    val Success = Color(0xFF38C98A)

    /** Used only for "limited / partial" states (never decorative). */
    val Caution = Color(0xFFF2B33D)

    val HeroGlow: Brush = Brush.verticalGradient(
        0f to Accent.copy(alpha = 0.22f),
        0.55f to Accent.copy(alpha = 0.05f),
        1f to Color.Transparent,
    )
    val ArtworkScrim: Brush = Brush.verticalGradient(
        0f to Color.Transparent,
        1f to Background.copy(alpha = 0.85f),
    )
}

object VortexSpacing {
    val xxs = 2.dp
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp

    /** Minimum interactive size (Material accessibility guidance). */
    val touchTarget = 48.dp
}

object VortexRadius {
    val sm = 12.dp
    val md = 16.dp
    val lg = 20.dp
    val pill = 50
}

private val VortexColorScheme = darkColorScheme(
    primary = VortexColors.Accent,
    onPrimary = VortexColors.TextPrimary,
    primaryContainer = VortexColors.AccentContainer,
    onPrimaryContainer = VortexColors.AccentActive,
    secondary = VortexColors.AccentActive,
    onSecondary = VortexColors.TextPrimary,
    secondaryContainer = VortexColors.CardRaised,
    onSecondaryContainer = VortexColors.TextPrimary,
    tertiary = VortexColors.Success,
    onTertiary = VortexColors.Background,
    background = VortexColors.Background,
    onBackground = VortexColors.TextPrimary,
    surface = VortexColors.Surface,
    onSurface = VortexColors.TextPrimary,
    surfaceVariant = VortexColors.Card,
    onSurfaceVariant = VortexColors.TextSecondary,
    surfaceTint = VortexColors.Accent,
    surfaceContainerLowest = VortexColors.Background,
    surfaceContainerLow = Color(0xFF0D0E11),
    surfaceContainer = VortexColors.Surface,
    surfaceContainerHigh = VortexColors.Card,
    surfaceContainerHighest = VortexColors.CardRaised,
    outline = VortexColors.Divider,
    outlineVariant = VortexColors.Divider,
    error = VortexColors.AccentActive,
    onError = VortexColors.TextPrimary,
    errorContainer = VortexColors.AccentContainer,
    onErrorContainer = VortexColors.AccentActive,
    scrim = Color(0xCC000000),
)

/**
 * Type scale from the design system: hero 30, section 21, body 16, secondary 14, metadata 12,
 * in [sans] (Montserrat when the build carries it, see [BrandFonts]).
 */
fun vortexTypography(sans: FontFamily): Typography = Typography(
    displaySmall = TextStyle(fontFamily = sans, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontFamily = sans, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.25).sp),
    headlineSmall = TextStyle(fontFamily = sans, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = sans, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 27.sp),
    titleMedium = TextStyle(fontFamily = sans, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 23.sp),
    titleSmall = TextStyle(fontFamily = sans, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = sans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = sans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = sans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontFamily = sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.3.sp),
    labelSmall = TextStyle(fontFamily = sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.8.sp),
)

/** Platform-font typography, for previews and code outside the theme. */
val VortexTypography = vortexTypography(FontFamily.SansSerif)

/** The brand font family in effect (Montserrat, or the platform sans as fallback). */
val LocalBrandFont = staticCompositionLocalOf<FontFamily> { FontFamily.SansSerif }

/**
 * Montserrat (SIL OFL 1.1) as a variable font from assets/fonts, which CI downloads
 * (.github/scripts/ci-assets.sh). Missing file: the platform sans is used.
 */
object BrandFonts {
    const val MONTSERRAT = "fonts/Montserrat-Variable.ttf"

    @OptIn(ExperimentalTextApi::class)
    fun load(assets: AssetManager): FontFamily = runCatching {
        assets.open(MONTSERRAT).close()
        FontFamily(
            Font(MONTSERRAT, assets, FontWeight.Normal),
            Font(MONTSERRAT, assets, FontWeight.Medium),
            Font(MONTSERRAT, assets, FontWeight.SemiBold),
            Font(MONTSERRAT, assets, FontWeight.Bold),
            Font(MONTSERRAT, assets, FontWeight.ExtraBold),
            Font(MONTSERRAT, assets, FontWeight.Black),
        )
    }.getOrDefault(FontFamily.SansSerif)
}

val VortexShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(VortexRadius.sm),
    medium = RoundedCornerShape(VortexRadius.md),
    large = RoundedCornerShape(VortexRadius.lg),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun VortexTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val family = remember { BrandFonts.load(context.assets) }
    val typography = remember(family) { vortexTypography(family) }
    CompositionLocalProvider(LocalBrandFont provides family) {
        MaterialTheme(
            colorScheme = VortexColorScheme,
            typography = typography,
            shapes = VortexShapes,
            content = content,
        )
    }
}
