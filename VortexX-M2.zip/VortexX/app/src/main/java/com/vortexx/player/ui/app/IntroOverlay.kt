package com.vortexx.player.ui.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortexx.player.ui.designsystem.components.VortexWordmark
import com.vortexx.player.ui.designsystem.theme.VortexColors
import kotlinx.coroutines.delay

private val EaseOutBack = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
private val EaseOut = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)

/**
 * Opening animation, about 1.5 s: the two arms of the mark fly in and lock
 * into the V, the play aperture opens, a red light blooms behind it and the
 * wordmark settles. Tap anywhere to skip. With Android's "Remove
 * animations" setting, Compose runs it instantly.
 */
@Composable
fun IntroOverlay(onFinished: () -> Unit) {
    val finish by rememberUpdatedState(onFinished)
    val arms = remember { Animatable(0f) }
    val aperture = remember { Animatable(0f) }
    val words = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        arms.animateTo(1f, tween(durationMillis = 620, easing = EaseOut))
        aperture.animateTo(1f, tween(durationMillis = 280, easing = EaseOutBack))
        words.animateTo(1f, tween(durationMillis = 420, easing = EaseOut))
        delay(260)
        exit.animateTo(0f, tween(durationMillis = 320))
        finish()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exit.value }
            .background(VortexColors.Background)
            .pointerInput(Unit) { detectTapGestures { finish() } },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(360.dp)) {
            val bloom = (arms.value * 0.6f + aperture.value * 0.4f).coerceIn(0f, 1f)
            drawCircle(
                Brush.radialGradient(
                    colors = listOf(VortexColors.Accent.copy(alpha = 0.42f * bloom), Color.Transparent),
                    center = center,
                    radius = size.minDimension / 2f,
                ),
                radius = size.minDimension / 2f,
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(132.dp)) {
                drawAnimatedMark(arms.value, aperture.value)
            }
            Spacer(Modifier.height(22.dp))
            VortexWordmark(
                fontSize = 28.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = words.value
                    translationY = (1f - words.value) * 18.dp.toPx()
                },
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "MUSIC  ·  VIDEO  ·  CINEMA",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 3.sp),
                color = VortexColors.TextSecondary,
                modifier = Modifier.graphicsLayer { alpha = words.value },
            )
        }
    }
}

/** The mark from ic_vortex_mark.xml (200 × 200 viewport), drawn with the arms at [arms] (0–1). */
private fun DrawScope.drawAnimatedMark(arms: Float, aperture: Float) {
    val unit = size.minDimension / 200f
    fun path(vararg points: Float): Path = Path().apply {
        moveTo(points[0] * unit, points[1] * unit)
        var i = 2
        while (i < points.size) {
            lineTo(points[i] * unit, points[i + 1] * unit)
            i += 2
        }
        close()
    }
    val back = path(14f, 34f, 76f, 34f, 116f, 146f, 100f, 180f)
    val front = path(186f, 26f, 124f, 26f, 80f, 126f, 100f, 180f)
    val fold = path(80f, 126f, 100f, 180f, 92f, 138f)
    val hole = path(88f, 84f, 88f, 112f, 111f, 98f)
    val travel = 70f * unit * (1f - arms)

    translate(left = -travel, top = -travel * 0.4f) {
        drawPath(back, Color(0xFFB3171F), alpha = arms)
    }
    translate(left = travel, top = -travel * 0.4f) {
        drawPath(front, VortexColors.Accent, alpha = arms)
        drawPath(fold, Color.Black.copy(alpha = 0.18f), alpha = arms)
    }
    if (aperture > 0f) {
        scale(scale = aperture, pivot = Offset(96f * unit, 98f * unit)) {
            drawPath(hole, VortexColors.Background)
        }
    }
}
