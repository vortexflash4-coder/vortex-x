# VORTEX X — project state

Last updated: 2026-11-12 (M2 step 1, versionCode 6 / 0.4.0-m2). Read this first when resuming.

## Where the source lives
- Canonical source: this tree, delivered as `VortexX-A0r5.zip` and uploaded to `main` of
  github.com/vortexflash4-coder/vortex-x. CI: `.github/workflows/vortex.yml` (repo) runs `.github/scripts/ci-build.sh` (inside the zip) and pushes each run's summary, logs and JUnit XML to the branch `ci-results`.
- A second A0 line exists on branch `codex/a0-verification-20261111` (PR #1, source under `a0/`): versionName `0.2.1-a0-review`, versionCode 3, signed with a debug keystore committed in that branch. It was built from the first A0 package. See DECISIONS.md D1–D3.

## M1 (design) — written, CI pending
Owner override (D12): the design app is built before the A0 phone checks. M1 = brand mark, launcher/splash, tokens, custom bottom bar Home | Music | Video | Library | You (D11), mini player, Home, Music, album hero, Now Playing (Audio Lab strip with the real EQ curve), Video tabs All / In progress / Cinema with a featured hero, Library, You hub, Audio Lab EQ curve. Built from branch `src/m1` by `vortex-src.yml` (D13). Install over the existing app without uninstalling; that install also confirms the signing pin.

### CI evidence (M1, VORTEX X build #7, 2026-11-12, from `VortexX-M1.zip`)
assembleDebug ✅ · unit tests 77/77 ✅ · androidTest compile ✅ · APK `app-debug.apk` 22.8 MB · `com.vortexx.player.debug` 0.3.0-m1-debug (5) · signer d73bff61…bb5d = pinned ✅ · DSP table all PASS. Phone install/visual check: pending.

## M2 step 1 (0.4.0-m2) — written, CI pending
Owner brief (2026-11-12): a "wow" app with cinema player, songs player, video player, short videos, AI helper, premium font and motion; wants a real ~370 MB app. Plan agreed with the owner: (1) font, opening animation, Home motion, Shorts from phone videos, FFmpeg decoder pack; (2) legal online sources + Downloads (D17); (3) AI helper, on-device lyrics and karaoke models (the real source of size, D9).
This step: Montserrat via CI, `IntroOverlay`, `Motion.kt` (reveal, press scale, hero zoom, ambient glow), Shorts tab (vertical pager, one shared player, like/mute/share/open in player, double-tap like, likes stored as video favourites), Home Shorts shelf, tabs per D14, FFmpeg pack per D15 with a Diagnostics section, direct APK release per D16. Built from an overlay branch `src/*` on top of `VortexX-M1.zip` (`.vx-base`).

## Gate A0 (real phone) — NOT YET ACCEPTED
The checks below are still open (owner deferred them, D12).
Recorded so far (from owner screenshots, 2026-11-12): the APK from VORTEX X build #5 was downloaded; Now Playing plays a local MP3 ("Sheesha Chahe Toot Bhi Jaaye"). Which APK is installed is not yet confirmed (Settings footer shows the version).

| # | Gate check | Result |
|---|---|---|
| 0 | Installed build (Settings → bottom line shows version) | **VORTEX X 0.2.0-a0-debug** (owner screenshot 2026-11-12 10:08) = this tree's A0r4/A0r5 line, not the Codex build. Signer expected to be the Actions-cache key (builds #4/#5); confirmed when A0r6 installs as an update. |
| 1 | App installs and opens; library loads | NOT TESTED (playback seen, not confirmed as a test) |
| 2 | Audio Lab shows "DSP · Active" while a song plays; meters move | NOT TESTED |
| 3 | 63 Hz +9 dB is clearly audible; Flat restores the sound | NOT TESTED |
| 4 | Battery offload: EQ stops within a moment, no click; status "Off: battery mode" | NOT TESTED |
| 5 | Faders are readable and the bank scrolls sideways | NOT TESTED |
| 6 | Close and reopen: EQ, preamp, bypass and mode are kept | NOT TESTED |
| 7 | 10 minutes of playback with screen off: no crash, no dropouts | NOT TESTED |

A1 work started on 2026-11-12 before the master prompt arrived (Now Playing redesign, Home deck, title clean-up). It was removed from this tree and parked outside the repository; it is not in any package. It will be re-reviewed against the 16 references after the gate.

## CI evidence (A0r5, VORTEX X build #4 and #5, 2026-11-12)
assembleDebug ✅ · testDebugUnitTest 68/68, 0 skipped ✅ · assembleDebugAndroidTest ✅ (compiled, not executed) · lint not run in the phone workflow · APK 22.7 MB. Allocation: processor rounds 1184 / 0 / 0 bytes over 5000 buffers each after 5000 warm-up buffers (gate: lowest round < 1024); DSP chain 0 bytes. Signing: CI debug key kept in the Actions cache (build #4 created it, #5 reused it).
Not yet in CI: APK signature/package/version verification step (planned, see FEATURE_STATUS).

## Review findings (2026-11-12, owner's reviewer on PR #3) and actions
1. Settings inventory and rendered board were missing from PR #3 → added (`docs/SETTINGS_INVENTORY.md`, `docs/design/brand/board.html`; the PNG render is in the chat and the zip).
2. Signing key lives only in the Actions cache; a cache miss would silently create a new key and the next APK would not update the installed app → CI now reads package, version and signer SHA-256 from every built APK (apksigner/aapt2) and fails when a pinned certificate exists and differs. After gate check 0 identifies the installed build: pin its certificate in `.github/signing/expected-debug-cert-sha256.txt`, and make the key durable (installed = build #4/#5: export the cached key once into the repository secret and stop creating keys when a pin exists; installed = Codex build: build with that branch's keystore). Workflow change follows that answer.
3. Allocation gate took the lowest of three rounds (1184 / 0 / 0) → restored to "every round < 1024 bytes", warm-up raised to 20 000 buffers with an alternating parameter change, each round split into 10 blocks of 500 to locate any one-off allocation, plus direct-buffer growth (must be 0). The 1184-byte round is kept in the history; its cause is not yet identified (next CI run reports the block).
Package with these changes: `VortexX-A0r6.zip`, versionName 0.2.2-a0, versionCode 4.

## CI evidence (A0r6, VORTEX X build #6, 2026-11-12)
assembleDebug ✅ · assembleDebugAndroidTest ✅ · testDebugUnitTest ❌ did not compile: the new direct-buffer check used `java.lang.management`, which is not on the Android unit-test compile classpath (fixed in A0r7 by reflection, like the heap counter). No JUnit results, so no allocation numbers from this run.
APK identity read from the APK: versionName 0.2.2-a0-debug, versionCode 4, signature scheme v2, signer SHA-256 `d73bff6164edf3cab201def28f8e72ffa4a4586533c43cd841849a962794bb5d` (package field was mis-parsed as "16"; parser fixed in A0r7). Same key as builds #4/#5 (Actions cache).
Pin: that certificate is pinned in `.github/signing/expected-debug-cert-sha256.txt` (repository root and project). **Provisional** until the build #6/A0r7 APK installs over the phone's 0.2.0-a0-debug as an update without uninstalling; if Android refuses, the phone app came from a differently signed run (#3) and the pin is withdrawn.

## Next checkpoint
1. Owner runs the 8 gate checks above and reports PASS/FAIL per number.
2. Fix any A0 failure within A0 scope; record results here.
3. On acceptance: Build milestone 1 (brand, components, navigation shell, local library, Now Playing, Video shell, Settings hub) per docs/design/ROUTE_MAP.md.

## Implementation sequence (after the gate)
- **M1** brand vector + adaptive icon + font; tokens in code; bottom nav Home | Music | Video | Downloads | You; mini player; Home (local sources only), Music library (03), Now Playing (04), Queue (05 without lyrics source), Video list/player shell (11), Settings hub (14) with search that opens the setting. Real screenshots from CI (Roborazzi or instrumentation) where possible.
- **M2** expanded DSP: presets save/import/export, A/B, response graph from coefficients (06); compressor, sample-peak limiter, width, balance, reverb (07) — each with measured CI tests before it is shown. Studio/Balanced/Battery (15). Full setting-to-engine wiring (docs/SETTINGS_INVENTORY.md).
- **M3** sources: user-provided HTTPS URLs, then documented open-licence sources, Media3 downloads (13), film/video detail (09/10) only with real sources. Commercial services only with their official SDKs and agreements.
- **M4** visual comparison against the references at 320/360/393/412 dp, accessibility, lifecycle/route stability, performance on the owner's phone, size report.
