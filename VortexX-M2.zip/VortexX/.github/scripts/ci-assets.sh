#!/usr/bin/env bash
# Downloads the app's open-licence fonts into app/src/main/assets/fonts before Gradle runs.
# Fonts are binary, so they are fetched here instead of living in the source upload.
# Montserrat: SIL Open Font License 1.1 (google/fonts, ofl/montserrat). The app falls back to
# the platform font when the file is missing, so a failure here never breaks the build.
#
# usage: ci-assets.sh <project_dir>
set -euo pipefail

DIR="$(cd "${1:?project dir}" && pwd)"
OUT="$DIR/app/src/main/assets/fonts"
BASE="https://github.com/google/fonts/raw/main/ofl/montserrat"
mkdir -p "$OUT"

curl -fsSL --retry 3 -o "$OUT/Montserrat-Variable.ttf" "$BASE/Montserrat%5Bwght%5D.ttf"
curl -fsSL --retry 3 -o "$OUT/Montserrat-OFL.txt" "$BASE/OFL.txt"

MAGIC="$(head -c 4 "$OUT/Montserrat-Variable.ttf" | od -An -tx1 | tr -d ' \n')"
SIZE="$(wc -c < "$OUT/Montserrat-Variable.ttf")"
if [ "$MAGIC" != "00010000" ] || [ "$SIZE" -lt 100000 ]; then
  echo "::warning::Montserrat download is not a TrueType font (magic $MAGIC, $SIZE bytes); using the platform font."
  rm -f "$OUT/Montserrat-Variable.ttf"
  exit 1
fi
echo "Fonts: Montserrat variable ($SIZE bytes, sha256 $(sha256sum "$OUT/Montserrat-Variable.ttf" | cut -c1-16)…)"
