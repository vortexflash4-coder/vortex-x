#!/usr/bin/env bash
# Prepares the optional :ffmpeg module (Media3 FFmpeg audio decoder) before Gradle runs.
#
# 1. Copies the Media3 decoder_ffmpeg sources (Apache 2.0) at the same tag as the app's Media3.
# 2. Restores FFmpeg static libraries and headers from the branch named in CACHE_BRANCH, or builds
#    them with Media3's build_ffmpeg.sh (FFmpeg release/6.0, LGPL decoders only) and saves them
#    to that branch for the next run.
# 3. Writes ffmpeg/ndk-version.txt (read by ffmpeg/build.gradle.kts) and ffmpeg/READY.
#    settings.gradle.kts includes :ffmpeg only when READY exists, so a failure here still
#    gives an APK, just without the decoder pack; the CI summary shows it.
#
# usage: ci-ffmpeg.sh <project_dir>
set -euo pipefail

DIR="$(cd "${1:?project dir}" && pwd)"
MEDIA3_TAG="1.11.1"
FFMPEG_BRANCH="release/6.0"
ABI_LEVEL="26"
DECODERS=(vorbis opus flac alac pcm_mulaw pcm_alaw mp3 amrnb amrwb aac ac3 eac3 dca mlp truehd)
CACHE_REV="1"

MOD="$DIR/ffmpeg/src/main"
rm -f "$DIR/ffmpeg/READY"
WORK="$(mktemp -d "${RUNNER_TEMP:-/tmp}/vxffmpeg.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

# NDK: prefer r27, else the newest one installed on the runner.
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
NDK="$(ls -d "$SDK"/ndk/27.* 2>/dev/null | sort -V | tail -n 1 || true)"
[ -n "$NDK" ] || NDK="$(ls -d "$SDK"/ndk/* 2>/dev/null | sort -V | tail -n 1 || true)"
[ -n "$NDK" ] || NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-}}"
if [ -z "$NDK" ] || [ ! -d "$NDK/toolchains/llvm" ]; then
  echo "::warning::No Android NDK found; building without the FFmpeg decoder pack."
  exit 1
fi
NDK_VERSION="$(basename "$NDK")"
echo "FFmpeg pack: NDK $NDK_VERSION, Media3 $MEDIA3_TAG, FFmpeg $FFMPEG_BRANCH"

# 1. Media3 decoder_ffmpeg sources.
git clone -q --depth 1 --branch "$MEDIA3_TAG" --filter=blob:none --sparse https://github.com/androidx/media "$WORK/media"
git -C "$WORK/media" sparse-checkout set libraries/decoder_ffmpeg
SRC="$WORK/media/libraries/decoder_ffmpeg/src/main"
rm -rf "$MOD/java" "$MOD/jni"
mkdir -p "$MOD/java" "$MOD/jni"
cp -r "$SRC/java/." "$MOD/java/"
find "$SRC/jni" -maxdepth 1 -type f -exec cp {} "$MOD/jni/" \;

# 2. FFmpeg: restore from the cache branch, or build and save.
CACHE_BRANCH="prebuilt/ffmpeg-6.0-media3-$MEDIA3_TAG-ndk$NDK_VERSION-r$CACHE_REV"
WS="${GITHUB_WORKSPACE:-}"
mkdir -p "$MOD/jni/ffmpeg"
if [ -n "$WS" ] && git -C "$WS" fetch -q --depth 1 origin "refs/heads/$CACHE_BRANCH" 2>/dev/null; then
  git -C "$WS" archive FETCH_HEAD | tar -x -C "$MOD/jni/ffmpeg"
  echo "FFmpeg pack: restored from branch $CACHE_BRANCH"
  FROM=cache
else
  rm -rf "$MOD/jni/ffmpeg"
  git clone -q --depth 1 --branch "$FFMPEG_BRANCH" https://github.com/FFmpeg/FFmpeg "$MOD/jni/ffmpeg"
  (cd "$MOD/jni" && bash ./build_ffmpeg.sh "$MOD" "$NDK" linux-x86_64 "$ABI_LEVEL" "${DECODERS[@]}")
  FROM=built
  if [ -n "$WS" ]; then
    SAVE="$WORK/save"
    mkdir -p "$SAVE"
    (cd "$MOD/jni/ffmpeg" && cp -r android-libs "$SAVE/" && find . -name '*.h' -not -path './android-libs/*' -exec cp --parents {} "$SAVE/" \;)
    {
      echo "FFmpeg $FFMPEG_BRANCH static libraries and headers for the VORTEX X :ffmpeg module."
      echo "Built by .github/scripts/ci-ffmpeg.sh with NDK $NDK_VERSION, ABI level $ABI_LEVEL."
      echo "Decoders: ${DECODERS[*]}. FFmpeg is LGPL-2.1-or-later; source: https://github.com/FFmpeg/FFmpeg ($FFMPEG_BRANCH)."
    } > "$SAVE/PREBUILT.txt"
    HDR="$(git -C "$WS" config --get http.https://github.com/.extraheader || true)"
    (
      cd "$SAVE"
      git init -q
      git add -A
      git -c user.name=vortex-ci -c user.email=vortex-ci@users.noreply.github.com commit -qm "FFmpeg prebuilt ($CACHE_BRANCH)"
      if [ -n "$HDR" ]; then
        git -c "http.https://github.com/.extraheader=$HDR" push -qf "https://github.com/${GITHUB_REPOSITORY}.git" "HEAD:refs/heads/$CACHE_BRANCH"
      fi
    ) && echo "FFmpeg pack: saved to branch $CACHE_BRANCH" || echo "::warning::Could not save the FFmpeg cache branch (next run builds again)."
  fi
fi

if [ ! -d "$MOD/jni/ffmpeg/android-libs" ]; then
  echo "::warning::FFmpeg libraries missing after the build; building without the decoder pack."
  exit 1
fi
echo "$NDK_VERSION" > "$DIR/ffmpeg/ndk-version.txt"
# Use an SDK CMake 3.x (>= 3.21) that is already installed, so Gradle does not need to download one.
rm -f "$DIR/ffmpeg/cmake-version.txt"
CMAKE_V="$(ls "$SDK/cmake" 2>/dev/null | grep -E '^3\.(2[1-9]|[3-9][0-9])\.' | sort -V | tail -n 1 || true)"
[ -n "$CMAKE_V" ] && echo "$CMAKE_V" > "$DIR/ffmpeg/cmake-version.txt"
{
  echo "media3=$MEDIA3_TAG"
  echo "ffmpeg=$FFMPEG_BRANCH"
  echo "ndk=$NDK_VERSION"
  echo "cmake=${CMAKE_V:-default}"
  echo "from=$FROM"
  echo "decoders=${DECODERS[*]}"
} > "$DIR/ffmpeg/READY"
echo "FFmpeg pack: ready ($FROM)"
