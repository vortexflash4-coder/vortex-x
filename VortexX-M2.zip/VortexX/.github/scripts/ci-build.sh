#!/usr/bin/env bash
# VORTEX X CI build. Runs the Gradle steps, writes the job summary and fails if a
# required step failed. It lives inside the project, so the workflow file in the
# phone repository does not need editing when the build steps change.
#
# usage: ci-build.sh <project_dir> <logs_dir>
# env:   RUN_LINT=1      also run lintDebug (report only, never fails the run)
#        KEY_B64         the VORTEX_DEBUG_KEYSTORE_B64 secret (optional; decoded here)
#        SIGNING         fixed | temporary | invalid, if the workflow already decided it
#        GITHUB_OUTPUT   receives assemble=<outcome> for the APK upload step
set -uo pipefail

DIR="$(cd "${1:?project dir}" && pwd)"
LOGS="${2:?logs dir}"
mkdir -p "$LOGS"
LOGS="$(cd "$LOGS" && pwd)"
cd "$DIR"
# Source-branch overlay: a src/* branch may carry only the changed files plus .vx-base, which
# names a project zip at the repository root. Every file the branch does not have is taken
# from that zip; files in the branch win. .vx-deleted lists project paths to remove.
if [ -f .vx-base ]; then
  BASE_NAME="$(tr -d ' \r\n' < .vx-base)"
  BASE_ZIP="${GITHUB_WORKSPACE:-$DIR}/$BASE_NAME"
  if [ ! -f "$BASE_ZIP" ]; then
    echo "::error::Overlay base $BASE_NAME not found at the repository root."
    exit 1
  fi
  BASE_TMP="$(mktemp -d "${RUNNER_TEMP:-/tmp}/vxbase.XXXXXX")"
  unzip -q "$BASE_ZIP" -d "$BASE_TMP"
  BASE_DIR="$(dirname "$(find "$BASE_TMP" -maxdepth 4 -name gradlew | head -n 1)")"
  OVERLAID=0
  while IFS= read -r f; do
    if [ -e "$DIR/$f" ]; then OVERLAID=$((OVERLAID + 1)); continue; fi
    mkdir -p "$DIR/$(dirname "$f")"
    cp -p "$BASE_DIR/$f" "$DIR/$f"
  done < <(cd "$BASE_DIR" && find . -type f | sed 's|^\./||')
  if [ -f .vx-deleted ]; then
    while IFS= read -r f; do [ -n "$f" ] && rm -f "$DIR/$f"; done < .vx-deleted
  fi
  rm -rf "$BASE_TMP"
  echo "Overlay: $OVERLAID branch files on top of \`$BASE_NAME\`" >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
fi
# A source branch pushed as text carries the wrapper jar as base64.
if [ ! -f gradle/wrapper/gradle-wrapper.jar ] && [ -f gradle/wrapper/gradle-wrapper.jar.b64 ]; then
  base64 -d gradle/wrapper/gradle-wrapper.jar.b64 > gradle/wrapper/gradle-wrapper.jar
fi
chmod +x gradlew

# Debug signing key from the repository secret, when the workflow passes it as KEY_B64.
# It is written to a temporary folder outside the project and deleted when the script ends.
if [ -z "${SIGNING:-}" ]; then
  if [ -n "${KEY_B64:-}" ]; then
    KEYDIR="$(mktemp -d "${RUNNER_TEMP:-/tmp}/vxkey.XXXXXX")"
    trap 'rm -rf "$KEYDIR"' EXIT
    KEYFILE="$KEYDIR/vortex-debug.keystore"
    printf '%s' "$KEY_B64" | tr -d ' \r\n\t' | base64 -d > "$KEYFILE" 2>/dev/null || true
    if keytool -list -keystore "$KEYFILE" -storepass android -alias androiddebugkey > /dev/null 2>&1; then
      export VORTEX_DEBUG_KEYSTORE="$KEYFILE"
      SIGNING=fixed
    else
      rm -f "$KEYFILE"
      SIGNING=invalid
      echo "::warning::Secret VORTEX_DEBUG_KEYSTORE_B64 is not a valid keystore: this APK uses a temporary key."
    fi
  else
    SIGNING=temporary
    echo "::warning::Secret VORTEX_DEBUG_KEYSTORE_B64 is not set: this APK uses a temporary key."
  fi
fi
unset KEY_B64
export SIGNING

STEP=skipped
gradle_step() { # <title> <task> <log file>
  echo "::group::$1"
  ./gradlew --stacktrace "$2" 2>&1 | tee "$LOGS/$3"
  local rc=${PIPESTATUS[0]}
  echo "::endgroup::"
  if [ "$rc" -eq 0 ]; then STEP=success; else STEP=failure; echo "::warning::$1 failed (exit $rc)"; fi
}

# Open-licence fonts (binary, so downloaded here). A failure keeps the platform font.
FONTS=skipped
if [ -f "$DIR/.github/scripts/ci-assets.sh" ]; then
  if bash "$DIR/.github/scripts/ci-assets.sh" "$DIR" 2>&1 | tee "$LOGS/0-assets.log"; then FONTS=success; else FONTS=failure; fi
fi
export FONTS

# Optional FFmpeg decoder pack (:ffmpeg). A failure leaves it out of the APK; the summary shows it.
FFMPEG=skipped
if [ -f "$DIR/.github/scripts/ci-ffmpeg.sh" ] && [ -f "$DIR/ffmpeg/build.gradle.kts" ]; then
  echo "::group::FFmpeg decoder pack"
  if bash "$DIR/.github/scripts/ci-ffmpeg.sh" "$DIR" 2>&1 | tee "$LOGS/0-ffmpeg.log"; then FFMPEG=success; else FFMPEG=failure; fi
  echo "::endgroup::"
fi
export FFMPEG

ASSEMBLE=skipped UNIT=skipped ANDROIDTEST=skipped LINT=skipped
gradle_step "Build debug APK" assembleDebug 1-assembleDebug.log
ASSEMBLE=$STEP
# The decoder pack is optional: if the build fails with it, keep its errors and build without it.
if [ "$ASSEMBLE" != success ] && [ -f "$DIR/ffmpeg/READY" ]; then
  echo "::warning::Build failed with the FFmpeg decoder pack; building again without it."
  cp "$LOGS/1-assembleDebug.log" "$LOGS/1-assembleDebug-with-ffmpeg.log"
  grep -n -E "error:|^e: |FAILED|What went wrong|CMake Error|undefined reference|Could not|cannot find symbol" -A 4 "$LOGS/1-assembleDebug-with-ffmpeg.log" | head -n 120 > "$LOGS/0-ffmpeg-build-errors.txt" || true
  rm -f "$DIR/ffmpeg/READY"
  FFMPEG=failure
  export FFMPEG
  gradle_step "Build debug APK (without the FFmpeg pack)" assembleDebug 1-assembleDebug.log
  ASSEMBLE=$STEP
fi
if [ "$ASSEMBLE" = success ]; then
  gradle_step "JVM unit tests" testDebugUnitTest 2-testDebugUnitTest.log
  UNIT=$STEP
  gradle_step "Compile instrumentation tests" assembleDebugAndroidTest 3-assembleDebugAndroidTest.log
  ANDROIDTEST=$STEP
  if [ "${RUN_LINT:-0}" = 1 ]; then
    gradle_step "Lint (report only)" lintDebug 4-lintDebug.log
    LINT=$STEP
  fi
fi

if [ -n "${GITHUB_OUTPUT:-}" ]; then
  echo "assemble=$ASSEMBLE" >> "$GITHUB_OUTPUT"
fi

# APK identity: package, version and signing certificate read from the built APK with the
# Android build tools, compared with the pinned certificate when the project has one.
IDENTITY=skipped
APK_FILE="$(ls app/build/outputs/apk/debug/*.apk 2>/dev/null | head -n 1)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -n 1)"
# Pinned certificate: in the project, or at the repository root of the phone workflow checkout.
PIN_FILE="$DIR/.github/signing/expected-debug-cert-sha256.txt"
if [ ! -f "$PIN_FILE" ] && [ -n "${GITHUB_WORKSPACE:-}" ] && [ -f "$GITHUB_WORKSPACE/.github/signing/expected-debug-cert-sha256.txt" ]; then
  PIN_FILE="$GITHUB_WORKSPACE/.github/signing/expected-debug-cert-sha256.txt"
fi
if [ "$ASSEMBLE" = success ] && [ -n "$APK_FILE" ] && [ -x "$BT/apksigner" ] && [ -x "$BT/aapt2" ]; then
  "$BT/aapt2" dump badging "$APK_FILE" > "$LOGS/apk-badging.txt" 2>&1 || true
  "$BT/apksigner" verify -v --print-certs "$APK_FILE" > "$LOGS/apk-signature.txt" 2>&1
  SIG_RC=$?
  PKG_LINE="$(grep -m1 '^package:' "$LOGS/apk-badging.txt" || true)"
  PKG="$(printf '%s' "$PKG_LINE" | sed -n "s/^package: name='\([^']*\)'.*/\1/p")"
  VCODE="$(printf '%s' "$PKG_LINE" | sed -n "s/.*versionCode='\([^']*\)'.*/\1/p")"
  VNAME="$(printf '%s' "$PKG_LINE" | sed -n "s/.*versionName='\([^']*\)'.*/\1/p")"
  CERT="$(grep -m1 'certificate SHA-256 digest' "$LOGS/apk-signature.txt" | sed 's/.*digest: *//' | tr -d ' ' | tr 'A-F' 'a-f')"
  SCHEMES="$(grep -E '^Verified using v[0-9].*: true' "$LOGS/apk-signature.txt" | sed 's/Verified using //; s/ scheme.*//' | paste -sd ',' -)"
  PIN=""
  [ -f "$PIN_FILE" ] && PIN="$(tr -d ' \r\n' < "$PIN_FILE" | tr 'A-F' 'a-f')"
  if [ "$SIG_RC" -ne 0 ] || [ -z "$CERT" ]; then
    IDENTITY=failure; VERDICT="❌ signature did not verify"
  elif [ -n "$PIN" ] && [ "$PIN" != "$CERT" ]; then
    IDENTITY=failure; VERDICT="❌ certificate differs from the pinned one: this APK will NOT update the installed app"
  elif [ -n "$PIN" ]; then
    IDENTITY=success; VERDICT="✅ matches the pinned certificate (updates the installed app)"
  else
    IDENTITY=success; VERDICT="⚠️ no pinned certificate in the project yet"
  fi
  {
    echo "### APK identity (read from the built APK)"
    echo ""
    echo "| Field | Value |"
    echo "|---|---|"
    echo "| Package | \`${PKG:-?}\` |"
    echo "| versionName / versionCode | \`${VNAME:-?}\` / \`${VCODE:-?}\` |"
    echo "| Signature schemes verified | ${SCHEMES:-none} |"
    echo "| Signer certificate SHA-256 | \`${CERT:-?}\` |"
    if [ -n "$PIN" ]; then echo "| Pinned certificate | \`$PIN\` |"; else echo "| Pinned certificate | none |"; fi
    echo "| Result | $VERDICT |"
    echo ""
  } > "$LOGS/apk-identity.md"
  echo "APK identity: $PKG $VNAME ($VCODE) cert $CERT -> $IDENTITY"
elif [ "$ASSEMBLE" = success ]; then
  echo "::warning::Android build tools (apksigner/aapt2) not found; APK identity not checked."
fi

# Emulator smoke test (report only): opens the main screens, saves screenshots, looks for a crash.
SMOKE=skipped
if [ "$ASSEMBLE" = success ] && [ -n "$APK_FILE" ] && [ "${RUN_SMOKE:-1}" = 1 ] && [ -n "${GITHUB_WORKSPACE:-}" ] && [ -f "$DIR/.github/scripts/ci-smoke.sh" ]; then
  echo "::group::Emulator smoke test"
  timeout 1500 bash "$DIR/.github/scripts/ci-smoke.sh" "$APK_FILE" "${PKG:-com.vortexx.player.debug}" "$LOGS" 2>&1 | tee "$LOGS/6-smoke.log"
  SMOKE_RC=${PIPESTATUS[0]}
  echo "::endgroup::"
  case "$SMOKE_RC" in
    0) SMOKE=success ;;
    2) SMOKE=skipped ;;
    *) SMOKE=failure ;;
  esac
fi

# Direct .apk download for the phone: a release asset in this repository (see ci-publish.sh).
PUBLISH=skipped
if [ "$ASSEMBLE" = success ] && [ "$UNIT" = success ] && [ "$IDENTITY" = success ] && [ -n "${GITHUB_WORKSPACE:-}" ] && [ -f "$DIR/.github/scripts/ci-publish.sh" ]; then
  if bash "$DIR/.github/scripts/ci-publish.sh" "$APK_FILE" "${VNAME:-unknown}" "${VCODE:-0}" "$LOGS" 2>&1 | tee "$LOGS/5-publish.log"; then PUBLISH=success; else PUBLISH=failure; fi
fi

SMOKE=$SMOKE PUBLISH=$PUBLISH FONTS=$FONTS FFMPEG=$FFMPEG ASSEMBLE=$ASSEMBLE UNIT=$UNIT ANDROIDTEST=$ANDROIDTEST LINT=$LINT \
  bash "$DIR/.github/scripts/ci-summary.sh" "$DIR" "$LOGS"

echo "assembleDebug=$ASSEMBLE testDebugUnitTest=$UNIT assembleDebugAndroidTest=$ANDROIDTEST lintDebug=$LINT apkIdentity=$IDENTITY"
if [ "$ASSEMBLE" != success ] || [ "$UNIT" != success ] || [ "$ANDROIDTEST" != success ] || [ "$IDENTITY" = failure ]; then
  echo "::error::Build or tests failed. Open the run's Summary for the Errors box."
  exit 1
fi
