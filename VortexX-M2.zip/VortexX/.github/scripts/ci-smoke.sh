#!/usr/bin/env bash
# Emulator smoke test (report only, never fails the build). Boots a headless emulator on the CI
# machine, installs the APK, adds a test tone and a test clip, opens the main screens, saves a
# screenshot of each and checks that the app did not crash. Results: <logs>/smoke/.
#
# usage: ci-smoke.sh <apk_file> <package> <logs_dir>
# exit:  0 = ran, no crash   1 = ran, app crashed or a screen was missing   2 = could not run
set -uo pipefail

APK="${1:?apk}"
PKG="${2:?package}"
LOGS="${3:?logs dir}"
OUT="$LOGS/smoke"
mkdir -p "$OUT"
REPORT="$OUT/report.md"
: > "$REPORT"
say() { echo "$*" | tee -a "$REPORT"; }

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
ADB="$SDK/platform-tools/adb"
if [ ! -e /dev/kvm ]; then
  say "Skipped: this CI machine has no /dev/kvm (no hardware acceleration for the emulator)."
  exit 2
fi
echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules > /dev/null 2>&1 || true
sudo udevadm control --reload-rules > /dev/null 2>&1 || true
sudo udevadm trigger --name-match=kvm > /dev/null 2>&1 || true

SDKM="$(ls "$SDK"/cmdline-tools/*/bin/sdkmanager 2>/dev/null | sort -V | tail -n 1)"
if [ -z "$SDKM" ]; then
  say "Skipped: sdkmanager not found."
  exit 2
fi
AVDM="$(dirname "$SDKM")/avdmanager"
IMAGE="system-images;android-34;default;x86_64"
# pipefail is off inside the subshell: `yes` always ends with SIGPIPE when sdkmanager is done.
if ! (set +o pipefail; yes | timeout 600 "$SDKM" --install "$IMAGE" emulator platform-tools > "$OUT/sdkmanager.log" 2>&1); then
  say "Skipped: could not install the emulator image ($IMAGE)."
  exit 2
fi
echo no | "$AVDM" create avd --force -n vxsmoke -k "$IMAGE" -d pixel_6 > "$OUT/avd.log" 2>&1 || {
  say "Skipped: could not create the virtual device."
  exit 2
}

"$SDK/emulator/emulator" -avd vxsmoke -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader_indirect -camera-back none -camera-front none > "$OUT/emulator.log" 2>&1 &
EMU_PID=$!
trap 'exit 143' TERM INT
cleanup() {
  "$ADB" emu kill > /dev/null 2>&1 || true
  sleep 2
  kill "$EMU_PID" > /dev/null 2>&1 || true
}
trap cleanup EXIT

timeout 240 "$ADB" wait-for-device || { say "Skipped: the emulator did not start."; exit 2; }
BOOTED=0
for _ in $(seq 1 100); do
  if [ "$("$ADB" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ]; then BOOTED=1; break; fi
  sleep 3
done
if [ "$BOOTED" != 1 ]; then
  say "Skipped: the emulator did not finish booting in 5 minutes."
  exit 2
fi
"$ADB" shell input keyevent 82 > /dev/null 2>&1 || true

# Test media: a 12 s tone, and (when ffmpeg is on the machine) a 6 s portrait clip.
python3 - "$OUT/vortex_test_tone.wav" <<'PY'
import math, struct, sys, wave
with wave.open(sys.argv[1], "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(44100)
    frames = bytearray()
    for i in range(44100 * 12):
        v = int(9000 * math.sin(2 * math.pi * 440 * i / 44100))
        frames += struct.pack("<hh", v, v)
    w.writeframes(bytes(frames))
PY
"$ADB" shell mkdir -p /sdcard/Music /sdcard/Movies > /dev/null 2>&1 || true
"$ADB" push "$OUT/vortex_test_tone.wav" /sdcard/Music/Vortex_Test_Tone.wav > /dev/null 2>&1 || true
rm -f "$OUT/vortex_test_tone.wav"
if command -v ffmpeg > /dev/null 2>&1; then
  if ffmpeg -loglevel error -y -f lavfi -i "testsrc=size=540x960:rate=30" -f lavfi -i "sine=frequency=330" -t 6 -c:v libx264 -pix_fmt yuv420p -c:a aac "$OUT/clip.mp4" 2> /dev/null; then
    "$ADB" push "$OUT/clip.mp4" /sdcard/Movies/Vortex_Test_Clip.mp4 > /dev/null 2>&1 || true
  fi
  rm -f "$OUT/clip.mp4"
fi
"$ADB" shell "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Music/Vortex_Test_Tone.wav" > /dev/null 2>&1 || true
"$ADB" shell "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Movies/Vortex_Test_Clip.mp4" > /dev/null 2>&1 || true

if ! "$ADB" install -r "$APK" > "$OUT/install.log" 2>&1; then
  say "FAILED: the APK did not install on the emulator: $(tail -n 1 "$OUT/install.log")"
  exit 1
fi
for perm in READ_MEDIA_AUDIO READ_MEDIA_VIDEO READ_MEDIA_VISUAL_USER_SELECTED POST_NOTIFICATIONS; do
  "$ADB" shell pm grant "$PKG" "android.permission.$perm" > /dev/null 2>&1 || true
done
"$ADB" logcat -c > /dev/null 2>&1 || true

shot() { # <name>
  "$ADB" exec-out screencap -p > "$OUT/$1.png" 2> /dev/null || true
  [ -s "$OUT/$1.png" ] || rm -f "$OUT/$1.png"
}
alive() { [ -n "$("$ADB" shell pidof "$PKG" 2>/dev/null | tr -d '\r')" ]; }
tap_text() { # <visible text>; taps the centre of the first node showing it. 0 = tapped
  "$ADB" shell uiautomator dump /sdcard/vx_ui.xml > /dev/null 2>&1 || return 1
  "$ADB" exec-out cat /sdcard/vx_ui.xml > "$OUT/ui.xml" 2> /dev/null || return 1
  local xy
  xy="$(python3 - "$OUT/ui.xml" "$1" <<'PY'
import re, sys
xml = open(sys.argv[1], encoding="utf-8", errors="replace").read()
want = sys.argv[2]
nodes = re.findall(r"<node [^>]*>", xml)
def labels(node):
    out = []
    for attr in ("text", "content-desc"):
        m = re.search(r'\b%s="([^"]*)"' % attr, node)
        if m:
            out.append(m.group(1))
    return out
# Exact label first; then a merged Compose node whose label starts with the text ("Audio Lab, …").
for match in (lambda l: l == want, lambda l: l.startswith(want + ",")):
    for node in nodes:
        if any(match(l) for l in labels(node)):
            b = re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', node)
            if b:
                x1, y1, x2, y2 = map(int, b.groups())
                print((x1 + x2) // 2, (y1 + y2) // 2)
                sys.exit(0)
PY
)"
  [ -n "$xy" ] || return 1
  # shellcheck disable=SC2086
  "$ADB" shell input tap $xy > /dev/null 2>&1
}

PROBLEMS=0
"$ADB" shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 > /dev/null 2>&1
sleep 2
shot 00-opening
# Wait (up to 90 s) until the bottom bar is on screen: first launch on a software GPU is slow.
READY=0
for _ in $(seq 1 30); do
  "$ADB" shell uiautomator dump /sdcard/vx_ui.xml > /dev/null 2>&1 || true
  if "$ADB" exec-out cat /sdcard/vx_ui.xml 2> /dev/null | grep -q 'text="Shorts"'; then READY=1; break; fi
  sleep 3
done
sleep 2
shot 01-home
if ! alive; then
  say "FAILED: the app is not running after launch."
  PROBLEMS=$((PROBLEMS + 1))
elif [ "$READY" != 1 ]; then
  say "Note: the bottom bar was not seen within 90 s of launch."
fi

visit() { # <tab label> <file name>
  if tap_text "$1"; then
    sleep 4
    shot "$2"
    if alive; then say "- $1: opened"; else say "- $1: **app stopped**"; PROBLEMS=$((PROBLEMS + 1)); fi
  else
    say "- $1: not found on screen"
    PROBLEMS=$((PROBLEMS + 1))
  fi
}
say "Screens opened on the emulator (Pixel 6 profile, Android 14):"
visit "Music" 02-music
if tap_text "Vortex Test Tone"; then
  sleep 5
  shot 03-now-playing
  if alive; then say "- Now Playing (test tone): opened"; else say "- Now Playing: **app stopped**"; PROBLEMS=$((PROBLEMS + 1)); fi
  "$ADB" shell input keyevent 4 > /dev/null 2>&1
  sleep 2
else
  say "- Now Playing: test tone not listed (library scan may be late)"
fi
visit "Video" 04-video
visit "Shorts" 05-shorts
visit "You" 06-you
if tap_text "Audio Lab"; then
  sleep 4
  shot 07-audio-lab
  if alive; then say "- Audio Lab: opened"; else say "- Audio Lab: **app stopped**"; PROBLEMS=$((PROBLEMS + 1)); fi
  "$ADB" shell input keyevent 4 > /dev/null 2>&1
  sleep 2
fi
visit "Home" 08-home-again

"$ADB" logcat -d -v brief > "$OUT/logcat.txt" 2> /dev/null || true
CRASH="$(grep -n -E "FATAL EXCEPTION|ANR in $PKG" "$OUT/logcat.txt" | head -n 3 || true)"
if [ -n "$CRASH" ]; then
  say ""
  say "**Crash found in the log:**"
  grep -E -A 14 "FATAL EXCEPTION" "$OUT/logcat.txt" | head -n 40 > "$OUT/crash.txt" || true
  say '```'
  head -n 24 "$OUT/crash.txt" | tee -a "$REPORT"
  say '```'
  PROBLEMS=$((PROBLEMS + 1))
fi
# Keep the log small for the results branch.
tail -n 1500 "$OUT/logcat.txt" > "$OUT/logcat-tail.txt" 2> /dev/null || true
rm -f "$OUT/logcat.txt" "$OUT/ui.xml" "$OUT/sdkmanager.log"
say ""
say "Screenshots: $(ls "$OUT"/*.png 2>/dev/null | wc -l) in \`smoke/\` on the ci-results branch."
[ "$PROBLEMS" -eq 0 ]
