#!/usr/bin/env bash
# Publishes the built APK as a release asset in this (private) repository, so the owner can
# download one .apk file on the phone instead of an Actions artifact zip. It uses the
# workflow's own repository token (the one actions/checkout stored for this run); nothing is
# sent outside this repository.
#
# usage: ci-publish.sh <apk_file> <version_name> <version_code> <logs_dir>
set -euo pipefail

APK="${1:?apk file}"
VNAME="${2:?version name}"
VCODE="${3:?version code}"
LOGS="${4:?logs dir}"
WS="${GITHUB_WORKSPACE:?not running in GitHub Actions}"
REPO="${GITHUB_REPOSITORY:?}"

HDR="$(git -C "$WS" config --get http.https://github.com/.extraheader || true)"
TOKEN="$(printf '%s' "${HDR##* }" | base64 -d 2>/dev/null | cut -d: -f2- || true)"
if [ -z "$TOKEN" ]; then
  echo "::warning::No repository credential found; the APK stays an Actions artifact only."
  exit 1
fi

TAG="apk-${VNAME}-${GITHUB_RUN_ID:-0}-${GITHUB_RUN_ATTEMPT:-1}"
NAME="VortexX-${VNAME}.apk"
BODY="$(python3 - "$TAG" "$VNAME" "$VCODE" "${GITHUB_SHA:-}" <<'PY'
import json, sys
tag, vname, vcode, sha = sys.argv[1:5]
print(json.dumps({
    "tag_name": tag,
    "target_commitish": sha,
    "name": f"VORTEX X {vname} (versionCode {vcode})",
    "body": "Debug build from CI. Install it over the existing app; do not uninstall first.",
    "draft": False,
    "prerelease": False,
}))
PY
)"
api() { curl -fsS -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28" "$@"; }

RESP="$(api -X POST "https://api.github.com/repos/$REPO/releases" -d "$BODY")"
UPLOAD="$(printf '%s' "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["upload_url"].split("{")[0])')"
PAGE="$(printf '%s' "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["html_url"])')"
ASSET="$(api -X POST -H "Content-Type: application/vnd.android.package-archive" --data-binary @"$APK" "$UPLOAD?name=$NAME")"
URL="$(printf '%s' "$ASSET" | python3 -c 'import json,sys; print(json.load(sys.stdin)["browser_download_url"])')"
{
  echo "### Direct download"
  echo ""
  echo "APK file: $URL"
  echo ""
  echo "Release page: $PAGE"
  echo ""
} > "$LOGS/apk-download.md"
echo "Published $NAME -> $URL"
