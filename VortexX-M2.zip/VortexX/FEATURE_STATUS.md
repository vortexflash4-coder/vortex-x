# Feature status

Labels: **VERIFIED** (implemented and checked on the owner's phone) · **IMPLEMENTED, NOT VERIFIED** (in the build; CI compiled/tested where stated, not phone-checked) · **SOURCE-DEPENDENT** (needs a real source, account or licence) · **NOT IMPLEMENTED**.
No feature is VERIFIED yet: the A0 phone gate is open (PROJECT_STATE.md).

| Area | Feature | Status | Evidence |
|---|---|---|---|
| Library | MediaStore songs/videos, albums, artists, genres, folders, search, sort, live refresh | IMPLEMENTED, NOT VERIFIED | Phase 1 build; owner saw songs play |
| Library | Multi-select, grid view, folder include/exclude, playlist import/export | NOT IMPLEMENTED | M1/M2 |
| Playback | Media3 service, background, notification, headset buttons, focus, unplug pause | IMPLEMENTED, NOT VERIFIED | Phase 1 |
| Playback | Queue view/reorder/remove/save as playlist; shuffle/repeat; speed; sleep timer | IMPLEMENTED, NOT VERIFIED | Phase 1 |
| Playback | Queue persistence across process death | NOT IMPLEMENTED | M1 |
| Playback | Lyrics (local .lrc, synced highlight) | NOT IMPLEMENTED | M1/M2 |
| Audio Lab | Preamp, 10-band EQ, ramps, click-free bypass, clip counter, peak/RMS meters, DSP load | IMPLEMENTED, NOT VERIFIED | CI 68/68; DSP table 27/27 PASS |
| Audio Lab | Auto headroom from combined curve | IMPLEMENTED, NOT VERIFIED | EqResponseTest (10.85 dB peak; 0 clips with −10.9 dB) |
| Audio Lab | DSP / Battery mode, status from Media3's opened output, immediate bypass in Battery | IMPLEMENTED, NOT VERIFIED | DspStatusAndParametersTest |
| Audio Lab | Buffer size vs measured change-to-ear and output-start latency | IMPLEMENTED, NOT VERIFIED | LatencyTrackerTest; phone values pending |
| Audio Lab | Presets, A/B, compressor, limiter, width, balance, reverb | NOT IMPLEMENTED | M2 |
| Output | Studio / Balanced / Battery definitions, route presets | NOT IMPLEMENTED (DSP/Battery only) | M2 |
| Video | Grid, player, speed, tracks, Fit/Stretch/Crop, rotation lock, resume | IMPLEMENTED, NOT VERIFIED | Phase 1 |
| Video | PiP, lock, gestures, external subtitles, subtitle delay/style, chapters | NOT IMPLEMENTED | M2 |
| Shorts | Vertical feed of phone videos up to 3 min, like (stored), mute, share, open in player, Home shelf | IMPLEMENTED, NOT VERIFIED | 0.4.0-m2; M1ScreenLogicTest |
| Shorts | Online feed, uploads, comments | NOT IMPLEMENTED (needs a source/backend) | D17 |
| Decoders | FFmpeg pack: AC-3, E-AC-3, DTS, TrueHD, ALAC and more when the phone has no decoder | IMPLEMENTED, NOT VERIFIED (only if the CI summary shows the pack built) | D15; DecoderPackTest |
| Design | Montserrat font, opening animation, Home entrance motion, press feedback, hero zoom | IMPLEMENTED, NOT VERIFIED | 0.4.0-m2 |
| AI | Helper, on-device lyrics, karaoke (vocal removal) | NOT IMPLEMENTED | M2 step 3 |
| Online | User HTTPS URLs, open-licence sources (Jamendo, Audius, Internet Archive) | NOT IMPLEMENTED | M2 step 2 (D17) |
| Online | Downloaders for YouTube / Instagram / Spotify / Netflix | WILL NOT BE BUILT | D17 |
| Online | Commercial music/film catalogues | SOURCE-DEPENDENT | needs official API/SDK + agreement |
| Downloads | Media3 download queue, offline playback | NOT IMPLEMENTED | M3 |
| Design | Brand mark (vector), adaptive + themed launcher icon, Android 12 splash, tokens, type scale | IMPLEMENTED, NOT VERIFIED | M1 (0.3.0-m1) |
| Design | Custom bottom bar Home/Music/Video/Library/You (Downloads tab waits for downloads, D11), rail on wide screens, mini player with prev/play/next | IMPLEMENTED, NOT VERIFIED | M1 |
| Design | Home (greeting, featured newest album or now-playing deck, shelves), Music tabs, album hero, Video tabs + featured hero, Library, You hub | IMPLEMENTED, NOT VERIFIED | M1; M1ScreenLogicTest |
| Audio Lab | EQ curve drawn from the filter coefficients (Audio Lab, Now Playing, You) | IMPLEMENTED, NOT VERIFIED | EqResponseTest.drawnCurveIsFlatForFlatAndPeaksAtTheBoostedBand |
| Settings | Basic/Advanced/Pro/Developer, search, reset | IMPLEMENTED, NOT VERIFIED | Phase 1 |
| Settings | Searchable hub that opens the matching setting; appearance/gestures/backup | NOT IMPLEMENTED | M1/M2 |
| CI | assembleDebug, unit tests, androidTest compile, DSP table, results branch | IMPLEMENTED | runs #4, #5 |
| CI | APK package/version/signer read from the APK, pinned-certificate gate | IMPLEMENTED, NOT VERIFIED | A0r6 (ci-build.sh); pin added after gate check 0 |
| CI | Lint in phone workflow; instrumentation execution | NOT IMPLEMENTED | instrumentation: no emulator yet |
