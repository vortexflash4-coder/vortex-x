# Decisions

D1 (2026-11-12) — Canonical A0 source is the VortexX-A0r5 tree on `main`, not `a0/` on the Codex branch. Reason: it is the build the owner downloaded; it already contains the three fixes found in PR #1 (battery-mode bypass of a playing PCM stream, combined-curve auto headroom, 56 dp scrollable faders) plus bounded processor chunks, a float sample ceiling, latency readouts and 68 JVM tests. PR #1 stays open as review history; nothing from it is discarded.

D2 — Debug signer continuity follows the APK actually installed on the owner's phone. If it is build #4/#5 (versionName 0.2.0-a0), keep the Actions-cache key (`vortex-debug-key-v1`). If it is the Codex build (0.2.1-a0-review), switch CI to that branch's keystore. Decided once the owner reports the Settings footer (gate check 0). → 2026-11-12: footer shows 0.2.0-a0-debug, so the Actions-cache key is kept, backed up in the repository secret (task export-signing-key) and pinned in `.github/signing/expected-debug-cert-sha256.txt`; CI refuses to create a new key while the pin exists.

D3 — Next versionCode is at least 4 (both A0 lines used 2 and 3), so any later APK upgrades either installation.

D4 — No private keys in the repository or zips. The phone route keeps its key in the Actions cache with a weekly keep-alive run; Route B uses the secret `VORTEX_DEBUG_KEYSTORE_B64`. (The Codex branch contains a committed debug keystore; it is a debug key in a private repository and is not used for release.)

D5 — Navigation: Home | Music | Video | Downloads | You. Cinema lives inside Video; Settings is reached from You and contextual actions. The references disagree here; this is the canonical order.

D6 — Palette from the master prompt (#08090B, #14161A, #272A30, #F43F46, #F4F5F7, #969CA8) replaces the earlier #E71938 accent.

D7 — Online catalogues, films and "Vortex Library" are concept labels until a real authorized source is connected. Empty/unavailable states are shown instead of sample content.

D8 — Seek waveform appears only when computed from the decoded file; otherwise the plain progress track is used.

D9 — App size follows real features. No padding to reach ~360 MB; actual APK/installed sizes are reported.

D10 (2026-11-12) — M1 uses the platform sans font (ExtraBold for the wordmark). Montserrat could not be bundled: the font download host is blocked from the build container. Revisit when the font file can be added from the repository.

D11 (2026-11-12) — Bottom bar is Home | Music | Video | Library | You. "Library" (playlists, favourites, folders) stands where D5 has "Downloads", because downloads do not exist yet and a tab without a feature is not shown. It becomes Downloads when Media3 downloads are real (M3).

D12 (2026-11-12) — Owner override of the A0 gate: "Tum pahle pura degin app full working bano … not compromise" (2026-11-12). M1 (design) is built before the phone checks. The A0 checks stay open and are still recorded in PROJECT_STATE.md; nothing is marked VERIFIED without them.

D13 (2026-11-12) — Source builds: `.github/workflows/vortex-src.yml` (pasted by the owner) builds any `src/**` branch pushed as text, with the same pinned debug key (cache, else the backup secret; never a new key). `gradle-wrapper.jar` travels as base64 and `ci-build.sh` restores it. Zip upload to `main` keeps working.

D14 (2026-11-12) — Bottom bar is Home | Music | Video | Shorts | You (replaces D11). The owner asked for an Instagram-style short-video feed as a main feature. Playlists, favourites and folders open from You and from the Music header. Shorts shows the videos of up to three minutes that are on the phone; an online feed needs a real, authorized source (D17).

D15 (2026-11-12) — FFmpeg decoder pack: Media3's `decoder_ffmpeg` module (Apache 2.0) at the app's Media3 tag, linked with FFmpeg release/6.0 built without `--enable-gpl`/`--enable-nonfree` (LGPL-2.1-or-later), decoders vorbis opus flac alac pcm_mulaw pcm_alaw mp3 amrnb amrwb aac ac3 eac3 dca mlp truehd. CI fetches and builds it (`ci-ffmpeg.sh`) and caches the libraries in a `prebuilt/ffmpeg-*` branch; if it fails the APK is built without it and the summary says so. The phone's own decoders are always tried first. Before any store release: ship the LGPL notice and source offer (docs/THIRD_PARTY.md) and check Dolby/DTS patent licensing for the target countries.

D16 (2026-11-12) — Each green CI build is also attached to a release in this private repository (`ci-publish.sh`, workflow token, `contents: write`), so the owner downloads one .apk on the phone. Only builds whose signer matches the pin are published. Nothing is published outside the repository.

D17 (2026-11-12) — Online music, films and shorts come only from sources that allow it: user-provided URLs, open-licence catalogues (Jamendo, Audius, Internet Archive) through their APIs, and official embeds (YouTube IFrame player, no downloading). No downloaders for YouTube, Instagram, Spotify, Netflix or similar. A user-upload Shorts feed needs a backend, accounts and moderation and is planned last.

D10 update (2026-11-12) — Montserrat (SIL OFL 1.1) is now downloaded by CI (`ci-assets.sh`) into `assets/fonts` and loaded as a variable font; the platform sans remains the fallback when the file is missing.
