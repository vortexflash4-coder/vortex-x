// Optional FFmpeg audio decoder: Media3's decoder_ffmpeg module (Apache 2.0) linked against
// FFmpeg (LGPL-2.1-or-later). Its Java/JNI sources and the FFmpeg libraries are put in place by
// .github/scripts/ci-ffmpeg.sh; settings.gradle.kts includes this module only when that worked.
plugins {
    alias(libs.plugins.android.library)
}

val ndkVersionFile = file("ndk-version.txt")
val cmakeVersionFile = file("cmake-version.txt")

android {
    namespace = "androidx.media3.decoder.ffmpeg"
    compileSdk = 36
    if (ndkVersionFile.exists()) {
        ndkVersion = ndkVersionFile.readText().trim()
    }

    defaultConfig {
        minSdk = 26
        consumerProguardFiles("proguard-rules.txt")
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/jni/CMakeLists.txt")
            // An SDK CMake 3.x already on the build machine, when ci-ffmpeg.sh found one (else AGP's default).
            if (cmakeVersionFile.exists()) {
                version = cmakeVersionFile.readText().trim()
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.common)
    implementation(libs.androidx.media3.decoder)
    implementation(libs.androidx.annotation)
    compileOnly(libs.checker.qual)
    compileOnly(libs.errorprone.annotations)
    compileOnly(libs.kotlin.annotations.jvm)
}
