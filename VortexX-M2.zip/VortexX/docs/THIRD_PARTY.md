# Third-party components

| Component | Licence | How it is used |
|---|---|---|
| AndroidX, Jetpack Compose, Media3, Room, DataStore, Hilt, Kotlin, kotlinx | Apache 2.0 | Gradle dependencies |
| Media3 `decoder_ffmpeg` module (Java + JNI glue) | Apache 2.0 | Source fetched by CI from github.com/androidx/media at the app's Media3 tag; built as `:ffmpeg` |
| FFmpeg (libavcodec, libavutil, libswresample), release/6.0 | LGPL-2.1-or-later | Built by CI with Media3's `build_ffmpeg.sh`, audio decoders only, no `--enable-gpl`, no `--enable-nonfree`; statically linked into `libffmpegJNI.so` |
| Montserrat | SIL Open Font License 1.1 | Variable font downloaded by CI from github.com/google/fonts; `Montserrat-OFL.txt` is packaged next to it in `assets/fonts` |
| Material Icons (compose material-icons-extended) | Apache 2.0 | Icons |

## FFmpeg (LGPL) obligations before distributing outside the owner's own phones
- Show this notice in the app and state that the app uses FFmpeg under the LGPL.
- Provide the exact FFmpeg source (github.com/FFmpeg/FFmpeg, branch release/6.0) and the build script (`.github/scripts/ci-ffmpeg.sh`, Media3 `build_ffmpeg.sh`) so the library can be rebuilt and relinked.
- Decoding AC-3 / E-AC-3 / TrueHD (Dolby) and DTS can require patent licences for commercial distribution in some countries. Decide this before a store release; the pack can be left out by removing the `ffmpeg` folder (the app builds and runs without it).
