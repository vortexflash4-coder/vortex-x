# Changelog

## 0.4.0-m2 — 2026-11-12 — M2 step 1 (versionCode 6)

Status: **Written**; built by CI from a `src/*` overlay branch.

### Added
- Shorts tab: vertical feed of the phone's videos of up to three minutes; one shared player, tap to pause, double-tap to like, like/mute/share/open-in-player actions, progress line; likes stored in the favourites table (kind "video"). Home has a Shorts shelf that opens the feed at the chosen video.
- Opening animation (`IntroOverlay`): the mark's arms lock into the V, the aperture opens, the wordmark settles; tap to skip.
- Motion kit (`ui/designsystem/motion`): one-time staggered entrance, press scale, slow hero zoom, drifting header glow. Used on Home and shelf cards.
- Montserrat (OFL) downloaded by CI and used for all text and the wordmark; platform font as fallback.
- FFmpeg decoder pack (optional `:ffmpeg` module, Media3 decoder_ffmpeg + FFmpeg 6.0 LGPL build): AC-3, E-AC-3, DTS, TrueHD, ALAC and others for files the phone cannot decode; used by the music and video players after the phone's own decoders. Diagnostics lists, per format, whether the phone or the pack decodes it.
- CI: `ci-assets.sh`, `ci-ffmpeg.sh` (build + `prebuilt/ffmpeg-*` cache branch, automatic rebuild without the pack if it breaks the build), `ci-publish.sh` (direct .apk as a release asset in the private repository).

### Changed
- Bottom bar: Home | Music | Video | Shorts | You. Library (playlists, favourites, folders) opens from You and from the Music header.
- Tab links from Home and You switch tabs the way the bottom bar does.

## 0.3.0-m1 — 2026-11-12 — M1 design build (versionCode 5)

Status: **Written**; built by CI from branch `src/m1` (see PROJECT_STATE.md).

### Added
- Brand: `ic_vortex_mark` vector (two ribbon arms, play aperture), adaptive and themed launcher icon, notification icon, Android 12 splash; `VortexMark`, `VortexWordmark`, `BrandHeader`, `HeaderIconButton`, `SectionTitle`, `PlayCircleButton`, `MetaChip`, `ShelfCard`, `ProgressLine`, `UnderlineTabs`, `SongCover` / `VideoThumbnail` (generated cover when a file has no art).
- Navigation: custom bottom bar Home | Music | Video | Library | You with a red indicator, tab stays lit inside its detail screens; rail with the mark on wide screens; You hub (library summary, Audio Lab card with the EQ curve, tools, version).
- Home: clock greeting, newest album hero (or the now-playing deck), Shuffle all / Audio Lab, Continue watching, Recently added, Albums shelves, empty-library card.
- Music: brand header, underline tabs, generated covers in rows and the album grid; album/artist hero with a large cover.
- Video: tabs All / In progress / Cinema (40 min+ files on the phone), featured hero with Resume.
- Now Playing: Audio Lab strip with the live EQ curve; the A1 player parts (swipeable artwork, slim seek bar, signal chips, up next).
- `EqResponse.curveDb` (curve from the same coefficients as the audio thread) and its test; `M1ScreenLogicTest`; `DisplayAndFormatLabelsTest`, `NowPlayingLogicTest`.

### Changed
- Palette and type scale follow docs/design/DESIGN_SYSTEM.md (#08090B, #14161A, #272A30, #F43F46, #F4F5F7, #969CA8; hero 30 sp, section 21 sp, body 16 sp).
- Titles: file-name titles lose extensions and underscores (`DisplayText`).
- CI: `ci-build.sh` restores `gradle-wrapper.jar` from base64 for text-only source branches.

## 0.2.0-a0 revision 2 — 2026-11-11 — final A0 order

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Added
- `audio/engine/PlaybackEngine`: builds the music ExoPlayer (renderers with the VORTEX X processor, attributes, analytics), applies DSP or battery-offload mode, exposes `status` decided from Media3's opened output, and `latency`.
- `audio/engine/LatencyTracker`: change-to-ear delay (processor head − playback position ÷ speed, median of 9) and output start latency (Media3 playout start − play start), with 0–5000 ms plausibility and a rejected count.
- `VortexAudioProcessor` overrides `onFlush(StreamMetadata)` (Media3 1.11) and reports the stream position of the last processed sample.
- DSP measurement lines in the JVM tests and a **DSP measurements** table on the CI Summary page. New tests: `LatencyTrackerTest` (7), `processingSpeedOnCiMachine`, two processor position tests.
- `.github/scripts/ci-build.sh`: Gradle steps run from the zip, so the phone workflow file rarely needs editing.
- `create-signing-key` task in `docs/phone-build/build-from-zip.yml`, and `.github/workflows/create-debug-key.yml` for Route B.
- Package A0r7 (same app as A0r6): direct-buffer check reads BufferPoolMXBean by reflection (java.lang.management is not on the Android unit-test classpath, so A0r6's tests did not compile); APK identity parses the package from the `package:` line; certificate pin file added (`.github/signing/expected-debug-cert-sha256.txt`).
- Package A0r6 (versionCode 4, 0.2.2-a0): allocation gate restored to every round < 1024 bytes after 20 000 warm-up buffers, with per-block location and direct-buffer growth; CI reads package, version and signer SHA-256 from the built APK and fails on a pinned-certificate mismatch; design-milestone records (PROJECT_STATE, FEATURE_STATUS, DECISIONS, docs/design, settings inventory, sources).
- Package A0r5: first CI run (build #3, A0r4) compiled the app and both test sources; 67 of 68 unit tests passed. The processor allocation test measured exactly 1024 bytes once over 5000 buffers; it now measures three rounds and gates on the lowest, reporting all three. Phone signing moved to a key kept in the Actions cache (no manual secret).
- Package A0r4: three issues found by the draft review in PR #1, fixed here: battery mode now bypasses a stream that is already playing as PCM (20 ms fade, status "Off: battery mode"); Auto headroom uses the combined EQ curve (`EqResponse`), because neighbouring boosts add up; EQ faders are at least 56 dp wide and scroll sideways. The processor also works in bounded 1024-frame chunks with a buffer allocated once, clamps float output to full scale, and has its own allocation test.
- Package A0r3: the phone workflow is shortened to one job (it can be opened as a pre-filled GitHub "new file" link), and `ci-build.sh` decodes the signing secret itself (temporary folder, deleted on exit).

### Changed
- Signing: the committed `app/vortex-debug.keystore` is removed. Debug builds are signed with the key from the secret `VORTEX_DEBUG_KEYSTORE_B64`, decoded to the runner's temporary folder and deleted after the build. The Summary says whether the key was fixed or temporary.
- Audio Lab: "Output buffer" is now "Output buffer size … capacity (not latency)", followed by the two measured delays.
- `PlaybackService` uses `PlaybackEngine` instead of building the player itself.
- Media3 is standardised on 1.11.1 in the version catalog and every doc.

## 0.2.0-a0 — 2026-11-11 — Stage A0: Media3 1.11.1 and DSP proof

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Added
- `audio/dsp/`: `DspChain` (preamp, 10 peaking filters at ISO octave centres, gain ramps of 0.25 dB per 32 frames, 20 ms bypass crossfade, clip counter), `BiquadCoefficients` (RBJ cookbook), `DspParameters`, lock-free `MeterBus` and `LoadMeter`, `DspHost`.
- `audio/media3/`: `VortexAudioProcessor` (16-bit and float PCM, 1–8 channels), `VortexRenderersFactory` (adds it to `DefaultAudioSink`), `AudioEncodings`.
- `audio/engine/`: `AudioEngine` (settings, persistence, DSP/battery mode), `AudioDiagnostics` (Media3 analytics + audio-device callback), `DspStatusResolver`.
- Audio Lab A0 screen (replaces the Audio Studio report): status, stereo peak/RMS meters with clip light, bypass, output mode, preamp, 10 faders, signal path, device report.
- Instrument controls: `EqFader`, `PrecisionSlider`, `StereoLevelMeter`, `SegmentedSelector`, `StatusLed`, `ReadoutGrid`.
- (Replaced in revision 2) a committed debug keystore and its signing config.
- JVM tests: `DspChainTest` (13), `VortexAudioProcessorTest` (7), `DspStatusAndParametersTest` (5).
- `docs/STAGE_A0.md`.

### Changed
- Media3 upgraded to 1.11.1.
- `PlaybackService` builds the player with `VortexRenderersFactory`, attaches the diagnostics listener, tracks routes and applies the offload preference.
- Settings: the search field is the list's first item; the top bar shows "Detail level: …" and the level's description sits under the level chips; "Reset to defaults" no longer clears Audio Lab values.
- Top bar subtitles wrap to two lines. Navigation keeps clear of side display cutouts. List screens are width-capped and centred on tablets.
- Theme: true black background (#000000) and darker surfaces.
- Version 0.1.0-phase1 → 0.2.0-a0 (versionCode 2).

## 2026-11-11 — Phase 1 review pass

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Changed
- `.github/workflows/android-ci.yml`: every Gradle step now writes its full log to `ci-logs/`. The run always ends with a job summary and a logs artifact, even when the build fails. The run is still marked failed when `assembleDebug`, `testDebugUnitTest` or `assembleDebugAndroidTest` fails. Unit tests and the instrumentation-test compile run only after the APK builds, so the Errors box shows the first real failure.
- Artifacts: `vortex-x-debug-apk` (unchanged). `vortex-x-logs-and-reports` replaces `vortex-x-reports` and now also contains the Gradle logs.
- `feature/music/CollectionScreen.kt`: `SongActionsHost` is called directly instead of inside an empty `Box` (no behaviour change; removed unused import).
- `README.md`: phone-only build instructions now cover the zip-upload route.

### Added
- `.github/scripts/ci-summary.sh`: job summary with "APK built" (name + size) or "APK was not built", unit-test counts with failed test names, and an Errors box trimmed to `file:line`. Up to 10 errors also appear as annotations on the run page.
- `docs/phone-build/build-from-zip.yml`: workflow for a repository that contains only the project ZIP. Uploading the ZIP from a phone browser builds the APK with the same checks and summary.
- `docs/BUILD_STATUS.md`, `docs/CHANGELOG.md`.

### Static review result
No definite compile error found in the 57 Kotlin files, the manifest or the resources. This does not prove the project compiles; the first CI run decides.
