# Build status — VORTEX X

Last updated: 2026-11-11 (Stage A0 revision 2 written)

## Evidence levels

| Level | Meaning |
|---|---|
| **Written** | The code exists in this repository. |
| **Compiled** | A green GitHub Actions run built it (`assembleDebug`). |
| **Unit-tested** | JVM tests for it passed in CI (`testDebugUnitTest`). |
| **Device-tested** | The owner confirmed it on a real phone. |

## Stage A0 (version 0.2.0-a0)

### CI evidence

| Run | Package | assembleDebug | Unit tests | assembleDebugAndroidTest | Notes |
|---|---|---|---|---|---|
| VORTEX X build #3, 2026-11-12 | VortexX-A0r4.zip | ✅ | 67 of 68 passed | ✅ | Failed: processor allocation gate measured exactly 1024 bytes over 5000 buffers (limit < 1024). Every DSP measurement passed. APK 22.7 MB, temporary signing key. |
| VORTEX X build after A0r5 upload, 2026-11-12 | VortexX-A0r5.zip | ✅ | **68 of 68 passed** | ✅ | Processor allocation rounds 1184 / 0 / 0 bytes (one-off JVM allocation in round 1 only). All 27 DSP measurement rows PASS. APK 22.7 MB, signed with the new CI key kept in the Actions cache. |

### Package VortexX-A0r5.zip

Media3 1.11.1, PlaybackEngine, DSP proof (preamp, 10-band EQ, meters, bypass, clip detection), playback-mode reporting, buffer size kept apart from two measured delays, Audio Lab A0 screen, CI DSP measurement table, signing key from a GitHub secret, UI fixes. Details and the device checklist: `docs/STAGE_A0.md`.

Unit tests: 68 (28 Phase 1 + 40 A0). A0r5 compiled and all 68 JVM tests passed in CI: every A0 row below is **Compiled** and its JVM tests **Unit-tested**. Device-tested stays No until the phone checklist is done.

| Feature | Written | Compiled | Unit-tested | Device-tested |
|---|---|---|---|---|
| Media3 1.11.1 migration | Yes | Yes (build #3) | — | No |
| PlaybackEngine (player build, DSP/offload mode, status from Media3's opened output) | Yes | No | Status rules: 5 JVM tests written, not run | No |
| DSP chain (preamp, 10-band EQ, ramps, bypass, clip counter, meters, load) | Yes | No | 14 JVM tests written, not run | No |
| VortexAudioProcessor in DefaultAudioSink (bounded chunks, float ceiling, processed position) | Yes | No | 10 JVM tests written, not run | No |
| Auto headroom from the combined EQ curve | Yes | No | 4 JVM tests written, not run | No |
| Battery mode bypasses a playing PCM stream | Yes | No | Status rule tested; bypass ramp covered by DSP tests | No |
| Buffer size vs measured change-to-ear delay and output start latency | Yes | No | LatencyTracker: 7 JVM tests written, not run | No |
| Route tracking, underruns, decoder and format readouts | Yes | No | — | No |
| Audio Lab A0 screen | Yes | No | — | No |
| CI: build script in the zip, DSP measurement table, signing status | Yes | No (scripts run locally on sample data only) | — | — |
| Debug signing key from the `VORTEX_DEBUG_KEYSTORE_B64` secret (none in the repo) | Yes | No | — | No |
| Settings search in list, wrapped subtitles, cutout insets, OLED black | Yes | No | — | No |

## Phase 1 — first CI run

**First CI run green — 2026-11-11.** Repository `vortexflash4-coder/vortex-x` (private), workflow `build-from-zip.yml`, commit `949e9e2`, built from `VortexX-phase1-reviewed.zip`.

| Check | Result |
|---|---|
| `assembleDebug` | success — `app-debug.apk` 22.4 MB (artifact zip 21.5 MB) |
| `testDebugUnitTest` | success — 28 tests, 28 passed, 0 failed, 0 skipped |
| `assembleDebugAndroidTest` | success (compiled only; instrumented tests not run) |
| Lint | not run in the zip workflow |
| Errors | none |

Run annotations (warnings, not failures): Node.js 20 deprecation for the actions used, `setup-java@v4` deprecation, and `ubuntu-latest` moving to Ubuntu 26 from 2026-10-19. Action versions to be updated after checking the current releases.

| Feature | Written | Compiled | Unit-tested | Device-tested |
|---|---|---|---|---|
| Design system (tokens, components, previews) | Yes | Yes | — | No |
| Navigation (bottom bar / rail, 12 destinations) | Yes | Yes | — | Partial: bottom bar + Settings seen (2026-11-11) |
| Media permissions + first-launch screen | Yes | Yes | — | Partial: access granted, library readable (2026-11-11) |
| Music library (MediaStore, search, sort, grouping) | Yes | Yes | Yes (`LibraryLogicTest`) | Partial: a local song played from the library (2026-11-11) |
| Background playback (MediaSessionService, notification, focus, noisy) | Yes | Yes | — | Partial: plays in app with mini player; lock screen / notification / headset not yet checked |
| Queue (jump, reorder, remove, clear, save) | Yes | Yes | — | No |
| Playlists and favourites (Room) | Yes | Yes | Instrumented tests compiled, not run (`VortexDatabaseTest`) | No |
| Video player (PlayerView, scaling, rotation lock, resume) | Yes | Yes | Resume rules: Yes (`PoliciesAndFormatTest`) | No |
| Media Explorer (folders, open file via picker) | Yes | Yes | Folder merge: Yes | No |
| Audio Studio (capability report only; replaced by Audio Lab in A0) | Yes | Yes | — | No |
| Diagnostics (decoders, outputs, spatializer, HDR) | Yes | Yes | — | No |
| Settings (4 levels, search, reset) | Yes | Yes | Yes (`SettingsTest`) | Partial: Pro level and its toggles shown (2026-11-11) |
| Playback error explanations | Yes | Yes | Yes | No |
| CI job summary (APK built/not built, test counts, Errors box) | Yes | Yes | Worked in the real run | — |

## Next

- APK installed on the owner's phone on 2026-11-11 and runs. Finish "Device-tested" from `docs/TESTING.md` (manual table).
- Instrumented tests (`VortexDatabaseTest`, `PlaybackEngineTest`, `AppNavigationTest`) are compiled but have not run on a device or emulator.
