package com.vortexx.player

import com.vortexx.player.audio.dsp.DspHost
import com.vortexx.player.audio.engine.LatencyTracker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The arithmetic behind the Lab's two measured delays, kept apart from buffer size. */
class LatencyTrackerTest {

    @Test
    fun outputStartIsPlayoutMinusPlayStart() {
        val tracker = LatencyTracker()
        assertNull(tracker.readings.outputStartMs)
        tracker.onPlaybackStarted(nowWallMs = 10_000L)
        assertTrue(tracker.onPlayoutStarted(playoutStartWallMs = 10_087L))
        assertEquals(87L, tracker.readings.outputStartMs)
        assertEquals(1, tracker.readings.outputStartSamples)
    }

    @Test
    fun playoutWithoutAFreshStartIsIgnored() {
        // After a seek Media3 reports playout again, but no new play started: not a start latency.
        val tracker = LatencyTracker()
        tracker.onPlaybackStarted(1_000L)
        tracker.onPlayoutStarted(1_050L)
        assertFalse(tracker.onPlayoutStarted(9_000L))
        assertEquals(50L, tracker.readings.outputStartMs)

        tracker.onPlaybackStarted(20_000L)
        tracker.onPlaybackStopped()
        assertFalse(tracker.onPlayoutStarted(20_040L))
        assertEquals(50L, tracker.readings.outputStartMs)
    }

    @Test
    fun implausibleValuesAreRejectedNotShown() {
        val tracker = LatencyTracker()
        tracker.onPlaybackStarted(1_000L)
        assertFalse(tracker.onPlayoutStarted(900L)) // playout before play: clock mismatch
        tracker.onPlaybackStarted(1_000L)
        assertFalse(tracker.onPlayoutStarted(1_000L + LatencyTracker.MAX_PLAUSIBLE_MS + 1))
        assertNull(tracker.readings.outputStartMs)
        assertEquals(2, tracker.readings.rejectedSamples)
    }

    @Test
    fun changeToEarIsProcessorHeadMinusPlaybackPosition() {
        val tracker = LatencyTracker()
        // Processor has finished up to 12.480 s; the listener hears 12.300 s.
        assertTrue(tracker.onPositionSample(processedPositionUs = 12_480_000L, playbackPositionMs = 12_300L, speed = 1f))
        assertEquals(180L, tracker.readings.changeToEarMs)
        // At 2× speed the same media distance passes in half the time.
        val fast = LatencyTracker()
        fast.onPositionSample(12_480_000L, 12_300L, 2f)
        assertEquals(90L, fast.readings.changeToEarMs)
        val ms = tracker.readings.changeToEarMs
        DspMeasure.record("Change-to-ear arithmetic: head 12.480 s, heard 12.300 s, 1×", "$ms ms", "180 ms", ms == 180L)
    }

    @Test
    fun changeToEarUsesMedianOfRecentSamples() {
        val tracker = LatencyTracker()
        val samples = longArrayOf(200, 210, 190, 4_000, 205) // one outlier inside the plausible range
        for (ms in samples) tracker.onPositionSample(10_000_000L + ms * 1_000L, 10_000L, 1f)
        assertEquals(205L, tracker.readings.changeToEarMs)
        assertEquals(5, tracker.readings.changeToEarSamples)
    }

    @Test
    fun trackChangeSamplesAreRejected() {
        val tracker = LatencyTracker()
        // Processor already in the next song (0.2 s) while the player still reports the old one (240 s).
        assertFalse(tracker.onPositionSample(200_000L, 240_000L, 1f))
        // Processor position not known (DSP inactive).
        assertFalse(tracker.onPositionSample(DspHost.UNKNOWN_POSITION_US, 1_000L, 1f))
        assertNull(tracker.readings.changeToEarMs)
        assertEquals(1, tracker.readings.rejectedSamples)
    }

    @Test
    fun newOutputRestartsTheWindow() {
        val tracker = LatencyTracker()
        tracker.onPositionSample(1_300_000L, 1_000L, 1f)
        tracker.clearWindow()
        assertNull(tracker.readings.changeToEarMs)
        tracker.onPositionSample(1_040_000L, 1_000L, 1f)
        assertEquals(40L, tracker.readings.changeToEarMs)
    }
}
