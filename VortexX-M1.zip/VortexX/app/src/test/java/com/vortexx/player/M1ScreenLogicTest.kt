package com.vortexx.player

import com.vortexx.player.domain.model.Video
import com.vortexx.player.feature.home.greetingFor
import com.vortexx.player.feature.video.CINEMA_MIN_DURATION_MS
import com.vortexx.player.feature.video.VideoItemUi
import com.vortexx.player.feature.video.VideoTab
import com.vortexx.player.feature.video.videosForTab
import org.junit.Assert.assertEquals
import org.junit.Test

/** Rules behind the M1 screens: the Home greeting and the Video tabs. */
class M1ScreenLogicTest {

    @Test
    fun greetingFollowsThePhoneClock() {
        assertEquals("Late night", greetingFor(0))
        assertEquals("Late night", greetingFor(4))
        assertEquals("Good morning", greetingFor(5))
        assertEquals("Good morning", greetingFor(11))
        assertEquals("Good afternoon", greetingFor(12))
        assertEquals("Good afternoon", greetingFor(16))
        assertEquals("Good evening", greetingFor(17))
        assertEquals("Good evening", greetingFor(21))
        assertEquals("Late night", greetingFor(22))
        assertEquals("Late night", greetingFor(23))
    }

    private fun video(id: Long, durationMs: Long) = Video(
        id = id,
        contentUri = "content://media/external/video/media/$id",
        title = "Video $id",
        displayName = "video_$id.mp4",
        durationMs = durationMs,
        sizeBytes = 1_000L,
        dateAddedSec = id,
        mimeType = "video/mp4",
        width = 1920,
        height = 1080,
        folder = "/storage/emulated/0/Movies",
    )

    @Test
    fun videoTabsFilterWithoutReordering() {
        val short = VideoItemUi(video(1, 5 * 60_000L), watchedFraction = null)
        val longInProgress = VideoItemUi(video(2, CINEMA_MIN_DURATION_MS), watchedFraction = 0.4f)
        val shortInProgress = VideoItemUi(video(3, 10 * 60_000L), watchedFraction = 0.1f)
        val film = VideoItemUi(video(4, 2 * 60 * 60_000L), watchedFraction = null)
        val all = listOf(short, longInProgress, shortInProgress, film)

        assertEquals(all, videosForTab(all, VideoTab.All))
        assertEquals(listOf(longInProgress, shortInProgress), videosForTab(all, VideoTab.InProgress))
        assertEquals(listOf(longInProgress, film), videosForTab(all, VideoTab.Cinema))
        assertEquals(emptyList<VideoItemUi>(), videosForTab(emptyList(), VideoTab.Cinema))
    }
}
