package com.vortexx.player

import com.vortexx.player.audio.engine.RouteInfo
import com.vortexx.player.feature.nowplaying.routeLine
import com.vortexx.player.feature.nowplaying.upNext
import com.vortexx.player.playback.PlaybackUiState
import com.vortexx.player.playback.QueueEntry
import com.vortexx.player.playback.RepeatSetting
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** "Up next" and the route chip must never show something that is not true. */
class NowPlayingLogicTest {

    private val queue = (0 until 3).map { QueueEntry(index = it, mediaId = "song:$it", songId = it.toLong(), title = "Song $it", artist = "A", contentUri = null) }

    @Test
    fun upNextFollowsQueueOrder() {
        assertEquals("Song 1", upNext(PlaybackUiState(queue = queue, currentIndex = 0))?.title)
        assertNull(upNext(PlaybackUiState(queue = queue, currentIndex = 2)))
        assertEquals("Song 0", upNext(PlaybackUiState(queue = queue, currentIndex = 2, repeat = RepeatSetting.All))?.title)
    }

    @Test
    fun upNextIsUnknownWhenShuffledOrRepeatingOne() {
        assertNull(upNext(PlaybackUiState(queue = queue, currentIndex = 0, shuffleEnabled = true)))
        assertNull(upNext(PlaybackUiState(queue = queue, currentIndex = 0, repeat = RepeatSetting.One)))
        assertNull(upNext(PlaybackUiState()))
    }

    @Test
    fun routeLineSaysWhenItIsAGuess() {
        assertEquals("Bluetooth · Galaxy Buds2", routeLine(RouteInfo("Bluetooth", "Galaxy Buds2", exact = true, sampleRates = emptyList(), encodings = emptyList())))
        assertEquals("Speaker (estimated)", routeLine(RouteInfo("Speaker", "speaker", exact = false, sampleRates = emptyList(), encodings = emptyList())))
        assertNull(routeLine(null))
    }
}
