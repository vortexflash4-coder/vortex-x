package com.vortexx.player

import java.util.Locale

/**
 * Prints one measured DSP result per line. Gradle stores test output in the
 * JUnit XML reports; CI (.github/scripts/ci-summary.sh) turns these lines into
 * the "DSP measurements" table on the run's Summary page. Values are printed
 * before the assertion that judges them, so a failing run still shows them.
 */
object DspMeasure {
    fun record(metric: String, value: String, limit: String, pass: Boolean) {
        println("DSP-MEASURE|$metric|$value|$limit|${if (pass) "PASS" else "FAIL"}")
    }

    fun f(value: Double, decimals: Int = 2): String = String.format(Locale.ROOT, "%.${decimals}f", value)
}
