package com.vortexx.player

import com.vortexx.player.audio.dsp.DspChain
import com.vortexx.player.audio.dsp.DspParameters
import com.vortexx.player.audio.dsp.EqResponse
import com.vortexx.player.audio.dsp.GraphicEqBands
import com.vortexx.player.audio.dsp.MeterBus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Auto headroom must cover the combined EQ curve, where neighbouring bands overlap. */
class EqResponseTest {

    private fun bands(vararg pairs: Pair<Int, Float>): List<Float> {
        val list = MutableList(GraphicEqBands.COUNT) { 0f }
        for ((band, gain) in pairs) list[band] = gain
        return list
    }

    private fun clippedSamples(gains: List<Float>, preampDb: Float, frequency: Double, amplitude: Double): Int {
        val chain = DspChain(MeterBus())
        chain.configure(48_000, 1)
        chain.apply(DspParameters(preampDb = preampDb, bandGainsDb = gains))
        val frames = 48_000
        val buffer = FloatArray(frames) { (amplitude * sin(2 * PI * frequency * it / 48_000)).toFloat() }
        return chain.process(buffer, frames)
    }

    @Test
    fun drawnCurveIsFlatForFlatAndPeaksAtTheBoostedBand() {
        assertTrue(EqResponse.curveDb(DspParameters.FLAT).all { it == 0f })
        val curve = EqResponse.curveDb(bands(5 to 6f), points = 200)
        val max = curve.maxOrNull()!!
        assertEquals(6.0, max.toDouble(), 0.3)
        // The highest point sits near 1 kHz on the 20 Hz to 20 kHz log grid.
        val frequency = 20.0 * Math.pow(20_000.0 / 20.0, curve.indexOfFirst { it == max } / 199.0)
        assertTrue("peak at $frequency Hz", frequency in 800.0..1_250.0)
        assertTrue(curve.first() < 0.5f && curve.last() < 0.5f)
    }

    @Test
    fun flatAndCutOnlyCurvesNeedNoHeadroom() {
        assertEquals(0f, EqResponse.autoPreampDb(DspParameters.FLAT))
        assertEquals(0f, EqResponse.autoPreampDb(bands(2 to -6f, 7 to -12f)))
    }

    @Test
    fun singleBandPeakIsItsOwnGain() {
        val peak = EqResponse.peak(bands(1 to 12f))
        DspMeasure.record("EQ curve peak, one band +12 dB", "${DspMeasure.f(peak.gainDb, 3)} dB at ${DspMeasure.f(peak.frequencyHz, 1)} Hz", "12 ± 0.05 dB", abs(peak.gainDb - 12.0) <= 0.05)
        assertEquals(12.0, peak.gainDb, 0.05)
        assertEquals(-12f, EqResponse.autoPreampDb(bands(1 to 12f)))
    }

    @Test
    fun overlappingBoostsNeedMoreThanTheLargestBand() {
        // 125 Hz and 250 Hz both +9 dB: the curve rises above 9 dB (about 10.8 dB near 129 Hz).
        val gains = bands(2 to 9f, 3 to 9f)
        val peak = EqResponse.peak(gains)
        val auto = EqResponse.autoPreampDb(gains)
        DspMeasure.record("EQ curve peak, 125 + 250 Hz both +9 dB", "${DspMeasure.f(peak.gainDb, 3)} dB at ${DspMeasure.f(peak.frequencyHz, 1)} Hz", "> 9 dB (bands overlap)", peak.gainDb > 9.5)
        assertTrue("combined peak ${peak.gainDb}", peak.gainDb > 9.5)
        assertTrue(auto <= -peak.gainDb.toFloat())

        val oldHeadroom = clippedSamples(gains, -9f, peak.frequencyHz, 0.9)
        val newHeadroom = clippedSamples(gains, auto, peak.frequencyHz, 0.9)
        DspMeasure.record("0.9 FS sine at the curve peak, preamp −9 dB (largest band only)", "$oldHeadroom clipped of 48000", "> 0 (old estimate too small)", oldHeadroom > 0)
        DspMeasure.record("Same signal, Auto headroom ${DspMeasure.f(auto.toDouble(), 1)} dB (combined curve)", "$newHeadroom clipped of 48000", "0", newHeadroom == 0)
        assertTrue(oldHeadroom > 0)
        assertEquals(0, newHeadroom)
    }

    @Test
    fun curvesAboveTwelveDbAreLimitedToTheMinusTwelvePreamp() {
        assertEquals(-GraphicEqBands.MAX_PREAMP_DB, EqResponse.autoPreampDb(List(GraphicEqBands.COUNT) { 12f }))
    }
}
