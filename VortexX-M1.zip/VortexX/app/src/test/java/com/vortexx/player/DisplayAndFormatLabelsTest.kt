package com.vortexx.player

import com.vortexx.player.audio.engine.AudioFormatLabels
import com.vortexx.player.audio.engine.InputStreamInfo
import com.vortexx.player.domain.library.DisplayText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DisplayAndFormatLabelsTest {

    @Test
    fun fileNameTitlesBecomeReadable() {
        assertEquals("Sheesha Chahe Toot Bhi Jaaye JHANKAR HD 1", DisplayText.title("Sheesha_Chahe_Toot_Bhi_Jaaye_JHANKAR_HD_1"))
        assertEquals("My Song", DisplayText.title("My_Song.mp3"))
        assertEquals("Track 01", DisplayText.title("  Track__01.flac "))
    }

    @Test
    fun realTitlesAreLeftAlone() {
        assertEquals("Tum Hi Ho", DisplayText.title("Tum Hi Ho"))
        assertEquals("Dr. Dre - Still D.R.E.", DisplayText.title("Dr. Dre - Still D.R.E."))
        // One underscore in a title with more spaces is kept.
        assertEquals("Live at the Hall vol_2 encore", DisplayText.title("Live at the Hall vol_2 encore"))
        assertEquals("___", DisplayText.title("___"))
    }

    @Test
    fun formatLabelsDescribeOnlyWhatWasReported() {
        val flac = InputStreamInfo(mimeType = "audio/flac", codecs = null, sampleRate = 44_100, channelCount = 2, bitrate = 905_000)
        assertEquals("FLAC · 44.1 kHz · Stereo · 905 kbps", AudioFormatLabels.describe(flac))
        val mp3 = InputStreamInfo(mimeType = "audio/mpeg", codecs = null, sampleRate = 48_000, channelCount = 2, bitrate = -1)
        assertEquals("MP3 · 48 kHz · Stereo", AudioFormatLabels.describe(mp3))
        assertEquals("Dolby Digital Plus JOC", AudioFormatLabels.codec("audio/eac3-joc"))
        assertNull(AudioFormatLabels.describe(InputStreamInfo(null, null, -1, -1, -1)))
        assertNull(AudioFormatLabels.describe(null))
    }
}
