package com.vortexx.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.util.EventLogger
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.vortexx.player.MainActivity
import com.vortexx.player.R
import com.vortexx.player.audio.engine.PlaybackEngine
import com.vortexx.player.data.settings.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Hosts the music ExoPlayer inside a MediaSession. Media3 provides the media
 * notification, lock-screen controls, Bluetooth/headset media buttons and
 * foreground-service handling from this session.
 */
@AndroidEntryPoint
class PlaybackService : MediaSessionService() {

    @Inject lateinit var sleepTimer: SleepTimer
    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var playbackEngine: PlaybackEngine

    private var mediaSession: MediaSession? = null
    private var eventLogger: EventLogger? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @androidx.annotation.OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        // The engine builds the player: Media3 renderers with the VORTEX X processor in the PCM chain.
        val player = playbackEngine.createMusicPlayer()
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivity())
            .setCallback(SessionCallback())
            .build()
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this).build().apply {
                setSmallIcon(R.drawable.ic_stat_vortex)
            },
        )
        playbackEngine.bind(player, serviceScope)
        observeSettings(player)
        observeSleepTimer(player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    /** Keep playing after the task is swiped away only if something is actually playing. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 ||
            player.playbackState == Player.STATE_ENDED
        ) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        playbackEngine.unbind()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        eventLogger = null
        super.onDestroy()
    }

    private fun sessionActivity(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_OPEN_NOW_PLAYING, true)
        return PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    private fun observeSettings(player: ExoPlayer) {
        serviceScope.launch {
            settingsRepository.settings.collect { settings ->
                player.setSkipSilenceEnabled(settings.skipSilence)
                player.setHandleAudioBecomingNoisy(settings.pauseOnHeadphonesDisconnect)
                updateEventLogging(player, settings.verbosePlaybackLogging)
            }
        }
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    private fun updateEventLogging(player: ExoPlayer, enabled: Boolean) {
        val current = eventLogger
        if (enabled && current == null) {
            val logger = EventLogger(LOG_TAG)
            player.addAnalyticsListener(logger)
            eventLogger = logger
        } else if (!enabled && current != null) {
            player.removeAnalyticsListener(current)
            eventLogger = null
        }
    }

    private fun observeSleepTimer(player: Player) {
        serviceScope.launch {
            sleepTimer.deadlineElapsedMs.collectLatest { deadline ->
                if (deadline == null) return@collectLatest
                val remaining = deadline - SystemClock.elapsedRealtime()
                if (remaining > 0) delay(remaining)
                player.pause()
                sleepTimer.cancel()
            }
        }
    }

    private class SessionCallback : MediaSession.Callback {
        /** Restores the playable URI that controllers send in RequestMetadata. */
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val uri = item.requestMetadata.mediaUri ?: item.localConfiguration?.uri
                if (uri != null) item.buildUpon().setUri(uri).build() else item
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }

    companion object {
        const val LOG_TAG = "VortexAudio"
    }
}
