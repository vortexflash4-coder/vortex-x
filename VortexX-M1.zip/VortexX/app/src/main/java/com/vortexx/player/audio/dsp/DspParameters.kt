package com.vortexx.player.audio.dsp

/**
 * One immutable snapshot of the user's DSP settings. The UI publishes a new
 * instance per change; the audio thread compares references once per buffer.
 */
data class DspParameters(
    val enabled: Boolean = true,
    val preampDb: Float = 0f,
    val bandGainsDb: List<Float> = FLAT,
) {
    init {
        require(bandGainsDb.size == GraphicEqBands.COUNT) { "Expected ${GraphicEqBands.COUNT} bands" }
    }

    val isFlat: Boolean get() = preampDb == 0f && bandGainsDb.all { it == 0f }

    /** Highest positive boost of any band, used to suggest headroom. */
    val maxBoostDb: Float get() = bandGainsDb.maxOrNull()?.coerceAtLeast(0f) ?: 0f

    fun withBand(index: Int, gainDb: Float): DspParameters =
        copy(bandGainsDb = bandGainsDb.mapIndexed { i, g -> if (i == index) clampGain(gainDb) else g })

    fun withPreamp(gainDb: Float): DspParameters = copy(preampDb = clampPreamp(gainDb))

    companion object {
        val FLAT: List<Float> = List(GraphicEqBands.COUNT) { 0f }

        fun clampGain(db: Float): Float = roundTenth(db.coerceIn(-GraphicEqBands.MAX_GAIN_DB, GraphicEqBands.MAX_GAIN_DB))

        fun clampPreamp(db: Float): Float = roundTenth(db.coerceIn(-GraphicEqBands.MAX_PREAMP_DB, GraphicEqBands.MAX_PREAMP_DB))

        /** 0.1 dB resolution keeps stored values readable and comparisons exact. */
        private fun roundTenth(db: Float): Float = Math.round(db * 10f) / 10f

        /** Parses "g1,g2,…" as stored in preferences; anything invalid gives a flat EQ. */
        fun parseBands(raw: String?): List<Float> {
            if (raw.isNullOrBlank()) return FLAT
            val parts = raw.split(',')
            if (parts.size != GraphicEqBands.COUNT) return FLAT
            val values = parts.map { it.trim().toFloatOrNull() ?: return FLAT }
            if (values.any { it.isNaN() }) return FLAT
            return values.map(::clampGain)
        }

        fun formatBands(bands: List<Float>): String = bands.joinToString(",")
    }
}
