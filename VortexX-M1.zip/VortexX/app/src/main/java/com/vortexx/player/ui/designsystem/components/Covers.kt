package com.vortexx.player.ui.designsystem.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortexx.player.data.library.ArtworkRequest
import com.vortexx.player.domain.model.Song
import com.vortexx.player.domain.model.Video

/** Embedded artwork of [song], or a generated cover from its album (or title) when it has none. */
@Composable
fun SongCover(
    song: Song,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp,
    initialsSize: TextUnit = 28.sp,
) {
    MediaArtwork(
        request = ArtworkRequest.Audio(song.contentUri),
        fallbackIcon = Icons.Rounded.MusicNote,
        modifier = modifier,
        cornerRadius = cornerRadius,
        contentDescription = null,
        fallback = { GeneratedCover(title = song.album.ifBlank { song.title }, initialsSize = initialsSize) },
    )
}

/** A frame from [video], or a generated cover from its title while none can be read. */
@Composable
fun VideoThumbnail(
    video: Video,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp,
    initialsSize: TextUnit = 28.sp,
) {
    MediaArtwork(
        request = ArtworkRequest.VideoFrame(video.contentUri),
        fallbackIcon = Icons.Rounded.Movie,
        modifier = modifier,
        cornerRadius = cornerRadius,
        contentDescription = null,
        fallback = { GeneratedCover(title = video.title, initialsSize = initialsSize) },
    )
}
