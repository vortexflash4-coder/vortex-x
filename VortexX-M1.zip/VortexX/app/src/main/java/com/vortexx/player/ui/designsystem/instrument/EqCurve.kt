package com.vortexx.player.ui.designsystem.instrument

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.vortexx.player.audio.dsp.EqResponse
import com.vortexx.player.audio.dsp.GraphicEqBands
import com.vortexx.player.ui.designsystem.theme.VortexColors
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The EQ curve the audio thread applies ([EqResponse.curveDb]), drawn from
 * 20 Hz (left) to 20 kHz (right), ±[rangeDb] around the 0 dB line. Red while
 * processing is on, grey while it is bypassed.
 */
@Composable
fun EqCurve(
    bandGainsDb: List<Float>,
    active: Boolean,
    modifier: Modifier = Modifier,
    rangeDb: Float = GraphicEqBands.MAX_GAIN_DB,
) {
    val curve = remember(bandGainsDb) { EqResponse.curveDb(bandGainsDb, points = 96) }
    val description = remember(curve, active) {
        val peak = curve.maxByOrNull { abs(it) } ?: 0f
        when {
            !active -> "EQ curve, bypassed"
            abs(peak) < 0.05f -> "EQ curve, flat"
            else -> "EQ curve, largest change ${(peak * 10).roundToInt() / 10f} dB"
        }
    }
    val line = if (active) VortexColors.Accent else VortexColors.TextSecondary
    Canvas(modifier.semantics { contentDescription = description }) {
        val w = size.width
        val h = size.height
        val mid = h / 2f
        for (i in 0..4) {
            val y = h * i / 4f
            drawLine(
                color = VortexColors.Divider.copy(alpha = if (i == 2) 0.9f else 0.35f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f,
            )
        }
        if (curve.size < 2) return@Canvas
        val path = Path()
        val fill = Path()
        val usable = h / 2f - 2.dp.toPx()
        for (i in curve.indices) {
            val x = w * i / (curve.size - 1)
            val y = mid - (curve[i].coerceIn(-rangeDb, rangeDb) / rangeDb) * usable
            if (i == 0) {
                path.moveTo(x, y)
                fill.moveTo(x, mid)
                fill.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(w, mid)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(line.copy(alpha = 0.30f), Color.Transparent)))
        drawPath(path, line, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
