package com.vortexx.player.ui.designsystem.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.vortexx.player.ui.designsystem.theme.VortexColors

/**
 * Cover for files without embedded artwork: a crimson-to-black field with
 * groove rings and the title's initials. It is decoration derived from the
 * title only, so the same song always gets the same cover.
 */
@Composable
fun GeneratedCover(title: String, modifier: Modifier = Modifier, initialsSize: TextUnit = 56.sp) {
    val seed = remember(title) { title.hashCode() }
    val angle = remember(seed) { ((seed ushr 3) % 360).toFloat() }
    val initials = remember(title) { initialsOf(title) }
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    0f to Color(0xFF5A0A18),
                    0.45f to Color(0xFF22060C),
                    1f to Color(0xFF050507),
                ),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val centre = Offset(size.width * (0.5f + 0.18f * kotlin.math.cos(Math.toRadians(angle.toDouble())).toFloat()), size.height * 0.62f)
            val maxRadius = size.minDimension * 0.9f
            var r = maxRadius * 0.18f
            var i = 0
            while (r < maxRadius) {
                drawCircle(
                    color = VortexColors.Accent.copy(alpha = if (i % 3 == 0) 0.22f else 0.08f),
                    radius = r,
                    center = centre,
                    style = Stroke(width = if (i % 3 == 0) 2.5f else 1.2f),
                )
                r += maxRadius * 0.055f
                i++
            }
        }
        Text(
            initials,
            style = TextStyle(fontSize = initialsSize, fontWeight = FontWeight.Black, color = Color.White.copy(alpha = 0.92f), letterSpacing = (-1).sp),
        )
    }
}

private fun initialsOf(title: String): String {
    val words = title.split(' ', '-', '_').filter { it.isNotBlank() && it.first().isLetterOrDigit() }
    return when {
        words.isEmpty() -> "♪"
        words.size == 1 -> words[0].take(2).uppercase()
        else -> (words[0].take(1) + words[1].take(1)).uppercase()
    }
}
