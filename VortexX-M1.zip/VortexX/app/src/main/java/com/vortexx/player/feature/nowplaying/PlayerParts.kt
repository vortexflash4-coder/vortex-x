package com.vortexx.player.feature.nowplaying

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortexx.player.audio.engine.DspStatus
import com.vortexx.player.core.util.Format
import com.vortexx.player.data.library.ArtworkRequest
import com.vortexx.player.playback.NowPlaying
import com.vortexx.player.playback.PositionSnapshot
import com.vortexx.player.ui.designsystem.components.GeneratedCover
import com.vortexx.player.ui.designsystem.components.MediaArtwork
import com.vortexx.player.ui.designsystem.instrument.InstrumentText
import com.vortexx.player.ui.designsystem.instrument.MeterDisplayState
import com.vortexx.player.ui.designsystem.theme.VortexColors

/** Song artwork, or a generated cover when the file has none. */
@Composable
fun CoverArt(nowPlaying: NowPlaying, modifier: Modifier = Modifier, cornerRadius: Dp = 24.dp, compact: Boolean = false) {
    MediaArtwork(
        request = nowPlaying.contentUri?.let { ArtworkRequest.Audio(it) },
        fallbackIcon = Icons.Rounded.MusicNote,
        modifier = modifier,
        cornerRadius = cornerRadius,
        contentDescription = "Artwork for ${nowPlaying.title}",
        fallback = {
            GeneratedCover(
                title = nowPlaying.title,
                initialsSize = if (compact) 20.sp else 64.sp,
            )
        },
    )
}

/**
 * Slim seek bar: tap anywhere to jump, drag to scrub. The playback position
 * only changes when the finger lifts, so playback is not flooded with seeks.
 */
@Composable
fun VortexSeekBar(position: PositionSnapshot, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier = Modifier) {
    val duration = (if (position.durationMs > 0) position.durationMs else durationMs).coerceAtLeast(0L)
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    val live = if (duration > 0) (position.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val buffered = if (duration > 0) (position.bufferedMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shown = dragFraction ?: live
    val shownMs = (shown * duration).toLong()
    val dragging = dragFraction != null

    Column(modifier) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(32.dp)
                .pointerInput(duration) {
                    if (duration <= 0) return@pointerInput
                    detectTapGestures { offset ->
                        onSeek(((offset.x / size.width).coerceIn(0f, 1f) * duration).toLong())
                    }
                }
                .pointerInput(duration) {
                    if (duration <= 0) return@pointerInput
                    detectHorizontalDragGestures(
                        onDragStart = { offset -> dragFraction = (offset.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = {
                            dragFraction?.let { onSeek((it * duration).toLong()) }
                            dragFraction = null
                        },
                        onDragCancel = { dragFraction = null },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            dragFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                        },
                    )
                }
                .semantics {
                    contentDescription = "Seek"
                    stateDescription = "${Format.duration(shownMs)} of ${Format.duration(duration)}"
                    progressBarRangeInfo = ProgressBarRangeInfo(shown, 0f..1f)
                    setProgress { target ->
                        if (duration <= 0) return@setProgress false
                        onSeek((target.coerceIn(0f, 1f) * duration).toLong())
                        true
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxWidth().height(32.dp)) {
                val trackHeight = (if (dragging) 6.dp else 4.dp).toPx()
                val y = size.height / 2f
                val radius = CornerRadius(trackHeight / 2f)
                val top = y - trackHeight / 2f
                drawRoundRect(VortexColors.Divider, Offset(0f, top), Size(size.width, trackHeight), radius)
                drawRoundRect(VortexColors.TextSecondary.copy(alpha = 0.35f), Offset(0f, top), Size(size.width * buffered, trackHeight), radius)
                drawRoundRect(VortexColors.Accent, Offset(0f, top), Size(size.width * shown, trackHeight), radius)
                val x = size.width * shown
                if (dragging) drawCircle(VortexColors.Accent.copy(alpha = 0.25f), radius = 16.dp.toPx(), center = Offset(x, y))
                drawCircle(VortexColors.TextPrimary, radius = (if (dragging) 9.dp else 7.dp).toPx(), center = Offset(x, y))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            Text(Format.duration(shownMs), style = InstrumentText.readoutSmall)
            Spacer(Modifier.weight(1f))
            Text(
                if (duration > 0) "-" + Format.duration((duration - shownMs).coerceAtLeast(0L)) else "--:--",
                style = InstrumentText.readoutSmall,
            )
        }
    }
}

/** Two thin bars fed by the DSP's own output meters (real samples, not animation). */
@Composable
fun CompactLevelMeter(state: MeterDisplayState, modifier: Modifier = Modifier) {
    Canvas(modifier.height(10.dp)) {
        val gap = 2.dp.toPx()
        val barHeight = (size.height - gap) / 2f
        fun bar(db: Float, holdDb: Float, top: Float) {
            val fraction = ((db + 60f) / 60f).coerceIn(0f, 1f)
            val hot = ((-6f + 60f) / 60f)
            drawRoundRect(VortexColors.Divider, Offset(0f, top), Size(size.width, barHeight), CornerRadius(barHeight / 2f))
            val whiteWidth = size.width * minOf(fraction, hot)
            drawRoundRect(VortexColors.TextPrimary.copy(alpha = 0.85f), Offset(0f, top), Size(whiteWidth, barHeight), CornerRadius(barHeight / 2f))
            if (fraction > hot) {
                drawRect(VortexColors.Accent, Offset(size.width * hot, top), Size(size.width * (fraction - hot), barHeight))
            }
            val hold = ((holdDb + 60f) / 60f).coerceIn(0f, 1f)
            if (hold > 0f) drawRect(VortexColors.AccentActive, Offset(size.width * hold - 1.dp.toPx(), top), Size(2.dp.toPx(), barHeight))
        }
        bar(state.peakLeftDb, state.holdLeftDb, 0f)
        bar(state.peakRightDb, state.holdRightDb, barHeight + gap)
    }
}

/** One technical fact as a small chip; optional tap action. */
@Composable
fun TechChip(text: String, modifier: Modifier = Modifier, dotColor: Color? = null, onClick: (() -> Unit)? = null) {
    Row(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(VortexColors.Card.copy(alpha = 0.85f))
            .border(1.dp, VortexColors.Divider, RoundedCornerShape(8.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (dotColor != null) {
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(dotColor),
            )
        }
        Text(text, style = InstrumentText.readoutSmall.copy(color = VortexColors.TextPrimary), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** DSP state, stream format and output route, all from what Media3 and Android report. */
@Composable
fun SignalChips(
    status: DspStatus,
    formatLine: String?,
    routeLine: String?,
    onOpenAudioLab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        TechChip(
            text = status.label,
            dotColor = if (status.isProcessing) VortexColors.Success else VortexColors.TextSecondary,
            onClick = onOpenAudioLab,
        )
        if (formatLine != null) TechChip(formatLine)
        if (routeLine != null) TechChip(routeLine)
        Spacer(Modifier.width(2.dp))
    }
}
