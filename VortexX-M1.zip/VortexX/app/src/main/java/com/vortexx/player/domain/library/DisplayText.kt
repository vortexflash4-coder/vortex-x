package com.vortexx.player.domain.library

/**
 * Turns raw MediaStore titles into readable ones. Files without tags often
 * carry their file name as title ("Sheesha_Chahe_Toot_Bhi_Jaaye.mp3").
 * Only spelling changes are made: words are never added, removed or reordered.
 */
object DisplayText {

    private val audioVideoExtensions = setOf(
        "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "wma", "amr", "alac", "aiff", "aif",
        "mp4", "mkv", "webm", "avi", "mov", "3gp", "ts", "m4v",
    )
    private val spaces = Regex("\\s+")

    fun title(raw: String): String {
        var text = raw.trim()
        val dot = text.lastIndexOf('.')
        if (dot > 0 && text.substring(dot + 1).lowercase() in audioVideoExtensions) {
            text = text.substring(0, dot)
        }
        val underscores = text.count { it == '_' }
        if (underscores > 0 && underscores >= text.count { it == ' ' }) {
            text = text.replace('_', ' ')
        }
        text = text.replace(spaces, " ").trim()
        return text.ifEmpty { raw.trim() }
    }
}
