package com.vortexx.player.feature.you

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vortexx.player.BuildConfig
import com.vortexx.player.audio.dsp.DspParameters
import com.vortexx.player.audio.engine.AudioEngine
import com.vortexx.player.audio.engine.DspStatus
import com.vortexx.player.audio.engine.DspStatusKind
import com.vortexx.player.audio.engine.PlaybackEngine
import com.vortexx.player.core.util.Format
import com.vortexx.player.data.library.MediaLibraryRepository
import com.vortexx.player.data.repo.FavoritesRepository
import com.vortexx.player.data.repo.PlaylistRepository
import com.vortexx.player.domain.model.dataOrNull
import com.vortexx.player.ui.designsystem.components.BrandHeader
import com.vortexx.player.ui.designsystem.components.HeaderIconButton
import com.vortexx.player.ui.designsystem.components.MetaChip
import com.vortexx.player.ui.designsystem.components.ScreenMargin
import com.vortexx.player.ui.designsystem.components.SectionTitle
import com.vortexx.player.ui.designsystem.components.VortexMark
import com.vortexx.player.ui.designsystem.components.VortexWordmark
import com.vortexx.player.ui.designsystem.instrument.EqCurve
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing
import com.vortexx.player.ui.navigation.ControlCenterRoute
import com.vortexx.player.ui.navigation.DiagnosticsRoute
import com.vortexx.player.ui.navigation.ExplorerRoute
import com.vortexx.player.ui.navigation.QueueRoute
import com.vortexx.player.ui.navigation.SettingsRoute
import com.vortexx.player.ui.navigation.StudioRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class YouUiState(
    val songCount: Int = 0,
    val videoCount: Int = 0,
    val playlistCount: Int = 0,
    val favoriteCount: Int = 0,
    val musicDurationMs: Long = 0L,
)

@HiltViewModel
class YouViewModel @Inject constructor(
    library: MediaLibraryRepository,
    playlists: PlaylistRepository,
    favorites: FavoritesRepository,
    audio: AudioEngine,
    playbackEngine: PlaybackEngine,
) : ViewModel() {
    val uiState: StateFlow<YouUiState> =
        combine(library.songs, library.videos, playlists.playlists, favorites.favoriteSongIds) { songs, videos, lists, favs ->
            val songList = songs.dataOrNull().orEmpty()
            YouUiState(
                songCount = songList.size,
                videoCount = videos.dataOrNull().orEmpty().size,
                playlistCount = lists.size,
                favoriteCount = favs.size,
                musicDurationMs = songList.sumOf { it.durationMs },
            )
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), YouUiState())

    val dsp: StateFlow<DspParameters> = audio.state
    val status: StateFlow<DspStatus> = playbackEngine.status
}

private data class HubEntry(val title: String, val subtitle: String, val icon: ImageVector, val route: Any)

private val HubEntries = listOf(
    HubEntry("Control Center", "Speed, sleep timer, repeat", Icons.Rounded.Tune, ControlCenterRoute),
    HubEntry("Queue", "What plays next", Icons.AutoMirrored.Rounded.QueueMusic, QueueRoute),
    HubEntry("Folders", "Browse and open any file", Icons.Rounded.FolderOpen, ExplorerRoute),
    HubEntry("Diagnostics", "Decoders, output route, HDR", Icons.Rounded.Analytics, DiagnosticsRoute),
    HubEntry("Settings", "Playback, video, audio, appearance", Icons.Rounded.Settings, SettingsRoute),
)

/** The You hub: library summary, the Audio Lab, tools and app information. */
@Composable
fun YouScreen(
    onNavigate: (Any) -> Unit,
    viewModel: YouViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val dsp by viewModel.dsp.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = VortexSpacing.xxl),
    ) {
        item(key = "header") {
            BrandHeader(title = "You", subtitle = "Your library, your sound, your settings") {
                HeaderIconButton(Icons.Rounded.Settings, "Settings", onClick = { onNavigate(SettingsRoute) })
            }
        }
        item(key = "stats") {
            LibrarySummary(state, Modifier.padding(horizontal = ScreenMargin, vertical = VortexSpacing.sm))
        }
        item(key = "lab-title") { SectionTitle("Sound") }
        item(key = "lab") {
            AudioLabCard(
                dsp = dsp,
                status = status,
                onClick = { onNavigate(StudioRoute) },
                modifier = Modifier.padding(horizontal = ScreenMargin),
            )
        }
        item(key = "tools-title") { SectionTitle("Tools") }
        item(key = "tools") {
            Column(
                Modifier
                    .padding(horizontal = ScreenMargin)
                    .clip(RoundedCornerShape(16.dp))
                    .background(VortexColors.Card)
                    .border(1.dp, VortexColors.Divider, RoundedCornerShape(16.dp)),
            ) {
                HubEntries.forEachIndexed { index, entry ->
                    HubRow(entry, onClick = { onNavigate(entry.route) })
                    if (index != HubEntries.lastIndex) {
                        Box(
                            Modifier
                                .padding(start = 68.dp)
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(VortexColors.Divider),
                        )
                    }
                }
            }
        }
        item(key = "about") {
            AboutCard(Modifier.padding(horizontal = ScreenMargin, vertical = VortexSpacing.xl))
        }
    }
}

@Composable
private fun LibrarySummary(state: YouUiState, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth()) {
        val stats = listOf(
            state.songCount.toString() to "Songs",
            state.videoCount.toString() to "Videos",
            state.playlistCount.toString() to "Playlists",
            state.favoriteCount.toString() to "Favourites",
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(
                        0f to VortexColors.Accent.copy(alpha = 0.22f),
                        0.55f to VortexColors.Card,
                        1f to VortexColors.Card,
                    ),
                )
                .border(1.dp, VortexColors.Divider, RoundedCornerShape(20.dp))
                .padding(VortexSpacing.lg),
        ) {
            Text("ON THIS PHONE", style = MaterialTheme.typography.labelSmall, color = VortexColors.TextSecondary)
            Spacer(Modifier.height(2.dp))
            Text(
                if (state.musicDurationMs > 0) "${Format.longDuration(state.musicDurationMs)} of music" else "Your library",
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(Modifier.height(VortexSpacing.md))
            Row(Modifier.fillMaxWidth()) {
                stats.forEach { (value, label) ->
                    Column(Modifier.weight(1f)) {
                        Text(value, style = MaterialTheme.typography.headlineSmall, maxLines = 1)
                        Text(label, style = MaterialTheme.typography.bodySmall, color = VortexColors.TextSecondary, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioLabCard(
    dsp: DspParameters,
    status: DspStatus,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val processing = status.kind == DspStatusKind.Active
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(VortexColors.Card)
            .border(1.dp, if (processing) VortexColors.Accent.copy(alpha = 0.5f) else VortexColors.Divider, shape)
            .clickable(role = Role.Button, onClickLabel = "Open Audio Lab", onClick = onClick)
            .padding(VortexSpacing.lg),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(VortexColors.AccentContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Equalizer, contentDescription = null, tint = VortexColors.Accent)
            }
            Spacer(Modifier.width(VortexSpacing.md))
            Column(Modifier.weight(1f)) {
                Text("Audio Lab", style = MaterialTheme.typography.titleMedium)
                Text(
                    status.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (processing) VortexColors.Success else VortexColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            MetaChip(if (dsp.enabled) "EQ ON" else "EQ OFF", accent = dsp.enabled)
        }
        Spacer(Modifier.height(VortexSpacing.md))
        EqCurve(
            bandGainsDb = dsp.bandGainsDb,
            active = dsp.enabled,
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
        )
        Spacer(Modifier.height(VortexSpacing.xs))
        Row(Modifier.fillMaxWidth()) {
            Text("20 Hz", style = MaterialTheme.typography.labelSmall, color = VortexColors.TextSecondary)
            Spacer(Modifier.weight(1f))
            Text("1 kHz", style = MaterialTheme.typography.labelSmall, color = VortexColors.TextSecondary)
            Spacer(Modifier.weight(1f))
            Text("20 kHz", style = MaterialTheme.typography.labelSmall, color = VortexColors.TextSecondary)
        }
    }
}

@Composable
private fun HubRow(entry: HubEntry, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = VortexSpacing.lg, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(VortexColors.CardRaised),
            contentAlignment = Alignment.Center,
        ) {
            Icon(entry.icon, contentDescription = null, tint = VortexColors.TextPrimary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(VortexSpacing.lg))
        Column(Modifier.weight(1f)) {
            Text(entry.title, style = MaterialTheme.typography.titleSmall)
            Text(entry.subtitle, style = MaterialTheme.typography.bodySmall, color = VortexColors.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = VortexColors.TextSecondary)
    }
}

@Composable
private fun AboutCard(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(VortexSpacing.xs),
    ) {
        VortexMark(size = 40.dp)
        VortexWordmark()
        Text("Version ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall, color = VortexColors.TextSecondary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Shield, contentDescription = null, tint = VortexColors.TextSecondary, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                "Plays files on this phone. No account, no tracking.",
                style = MaterialTheme.typography.bodySmall,
                color = VortexColors.TextSecondary,
            )
        }
    }
}
