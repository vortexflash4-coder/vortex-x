package com.vortexx.player.ui.designsystem.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortexx.player.R
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing

/** Screen margin from the design system (20 dp). */
val ScreenMargin: Dp = 20.dp

/** The VORTEX X mark: two ribbon arms forming a V around a play aperture. */
@Composable
fun VortexMark(modifier: Modifier = Modifier, size: Dp = 28.dp) {
    Image(
        painter = painterResource(R.drawable.ic_vortex_mark),
        contentDescription = null,
        modifier = modifier.size(size),
    )
}

/** "VORTEX X" with the X in brand red. */
@Composable
fun VortexWordmark(modifier: Modifier = Modifier, fontSize: TextUnit = 17.sp) {
    Text(
        text = buildAnnotatedString {
            append("VORTEX ")
            withStyle(SpanStyle(color = VortexColors.Accent)) { append("X") }
        },
        style = TextStyle(
            fontWeight = FontWeight.ExtraBold,
            fontSize = fontSize,
            letterSpacing = (fontSize.value * 0.14f).sp,
            color = VortexColors.TextPrimary,
        ),
        maxLines = 1,
        modifier = modifier.semantics { contentDescription = "VORTEX X" },
    )
}

/**
 * Header of every top-level screen: mark and wordmark, actions on the right,
 * then the screen title in the hero size.
 */
@Composable
fun BrandHeader(
    title: String?,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Column(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = ScreenMargin, end = VortexSpacing.sm, top = VortexSpacing.xs, bottom = VortexSpacing.sm),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            VortexMark(size = 26.dp)
            Spacer(Modifier.width(10.dp))
            VortexWordmark()
            Spacer(Modifier.weight(1f))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(VortexSpacing.xs),
                content = actions,
            )
        }
        if (title != null) {
            Spacer(Modifier.height(VortexSpacing.sm))
            Text(
                title,
                style = MaterialTheme.typography.displaySmall,
                color = VortexColors.TextPrimary,
                modifier = Modifier
                    .padding(end = VortexSpacing.md)
                    .semantics { heading() },
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = VortexColors.TextSecondary,
                    modifier = Modifier.padding(end = VortexSpacing.md, top = 2.dp),
                )
            }
        }
    }
}

/** Round graphite action button used in headers (48 dp target). */
@Composable
fun HeaderIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = VortexColors.TextPrimary,
) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(VortexColors.Card)
            .border(1.dp, VortexColors.Divider, CircleShape)
            .clickable(role = Role.Button, onClickLabel = contentDescription, onClick = onClick)
            .semantics { this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
    }
}

/** Shelf heading: section title in 21 sp bold with an optional red "See all". */
@Composable
fun SectionTitle(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = ScreenMargin, end = VortexSpacing.sm, top = VortexSpacing.lg, bottom = VortexSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .weight(1f)
                .semantics { heading() },
        )
        if (actionLabel != null && onAction != null) {
            Text(
                actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = VortexColors.Accent,
                modifier = Modifier
                    .defaultMinSize(minHeight = VortexSpacing.touchTarget)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(role = Role.Button, onClick = onAction)
                    .padding(horizontal = VortexSpacing.md, vertical = 14.dp),
            )
        }
    }
}

/** The primary red play / pause circle. */
@Composable
fun PlayCircleButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    playLabel: String = "Play",
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.verticalGradient(
                    0f to VortexColors.AccentActive,
                    1f to VortexColors.Accent,
                ),
            )
            .clickable(role = Role.Button, onClickLabel = if (isPlaying) "Pause" else playLabel, onClick = onClick)
            .semantics { contentDescription = if (isPlaying) "Pause" else playLabel },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(size * 0.52f),
        )
    }
}

/** Small status / format chip ("LOCAL", "FLAC", "1080p"). */
@Composable
fun MetaChip(
    text: String,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
) {
    val shape = RoundedCornerShape(6.dp)
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = if (accent) VortexColors.Accent else VortexColors.TextSecondary,
        maxLines = 1,
        modifier = modifier
            .clip(shape)
            .background(if (accent) VortexColors.AccentContainer else VortexColors.Card)
            .border(1.dp, if (accent) VortexColors.Accent.copy(alpha = 0.45f) else VortexColors.Divider, shape)
            .padding(horizontal = 7.dp, vertical = 3.dp),
    )
}

/**
 * Square media card for shelves (albums, songs, playlists): artwork slot,
 * title and one secondary line.
 */
@Composable
fun ShelfCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onClickLabel: String? = null,
    artwork: @Composable (Modifier) -> Unit,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClickLabel = onClickLabel, onClick = onClick)
            .padding(bottom = VortexSpacing.xs),
    ) {
        artwork(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp)),
        )
        Spacer(Modifier.height(VortexSpacing.sm))
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = VortexColors.TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** A thin red progress line on a dark track (cards and the mini player). */
@Composable
fun ProgressLine(fraction: Float, modifier: Modifier = Modifier, height: Dp = 3.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height))
            .background(VortexColors.Divider),
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .height(height)
                .background(VortexColors.Accent),
        )
    }
}

/**
 * Text tabs with a red underline on the selected one (Songs | Albums | …).
 * Scrolls sideways when the labels do not fit.
 */
@Composable
fun <T> UnderlineTabs(
    items: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = ScreenMargin - 12.dp),
        ) {
            items.forEach { item ->
                val isSelected = item == selected
                Column(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .selectable(selected = isSelected, role = Role.Tab, onClick = { onSelect(item) })
                        .defaultMinSize(minHeight = VortexSpacing.touchTarget)
                        .padding(start = 12.dp, end = 12.dp, top = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        label(item),
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isSelected) VortexColors.TextPrimary else VortexColors.TextSecondary,
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .width(if (isSelected) 26.dp else 0.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                            .background(VortexColors.Accent),
                    )
                }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(VortexColors.Divider),
        )
    }
}
