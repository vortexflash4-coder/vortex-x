package com.vortexx.player.audio.engine

import com.vortexx.player.audio.dsp.DspHost
import kotlin.math.roundToLong

/**
 * Measured audio delays. Both are kept apart from the output buffer size,
 * which is only the capacity Media3 allocated, not a delay anyone heard.
 *
 * @property outputStartMs last measured time from the player starting to play
 *   to the first sample leaving the output. The end point is Media3's
 *   `onAudioPositionAdvancing` playout-start time, which Media3 derives from
 *   the AudioTrack position. Null until one start has been measured.
 * @property changeToEarMs how far the processor's last finished sample is
 *   ahead of the playback position (median of the recent samples). A DSP
 *   change made now is heard after about this long. Null until measured.
 * @property rejectedSamples samples thrown away as implausible (outside
 *   0–[LatencyTracker.MAX_PLAUSIBLE_MS] ms), for example across a track change.
 */
data class LatencyReadings(
    val outputStartMs: Long? = null,
    val outputStartSamples: Int = 0,
    val changeToEarMs: Long? = null,
    val changeToEarSamples: Int = 0,
    val rejectedSamples: Int = 0,
)

/**
 * Turns raw timestamps into [LatencyReadings]. Plain Kotlin, no Android, so
 * the arithmetic and the plausibility rules are covered by JVM tests. Not
 * thread-safe: call it from the player's application thread only.
 */
class LatencyTracker {

    private var startMarkWallMs = NO_MARK
    private val window = LongArray(WINDOW)
    private val sorted = LongArray(WINDOW)
    private var windowCount = 0
    private var windowNext = 0

    var readings = LatencyReadings()
        private set

    /** The player started playing (isPlaying became true) at [nowWallMs] (System.currentTimeMillis). */
    fun onPlaybackStarted(nowWallMs: Long) {
        startMarkWallMs = nowWallMs
    }

    /** The player stopped playing; a later playout start must not be paired with the old mark. */
    fun onPlaybackStopped() {
        startMarkWallMs = NO_MARK
    }

    /**
     * Media3 reported that playout started at [playoutStartWallMs]. Pairs it
     * with the last start mark once; position advances after a seek have no
     * mark and are ignored. Returns true when a reading was recorded.
     */
    fun onPlayoutStarted(playoutStartWallMs: Long): Boolean {
        val mark = startMarkWallMs
        if (mark == NO_MARK) return false
        startMarkWallMs = NO_MARK
        val ms = playoutStartWallMs - mark
        if (ms !in 0..MAX_PLAUSIBLE_MS) {
            reject()
            return false
        }
        readings = readings.copy(outputStartMs = ms, outputStartSamples = readings.outputStartSamples + 1)
        return true
    }

    /**
     * One comparison of the processor's head with the playback position, both
     * in the current media item's time. [speed] converts media time to real
     * time. Returns true when the sample was accepted.
     */
    fun onPositionSample(processedPositionUs: Long, playbackPositionMs: Long, speed: Float): Boolean {
        if (processedPositionUs == DspHost.UNKNOWN_POSITION_US || speed <= 0f || playbackPositionMs < 0) return false
        val aheadUs = processedPositionUs - playbackPositionMs * 1_000L
        val ms = (aheadUs / 1_000.0 / speed).roundToLong()
        if (ms !in 0..MAX_PLAUSIBLE_MS) {
            reject()
            return false
        }
        window[windowNext] = ms
        windowNext = (windowNext + 1) % WINDOW
        if (windowCount < WINDOW) windowCount++
        readings = readings.copy(changeToEarMs = median(), changeToEarSamples = readings.changeToEarSamples + 1)
        return true
    }

    /** Forget the change-to-ear window (new output, new route). Start readings stay as history. */
    fun clearWindow() {
        windowCount = 0
        windowNext = 0
        readings = readings.copy(changeToEarMs = null)
    }

    private fun reject() {
        readings = readings.copy(rejectedSamples = readings.rejectedSamples + 1)
    }

    private fun median(): Long {
        for (i in 0 until windowCount) sorted[i] = window[i]
        sorted.sort(0, windowCount)
        return if (windowCount % 2 == 1) {
            sorted[windowCount / 2]
        } else {
            (sorted[windowCount / 2 - 1] + sorted[windowCount / 2]) / 2
        }
    }

    companion object {
        const val WINDOW = 9
        const val MAX_PLAUSIBLE_MS = 5_000L
        private const val NO_MARK = Long.MIN_VALUE
    }
}
