package com.vortexx.player.feature.nowplaying

import androidx.compose.foundation.layout.width
import com.vortexx.player.ui.designsystem.instrument.EqCurve
import com.vortexx.player.audio.dsp.DspParameters
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vortexx.player.audio.dsp.MeterBus
import com.vortexx.player.audio.engine.AudioDiagnostics
import com.vortexx.player.audio.engine.AudioEngine
import com.vortexx.player.audio.engine.AudioFormatLabels
import com.vortexx.player.audio.engine.AudioPathState
import com.vortexx.player.audio.engine.DspStatus
import com.vortexx.player.audio.engine.DspStatusKind
import com.vortexx.player.audio.engine.PlaybackEngine
import com.vortexx.player.audio.engine.RouteInfo
import com.vortexx.player.core.util.Format
import com.vortexx.player.data.repo.FavoritesRepository
import com.vortexx.player.domain.playback.PlaybackErrorExplainer
import com.vortexx.player.playback.PlaybackConnection
import com.vortexx.player.playback.PlaybackUiState
import com.vortexx.player.playback.PositionSnapshot
import com.vortexx.player.playback.QueueEntry
import com.vortexx.player.playback.RepeatSetting
import com.vortexx.player.playback.SleepTimer
import com.vortexx.player.ui.designsystem.components.EmptyState
import com.vortexx.player.ui.designsystem.components.InlineNotice
import com.vortexx.player.ui.designsystem.components.NoticeTone
import com.vortexx.player.ui.designsystem.instrument.InstrumentText
import com.vortexx.player.ui.designsystem.instrument.rememberMeterDisplay
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.abs

@HiltViewModel
class NowPlayingViewModel @Inject constructor(
    private val playback: PlaybackConnection,
    private val favorites: FavoritesRepository,
    sleepTimer: SleepTimer,
    playbackEngine: PlaybackEngine,
    audioEngine: AudioEngine,
    diagnostics: AudioDiagnostics,
) : ViewModel() {
    val state: StateFlow<PlaybackUiState> = playback.state
    val position: Flow<PositionSnapshot> = playback.positionUpdates(intervalMs = 250L)
    val status: StateFlow<DspStatus> = playbackEngine.status
    val path: StateFlow<AudioPathState> = diagnostics.state
    val meters: MeterBus = audioEngine.meters
    val dsp: StateFlow<DspParameters> = audioEngine.state
    val sleepTimerActive: StateFlow<Boolean> = combine(sleepTimer.deadlineElapsedMs, playback.state) { deadline, _ -> deadline != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), false)
    val isFavorite: StateFlow<Boolean> = combine(playback.state, favorites.favoriteSongIdSet) { s, ids ->
        val id = s.nowPlaying?.songId
        id != null && id in ids
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), false)

    fun togglePlayPause() = playback.togglePlayPause()
    fun next() = playback.next()
    fun previous() = playback.previous()
    fun seekTo(ms: Long) = playback.seekTo(ms)
    fun toggleShuffle() = playback.setShuffle(!state.value.shuffleEnabled)
    fun cycleRepeat() = playback.cycleRepeat()
    fun retry() = playback.retry()
    fun skipFailed() = playback.skipFailed()

    fun toggleFavorite() {
        val id = state.value.nowPlaying?.songId ?: return
        viewModelScope.launch { favorites.toggleSong(id) }
    }
}

/** The next song in queue order, or null when it cannot be known (shuffle) or there is none. */
internal fun upNext(state: PlaybackUiState): QueueEntry? {
    if (state.shuffleEnabled || state.queue.isEmpty() || state.currentIndex < 0) return null
    val nextIndex = state.currentIndex + 1
    return when {
        state.repeat == RepeatSetting.One -> null
        nextIndex < state.queue.size -> state.queue[nextIndex]
        state.repeat == RepeatSetting.All -> state.queue.first()
        else -> null
    }
}

internal fun routeLine(route: RouteInfo?): String? {
    route ?: return null
    val name = route.productName.takeIf { it.isNotBlank() && !it.equals(route.typeName, ignoreCase = true) }
    val text = listOfNotNull(route.typeName, name).joinToString(" · ")
    return if (route.exact) text else "$text (estimated)"
}

@Composable
fun NowPlayingScreen(
    onBack: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenControlCenter: () -> Unit,
    onOpenAudioLab: () -> Unit,
    onBrowseMusic: () -> Unit,
    viewModel: NowPlayingViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val position by viewModel.position.collectAsStateWithLifecycle(initialValue = PositionSnapshot())
    val isFavorite by viewModel.isFavorite.collectAsStateWithLifecycle()
    val sleepActive by viewModel.sleepTimerActive.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val path by viewModel.path.collectAsStateWithLifecycle()

    Box(
        Modifier
            .fillMaxSize()
            .background(VortexColors.Background)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(VortexColors.Accent.copy(alpha = 0.30f), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.28f),
                        radius = size.maxDimension * 0.65f,
                    ),
                )
            },
    ) {
        val nowPlaying = state.nowPlaying
        if (nowPlaying == null) {
            Column(Modifier.statusBarsPadding()) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close player") }
                EmptyState(
                    icon = Icons.Rounded.MusicNote,
                    title = "Nothing playing",
                    message = "Pick a song from your library to start playback.",
                    actionLabel = "Browse music",
                    onAction = onBrowseMusic,
                )
            }
            return@Box
        }

        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            val landscape = maxWidth > maxHeight && maxWidth >= 560.dp
            val artwork: @Composable (Modifier) -> Unit = { mod ->
                SwipeableArtwork(
                    isPlaying = state.isPlaying,
                    onNext = viewModel::next,
                    onPrevious = viewModel::previous,
                    modifier = mod,
                ) {
                    CoverArt(nowPlaying, Modifier.fillMaxSize(), cornerRadius = 28.dp)
                }
            }
            val controls: @Composable (Modifier) -> Unit = { mod ->
                PlayerDeck(
                    state = state,
                    position = position,
                    status = status,
                    path = path,
                    isFavorite = isFavorite,
                    sleepActive = sleepActive,
                    viewModel = viewModel,
                    onOpenQueue = onOpenQueue,
                    onOpenControlCenter = onOpenControlCenter,
                    onOpenAudioLab = onOpenAudioLab,
                    modifier = mod,
                )
            }

            Column(Modifier.fillMaxSize()) {
                TopBar(state = state, onBack = onBack, onOpenQueue = onOpenQueue)
                if (landscape) {
                    Row(
                        Modifier
                            .fillMaxSize()
                            .padding(horizontal = VortexSpacing.xl, vertical = VortexSpacing.md),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(VortexSpacing.xl),
                    ) {
                        artwork(Modifier.fillMaxHeight().aspectRatio(1f))
                        controls(Modifier.weight(1f).verticalScroll(rememberScrollState()))
                    }
                } else {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = VortexSpacing.xl),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Spacer(Modifier.height(VortexSpacing.sm))
                        artwork(Modifier.widthIn(max = 400.dp).fillMaxWidth().aspectRatio(1f))
                        Spacer(Modifier.height(VortexSpacing.xl))
                        controls(Modifier.widthIn(max = 520.dp).fillMaxWidth())
                        Spacer(Modifier.height(VortexSpacing.lg))
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(state: PlaybackUiState, onBack: () -> Unit, onOpenQueue: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close player")
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NOW PLAYING", style = InstrumentText.label)
            if (state.queue.isNotEmpty() && state.currentIndex >= 0) {
                Text(
                    "${state.currentIndex + 1} of ${state.queue.size} in queue",
                    style = InstrumentText.readoutSmall,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                )
            }
        }
        IconButton(onClick = onOpenQueue) {
            Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = "Open queue")
        }
    }
}

/** Artwork that shrinks a little while paused and changes song on a sideways swipe. */
@Composable
private fun SwipeableArtwork(
    isPlaying: Boolean,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    var dragX by remember { mutableFloatStateOf(0f) }
    val thresholdPx = with(LocalDensity.current) { 72.dp.toPx() }
    val scale by animateFloatAsState(if (isPlaying) 1f else 0.9f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow), label = "art-scale")
    val offset by animateFloatAsState(dragX, spring(stiffness = Spring.StiffnessMediumLow), label = "art-offset")
    Box(
        modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset * 0.6f
                rotationZ = offset / 80f
                alpha = 1f - (abs(offset) / (thresholdPx * 6f)).coerceAtMost(0.35f)
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        when {
                            dragX <= -thresholdPx -> onNext()
                            dragX >= thresholdPx -> onPrevious()
                        }
                        dragX = 0f
                    },
                    onDragCancel = { dragX = 0f },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        dragX += amount
                    },
                )
            },
    ) {
        content()
    }
}

@Composable
private fun PlayerDeck(
    state: PlaybackUiState,
    position: PositionSnapshot,
    status: DspStatus,
    path: AudioPathState,
    isFavorite: Boolean,
    sleepActive: Boolean,
    viewModel: NowPlayingViewModel,
    onOpenQueue: () -> Unit,
    onOpenControlCenter: () -> Unit,
    onOpenAudioLab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val nowPlaying = state.nowPlaying ?: return
    Column(modifier) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    nowPlaying.title,
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    listOf(nowPlaying.artist, nowPlaying.album).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium,
                    color = VortexColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (nowPlaying.songId != null) {
                IconButton(onClick = viewModel::toggleFavorite) {
                    Icon(
                        if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (isFavorite) "Remove from favourites" else "Add to favourites",
                        tint = if (isFavorite) VortexColors.Accent else VortexColors.TextSecondary,
                    )
                }
            }
        }

        Spacer(Modifier.height(VortexSpacing.md))
        SignalChips(
            status = status,
            formatLine = AudioFormatLabels.describe(path.input),
            routeLine = routeLine(path.route),
            onOpenAudioLab = onOpenAudioLab,
        )

        val error = state.error
        if (error != null) {
            val explanation = PlaybackErrorExplainer.explain(error.code)
            Spacer(Modifier.height(VortexSpacing.md))
            InlineNotice(
                text = "${explanation.title}. ${explanation.detail} (${error.codeName})",
                tone = NoticeTone.Error,
                actionLabel = if (explanation.canRetry) "Retry" else "Skip",
                onAction = if (explanation.canRetry) viewModel::retry else viewModel::skipFailed,
            )
        }

        Spacer(Modifier.height(VortexSpacing.md))
        VortexSeekBar(position = position, durationMs = state.durationMs, onSeek = viewModel::seekTo)

        Spacer(Modifier.height(VortexSpacing.sm))
        Transport(state = state, viewModel = viewModel)

        val processorInPath = status.kind == DspStatusKind.Active || status.kind == DspStatusKind.BypassedByUser
        if (processorInPath) {
            Spacer(Modifier.height(VortexSpacing.md))
            val meter = rememberMeterDisplay(viewModel.meters)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("OUT", style = InstrumentText.label, modifier = Modifier.padding(end = VortexSpacing.sm))
                CompactLevelMeter(meter, Modifier.weight(1f))
            }
        }

        val next = upNext(state)
        Spacer(Modifier.height(VortexSpacing.lg))
        UpNextCard(next = next, shuffle = state.shuffleEnabled, onClick = onOpenQueue)

        val dsp by viewModel.dsp.collectAsStateWithLifecycle()
        Spacer(Modifier.height(VortexSpacing.md))
        AudioLabStrip(dsp = dsp, status = status, onClick = onOpenAudioLab)

        Spacer(Modifier.height(VortexSpacing.lg))
        Row(Modifier.fillMaxWidth()) {
            ActionItem(Icons.Rounded.Speed, Format.speed(state.speed), state.speed != 1f, onOpenControlCenter, Modifier.weight(1f))
            ActionItem(Icons.Rounded.Bedtime, if (sleepActive) "Timer on" else "Sleep", sleepActive, onOpenControlCenter, Modifier.weight(1f))
            ActionItem(Icons.Rounded.Equalizer, "Audio Lab", status.isProcessing, onOpenAudioLab, Modifier.weight(1f))
            ActionItem(Icons.AutoMirrored.Rounded.QueueMusic, "Queue", false, onOpenQueue, Modifier.weight(1f))
        }
    }
}

@Composable
private fun Transport(state: PlaybackUiState, viewModel: NowPlayingViewModel) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = viewModel::toggleShuffle, modifier = Modifier.semantics { stateDescription = if (state.shuffleEnabled) "On" else "Off" }) {
            Icon(
                Icons.Rounded.Shuffle,
                contentDescription = "Shuffle",
                tint = if (state.shuffleEnabled) VortexColors.Accent else VortexColors.TextSecondary,
            )
        }
        IconButton(onClick = viewModel::previous, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
        }
        FilledIconButton(
            onClick = viewModel::togglePlayPause,
            modifier = Modifier.size(80.dp),
            shape = CircleShape,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = VortexColors.Accent,
                contentColor = VortexColors.TextPrimary,
            ),
        ) {
            Crossfade(targetState = state.isPlaying, label = "play-pause") { playing ->
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (playing) "Pause" else "Play",
                    modifier = Modifier.size(42.dp),
                )
            }
        }
        IconButton(onClick = viewModel::next, enabled = state.hasNext || state.repeat != RepeatSetting.Off, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
        }
        IconButton(
            onClick = viewModel::cycleRepeat,
            modifier = Modifier.semantics {
                stateDescription = when (state.repeat) {
                    RepeatSetting.Off -> "Off"
                    RepeatSetting.All -> "Repeat all"
                    RepeatSetting.One -> "Repeat one"
                }
            },
        ) {
            Icon(
                if (state.repeat == RepeatSetting.One) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                contentDescription = "Repeat",
                tint = if (state.repeat == RepeatSetting.Off) VortexColors.TextSecondary else VortexColors.Accent,
            )
        }
    }
}

@Composable
private fun UpNextCard(next: QueueEntry?, shuffle: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(VortexColors.Card.copy(alpha = 0.9f))
            .border(1.dp, VortexColors.Divider, RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClickLabel = "Open queue", onClick = onClick)
            .padding(horizontal = VortexSpacing.lg, vertical = VortexSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("UP NEXT", style = InstrumentText.label)
            Spacer(Modifier.height(2.dp))
            val (title, subtitle) = when {
                next != null -> next.title to next.artist
                shuffle -> "Shuffle is on" to "Open the queue to see the order"
                else -> "End of queue" to "Add songs from your library"
            }
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = VortexColors.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = null, tint = VortexColors.TextSecondary)
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tint = if (active) VortexColors.Accent else VortexColors.TextSecondary
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(vertical = VortexSpacing.sm),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) VortexColors.TextPrimary else VortexColors.TextSecondary,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** The Audio Lab at a glance: processing state and the EQ curve the audio thread applies. */
@Composable
private fun AudioLabStrip(dsp: DspParameters, status: DspStatus, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(VortexColors.Card)
            .border(1.dp, if (status.isProcessing) VortexColors.Accent.copy(alpha = 0.45f) else VortexColors.Divider, shape)
            .clickable(role = Role.Button, onClickLabel = "Open Audio Lab", onClick = onClick)
            .padding(horizontal = VortexSpacing.md, vertical = VortexSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "AUDIO LAB",
                style = InstrumentText.label.copy(color = if (status.isProcessing) VortexColors.Accent else VortexColors.TextSecondary),
            )
            Text(status.label, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(VortexSpacing.md))
        EqCurve(
            bandGainsDb = dsp.bandGainsDb,
            active = dsp.enabled && status.isProcessing,
            modifier = Modifier.size(width = 128.dp, height = 44.dp),
        )
    }
}
