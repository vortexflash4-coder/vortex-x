package com.vortexx.player.audio.engine

import java.util.Locale

/** Short, honest labels for what Media3 reports about the playing stream. */
object AudioFormatLabels {

    fun codec(mimeType: String?): String? {
        val mime = mimeType?.lowercase(Locale.ROOT)?.takeIf { it.isNotBlank() } ?: return null
        return codecName(mime)
    }

    private fun codecName(mime: String): String = when (mime) {
        "audio/mpeg", "audio/mpeg-l1", "audio/mpeg-l2" -> "MP3"
        "audio/mp4a-latm", "audio/aac" -> "AAC"
        "audio/flac" -> "FLAC"
        "audio/alac" -> "ALAC"
        "audio/opus" -> "Opus"
        "audio/vorbis" -> "Vorbis"
        "audio/raw" -> "PCM"
        "audio/ac3" -> "Dolby Digital (AC-3)"
        "audio/eac3" -> "Dolby Digital Plus (E-AC-3)"
        "audio/eac3-joc" -> "Dolby Digital Plus JOC"
        "audio/ac4" -> "Dolby AC-4"
        "audio/true-hd" -> "Dolby TrueHD"
        "audio/vnd.dts" -> "DTS"
        "audio/vnd.dts.hd" -> "DTS-HD"
        "audio/amr-wb" -> "AMR-WB"
        "audio/3gpp" -> "AMR-NB"
        "audio/x-ms-wma" -> "WMA"
        else -> mime.substringAfter('/').uppercase(Locale.ROOT)
    }

    fun sampleRate(hz: Int): String? = when {
        hz <= 0 -> null
        hz % 1000 == 0 -> "${hz / 1000} kHz"
        else -> String.format(Locale.ROOT, "%.1f kHz", hz / 1000.0)
    }

    fun channels(count: Int): String? = when (count) {
        0, -1 -> null
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> "$count ch"
    }

    fun bitrate(bitsPerSecond: Int): String? = if (bitsPerSecond > 0) "${(bitsPerSecond + 500) / 1000} kbps" else null

    /** "FLAC · 44.1 kHz · Stereo · 905 kbps"; parts Media3 did not report are left out. */
    fun describe(input: InputStreamInfo?): String? {
        input ?: return null
        val parts = listOfNotNull(codec(input.mimeType), sampleRate(input.sampleRate), channels(input.channelCount), bitrate(input.bitrate))
        return parts.takeIf { it.isNotEmpty() }?.joinToString(" · ")
    }
}
