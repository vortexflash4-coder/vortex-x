package com.vortexx.player.audio.dsp

/**
 * What the audio-thread processor needs from the rest of the app. Every
 * member must be safe to call from the playback thread without blocking.
 */
interface DspHost {
    /** Latest parameter snapshot (a volatile read). */
    val parameters: DspParameters

    /** False when the user prefers hardware offload; the processor then stays inactive. */
    val processingAllowed: Boolean

    val meters: MeterBus
    val load: LoadMeter

    /** Called when the processor (de)activates for a stream format; [format] null = not processing. */
    fun onProcessorConfigured(format: ProcessorFormat?, reason: String?)

    /**
     * Stream position (µs, window time) of the last sample the processor has
     * finished, or [UNKNOWN_POSITION_US]. Called once per buffer: must only
     * store the value (no allocation, no locks).
     */
    fun onProcessedPosition(positionUs: Long)

    companion object {
        const val UNKNOWN_POSITION_US = Long.MIN_VALUE
    }
}

/** The PCM format the processor is working on. */
data class ProcessorFormat(
    val sampleRate: Int,
    val channelCount: Int,
    val encodingName: String,
)
