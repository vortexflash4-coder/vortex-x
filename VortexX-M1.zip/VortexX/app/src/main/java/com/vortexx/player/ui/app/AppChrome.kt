package com.vortexx.player.ui.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortexx.player.feature.nowplaying.CoverArt
import com.vortexx.player.playback.PlaybackUiState
import com.vortexx.player.playback.PositionSnapshot
import com.vortexx.player.ui.designsystem.components.PlayCircleButton
import com.vortexx.player.ui.designsystem.components.ProgressLine
import com.vortexx.player.ui.designsystem.components.VortexMark
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing
import com.vortexx.player.ui.navigation.CollectionRoute
import com.vortexx.player.ui.navigation.ControlCenterRoute
import com.vortexx.player.ui.navigation.DiagnosticsRoute
import com.vortexx.player.ui.navigation.ExplorerFolderRoute
import com.vortexx.player.ui.navigation.ExplorerRoute
import com.vortexx.player.ui.navigation.HomeRoute
import com.vortexx.player.ui.navigation.MusicRoute
import com.vortexx.player.ui.navigation.PlaylistDetailRoute
import com.vortexx.player.ui.navigation.PlaylistsRoute
import com.vortexx.player.ui.navigation.QueueRoute
import com.vortexx.player.ui.navigation.SettingsRoute
import com.vortexx.player.ui.navigation.StudioRoute
import com.vortexx.player.ui.navigation.VideosRoute
import com.vortexx.player.ui.navigation.YouRoute
import kotlin.reflect.KClass

/**
 * A bottom-bar tab. [matches] lists every screen that belongs to the tab, so
 * the tab stays highlighted inside its detail screens.
 */
data class TopLevelDestination(
    val route: Any,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
    val matches: List<KClass<*>>,
)

/**
 * Home | Music | Video | Library | You. "Library" (playlists and folders)
 * stands where the design has "Downloads" until downloads exist (decision D11).
 */
val PrimaryDestinations = listOf(
    TopLevelDestination(HomeRoute, "Home", Icons.Outlined.Home, Icons.Rounded.Home, listOf(HomeRoute::class)),
    TopLevelDestination(MusicRoute, "Music", Icons.Outlined.LibraryMusic, Icons.Rounded.LibraryMusic, listOf(MusicRoute::class, CollectionRoute::class)),
    TopLevelDestination(VideosRoute, "Video", Icons.Outlined.VideoLibrary, Icons.Rounded.VideoLibrary, listOf(VideosRoute::class)),
    TopLevelDestination(
        PlaylistsRoute,
        "Library",
        Icons.AutoMirrored.Outlined.QueueMusic,
        Icons.AutoMirrored.Rounded.QueueMusic,
        listOf(PlaylistsRoute::class, PlaylistDetailRoute::class, ExplorerRoute::class, ExplorerFolderRoute::class),
    ),
    TopLevelDestination(
        YouRoute,
        "You",
        Icons.Outlined.Person,
        Icons.Rounded.Person,
        listOf(YouRoute::class, SettingsRoute::class, StudioRoute::class, DiagnosticsRoute::class, ControlCenterRoute::class, QueueRoute::class),
    ),
)

/** Custom bottom bar: hairline top border, red indicator bar and red icon on the selected tab. */
@Composable
fun VortexBottomBar(
    destinations: List<TopLevelDestination>,
    isSelected: (TopLevelDestination) -> Boolean,
    onSelect: (TopLevelDestination) -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(VortexColors.Background),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(VortexColors.Divider),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(66.dp),
        ) {
            destinations.forEach { destination ->
                NavItem(
                    destination = destination,
                    selected = isSelected(destination),
                    onClick = { onSelect(destination) },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                )
            }
        }
    }
}

@Composable
private fun NavItem(
    destination: TopLevelDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val tint by animateColorAsState(
        if (selected) VortexColors.Accent else VortexColors.TextSecondary,
        animationSpec = tween(180),
        label = "navTint",
    )
    val indicatorWidth by animateDpAsState(if (selected) 22.dp else 0.dp, animationSpec = tween(200), label = "navIndicator")
    Box(
        modifier.selectable(selected = selected, role = Role.Tab, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .width(indicatorWidth)
                .height(3.dp)
                .clip(RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                .background(VortexColors.Accent),
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                if (selected) destination.selectedIcon else destination.icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(24.dp),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                destination.label,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp, letterSpacing = 0.2.sp),
                color = if (selected) VortexColors.TextPrimary else VortexColors.TextSecondary,
                maxLines = 1,
            )
        }
    }
}

/** Rail for tablets, foldables and landscape: the brand mark and the same five tabs. */
@Composable
fun VortexNavRail(
    destinations: List<TopLevelDestination>,
    isSelected: (TopLevelDestination) -> Boolean,
    onSelect: (TopLevelDestination) -> Unit,
) {
    Row(Modifier.fillMaxHeight()) {
        Column(
            Modifier
                .fillMaxHeight()
                .width(88.dp)
                .background(VortexColors.Background)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(VortexSpacing.xs),
        ) {
            Spacer(Modifier.height(VortexSpacing.lg))
            VortexMark(size = 34.dp)
            Spacer(Modifier.height(VortexSpacing.xl))
            destinations.forEach { destination ->
                NavItem(
                    destination = destination,
                    selected = isSelected(destination),
                    onClick = { onSelect(destination) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp),
                )
            }
        }
        Box(
            Modifier
                .fillMaxHeight()
                .width(1.dp)
                .background(VortexColors.Divider),
        )
    }
}

/** Persistent mini player above the bottom bar while something is loaded. */
@Composable
fun MiniPlayer(
    state: PlaybackUiState,
    position: PositionSnapshot,
    onOpen: () -> Unit,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val nowPlaying = state.nowPlaying ?: return
    val duration = if (position.durationMs > 0) position.durationMs else state.durationMs
    val progress = if (duration > 0) (position.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(shape)
            .background(VortexColors.Card)
            .border(1.dp, VortexColors.Divider, shape)
            .clickable(role = Role.Button, onClickLabel = "Open player", onClick = onOpen),
    ) {
        Row(
            modifier = Modifier.padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CoverArt(nowPlaying, Modifier.size(48.dp), cornerRadius = 10.dp, compact = true)
            Spacer(Modifier.width(VortexSpacing.md))
            Column(Modifier.weight(1f)) {
                Text(
                    nowPlaying.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = if (state.error != null) "Playback error · tap for details" else nowPlaying.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.error != null) VortexColors.Accent else VortexColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onPrevious, enabled = state.hasPrevious || position.positionMs > 3_000L) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous track", tint = VortexColors.TextPrimary)
            }
            PlayCircleButton(isPlaying = state.isPlaying, onClick = onPlayPause, size = 42.dp)
            IconButton(onClick = onNext, enabled = state.hasNext) {
                Icon(
                    Icons.Rounded.SkipNext,
                    contentDescription = "Next track",
                    tint = if (state.hasNext) VortexColors.TextPrimary else VortexColors.TextSecondary.copy(alpha = 0.4f),
                )
            }
        }
        ProgressLine(
            fraction = progress,
            height = 2.dp,
            modifier = Modifier.padding(horizontal = 12.dp).padding(bottom = 6.dp),
        )
    }
}
