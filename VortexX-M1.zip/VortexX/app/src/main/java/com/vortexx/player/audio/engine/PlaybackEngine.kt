package com.vortexx.player.audio.engine

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import com.vortexx.player.audio.media3.VortexAudioProcessor
import com.vortexx.player.audio.media3.VortexRenderersFactory
import com.vortexx.player.di.ApplicationScope
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The music playback engine. It builds the ExoPlayer with the VORTEX X
 * processor in Media3's PCM chain, applies the output mode the user chose,
 * and reports the mode Media3 actually opened:
 *
 * - **DSP (PCM)**: decoded PCM passes through [VortexAudioProcessor].
 * - **Offload**: the hardware decodes; Media3 runs no processors.
 * - **Passthrough**: encoded audio (e.g. AC-3 to a receiver) goes out unchanged.
 *
 * [status] is decided from Media3's output config and the processor's own
 * report, never from the preference alone, so the Audio Lab cannot show
 * processing that is not happening.
 */
@Singleton
class PlaybackEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val audio: AudioEngine,
    private val diagnostics: AudioDiagnostics,
    @ApplicationScope appScope: CoroutineScope,
) {
    private val latencyTracker = LatencyTracker()
    private val _latency = MutableStateFlow(LatencyReadings())

    /** Measured delays; sampled only while something (the Audio Lab) collects this flow. */
    val latency: StateFlow<LatencyReadings> = _latency.asStateFlow()

    val status: StateFlow<DspStatus> = combine(audio.state, audio.outputMode, audio.processor, diagnostics.state) { params, mode, processor, path ->
        val output = path.output
        DspStatusResolver.resolve(
            outputOpen = output != null,
            outputIsPcm = output?.isPcm ?: true,
            outputOffload = output?.offload ?: false,
            processorActive = processor.format != null,
            processorReason = processor.inactiveReason,
            userEnabled = params.enabled,
            mode = mode,
        )
    }.stateIn(appScope, SharingStarted.Eagerly, IDLE)

    /** Builds the music player. Call once per PlaybackService instance, then [bind]. */
    @androidx.annotation.OptIn(UnstableApi::class)
    fun createMusicPlayer(): ExoPlayer {
        // Decoder fallback lets ExoPlayer try a secondary decoder if the primary one fails to initialise.
        val renderersFactory = VortexRenderersFactory(context, VortexAudioProcessor(audio))
            .setEnableDecoderFallback(true)
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val player = ExoPlayer.Builder(context, renderersFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addAnalyticsListener(diagnostics.analyticsListener())
        player.addAnalyticsListener(latencyListener())
        diagnostics.startRouteTracking()
        return player
    }

    /** Applies the output mode and runs latency sampling for as long as [scope] (main thread) lives. */
    fun bind(player: ExoPlayer, scope: CoroutineScope) {
        scope.launch {
            audio.outputMode.collect { mode -> applyOutputMode(player, mode) }
        }
        scope.launch {
            _latency.subscriptionCount
                .map { it > 0 }
                .distinctUntilChanged()
                .collectLatest { watched -> if (watched) sampleChangeToEar(player) }
        }
    }

    /** Call when the service releases its player. */
    fun unbind() {
        diagnostics.stopRouteTracking()
    }

    /**
     * DSP mode keeps offload disabled so decoded PCM reaches the processor.
     * Battery mode allows hardware offload where the phone supports it; the
     * processor then declines the stream and [status] reports what Media3 opened.
     */
    private fun applyOutputMode(player: ExoPlayer, mode: OutputModePreference) {
        val offload = TrackSelectionParameters.AudioOffloadPreferences.Builder()
            .setAudioOffloadMode(
                if (mode == OutputModePreference.Offload) {
                    TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED
                } else {
                    TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
                },
            )
            .setIsGaplessSupportRequired(true)
            .build()
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setAudioOffloadPreferences(offload)
            .build()
    }

    /** Compares the processor's head with the player's position twice a second while the Lab is open. */
    private suspend fun sampleChangeToEar(player: ExoPlayer) {
        while (true) {
            delay(SAMPLE_INTERVAL_MS)
            if (!player.isPlaying) continue
            val output = diagnostics.state.value.output ?: continue
            if (!output.isPcm || output.offload || audio.processor.value.format == null) continue
            latencyTracker.onPositionSample(
                processedPositionUs = audio.processedPositionUs,
                playbackPositionMs = player.currentPosition,
                speed = player.playbackParameters.speed,
            )
            _latency.value = latencyTracker.readings
        }
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    private fun latencyListener(): AnalyticsListener = object : AnalyticsListener {
        override fun onIsPlayingChanged(eventTime: AnalyticsListener.EventTime, isPlaying: Boolean) {
            if (isPlaying) latencyTracker.onPlaybackStarted(System.currentTimeMillis()) else latencyTracker.onPlaybackStopped()
        }

        override fun onAudioPositionAdvancing(eventTime: AnalyticsListener.EventTime, playoutStartSystemTimeMs: Long) {
            latencyTracker.onPlayoutStarted(playoutStartSystemTimeMs)
            _latency.value = latencyTracker.readings
        }

        override fun onAudioTrackInitialized(eventTime: AnalyticsListener.EventTime, audioTrackConfig: AudioSink.AudioTrackConfig) {
            // A new output (route, format or mode change) has its own delay; restart the median.
            latencyTracker.clearWindow()
            _latency.value = latencyTracker.readings
        }
    }

    private companion object {
        const val SAMPLE_INTERVAL_MS = 500L
        val IDLE = DspStatusResolver.resolve(
            outputOpen = false,
            outputIsPcm = true,
            outputOffload = false,
            processorActive = false,
            processorReason = null,
            userEnabled = true,
            mode = OutputModePreference.Dsp,
        )
    }
}
