package com.vortexx.player.audio.media3

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import com.vortexx.player.audio.dsp.DspChain
import com.vortexx.player.audio.dsp.DspHost
import com.vortexx.player.audio.dsp.ProcessorFormat
import java.nio.ByteBuffer

/**
 * VORTEX X's DSP inside Media3's PCM pipeline (DefaultAudioSink). Accepts
 * 16-bit and float PCM at any sample rate, 1–8 channels, and returns the same
 * format, so nothing else in the sink changes. For any other input it reports
 * itself inactive and audio passes untouched; the reason is published so the
 * Audio Lab never shows processing that is not happening.
 *
 * Media3 does not route encoded passthrough or offloaded audio through audio
 * processors at all; the playback engine reports those modes separately.
 */
@UnstableApi
class VortexAudioProcessor(private val host: DspHost) : BaseAudioProcessor() {

    private val chain = DspChain(host.meters)
    private val work = FloatArray(CHUNK_FRAMES * DspChain.MAX_CHANNELS)

    private var pendingFormat: AudioProcessor.AudioFormat? = null
    private var pendingReason: String? = null

    private var activeEncoding = C.ENCODING_INVALID
    private var activeSampleRate = 0
    private var activeChannels = 0

    private var streamOffsetUs = C.TIME_UNSET
    private var framesSinceFlush = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (!host.processingAllowed) {
            return inactive("Battery mode: hardware offload preferred, DSP off")
        }
        val encoding = inputAudioFormat.encoding
        if (encoding != C.ENCODING_PCM_16BIT && encoding != C.ENCODING_PCM_FLOAT) {
            return inactive("DSP needs 16-bit or float PCM; stream is ${AudioEncodings.name(encoding)}")
        }
        if (inputAudioFormat.channelCount !in 1..DspChain.MAX_CHANNELS) {
            return inactive("DSP supports 1–${DspChain.MAX_CHANNELS} channels; stream has ${inputAudioFormat.channelCount}")
        }
        if (inputAudioFormat.sampleRate <= 0) {
            return inactive("Unknown sample rate")
        }
        pendingFormat = inputAudioFormat
        pendingReason = null
        return inputAudioFormat
    }

    private fun inactive(reason: String): AudioProcessor.AudioFormat {
        pendingFormat = null
        pendingReason = reason
        // An inactive processor gets no flush or input from Media3, so clear the position here.
        streamOffsetUs = C.TIME_UNSET
        framesSinceFlush = 0L
        host.onProcessedPosition(DspHost.UNKNOWN_POSITION_US)
        host.onProcessorConfigured(null, reason)
        return AudioProcessor.AudioFormat.NOT_SET
    }

    /**
     * Media3 1.11: flush carries the stream position (µs, aligned to the window
     * start) of the first sample that follows, so the processor knows the media
     * time of every sample it finishes. That position, compared with the
     * player's playback position, gives the measured change-to-ear delay.
     */
    override fun onFlush(streamMetadata: AudioProcessor.StreamMetadata) {
        framesSinceFlush = 0L
        val format = pendingFormat
        if (format == null) {
            streamOffsetUs = C.TIME_UNSET
            activeEncoding = C.ENCODING_INVALID
            activeSampleRate = 0
            activeChannels = 0
            host.onProcessedPosition(DspHost.UNKNOWN_POSITION_US)
            host.onProcessorConfigured(null, pendingReason)
            return
        }
        if (format.sampleRate != chain.sampleRate || format.channelCount != chain.channelCount) {
            chain.configure(format.sampleRate, format.channelCount)
        } else {
            chain.resetState()
        }
        activeEncoding = format.encoding
        activeSampleRate = format.sampleRate
        activeChannels = format.channelCount
        streamOffsetUs = streamMetadata.positionOffsetUs
        host.onProcessedPosition(if (streamOffsetUs == C.TIME_UNSET) DspHost.UNKNOWN_POSITION_US else streamOffsetUs)
        host.onProcessorConfigured(
            ProcessorFormat(format.sampleRate, format.channelCount, AudioEncodings.name(format.encoding)),
            null,
        )
    }

    override fun onReset() {
        streamOffsetUs = C.TIME_UNSET
        framesSinceFlush = 0L
        pendingFormat = null
        pendingReason = null
        activeEncoding = C.ENCODING_INVALID
        activeSampleRate = 0
        activeChannels = 0
        chain.resetState()
        host.onProcessedPosition(DspHost.UNKNOWN_POSITION_US)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val channels = activeChannels
        if (channels == 0) {
            // Not configured for processing: pass through unchanged.
            val passthrough = replaceOutputBuffer(remaining)
            passthrough.put(inputBuffer)
            passthrough.flip()
            return
        }
        val started = System.nanoTime()
        val isFloat = activeEncoding == C.ENCODING_PCM_FLOAT
        val bytesPerSample = if (isFloat) 4 else 2
        val frames = remaining / (bytesPerSample * channels)
        if (frames == 0) return
        val output = replaceOutputBuffer(frames * channels * bytesPerSample)
        val buffer = work
        chain.apply(host.parameters)

        // Bounded chunks: the work array is allocated once, whatever buffer size Media3 sends.
        var done = 0
        while (done < frames) {
            val chunk = minOf(CHUNK_FRAMES, frames - done)
            val samples = chunk * channels
            if (isFloat) {
                for (i in 0 until samples) buffer[i] = inputBuffer.getFloat()
            } else {
                for (i in 0 until samples) buffer[i] = inputBuffer.getShort() * INT16_TO_FLOAT
            }
            chain.process(buffer, chunk, started)
            if (isFloat) {
                // Sample ceiling: never hand the output more than full scale. Overs are already counted.
                for (i in 0 until samples) {
                    val x = buffer[i]
                    output.putFloat(if (x > 1f) 1f else if (x < -1f) -1f else x)
                }
            } else {
                for (i in 0 until samples) {
                    val value = Math.round(buffer[i] * FLOAT_TO_INT16)
                    val clamped = if (value > Short.MAX_VALUE) Short.MAX_VALUE.toInt() else if (value < Short.MIN_VALUE) Short.MIN_VALUE.toInt() else value
                    output.putShort(clamped.toShort())
                }
            }
            done += chunk
        }
        // Media3 sends whole frames; mark any stray trailing bytes as consumed.
        inputBuffer.position(inputBuffer.limit())
        output.flip()
        framesSinceFlush += frames
        if (streamOffsetUs != C.TIME_UNSET) {
            host.onProcessedPosition(streamOffsetUs + framesSinceFlush * 1_000_000L / activeSampleRate)
        }
        host.load.record(System.nanoTime() - started, frames, activeSampleRate)
    }

    private companion object {
        const val CHUNK_FRAMES = 1024
        const val FLOAT_TO_INT16 = 32768f
        const val INT16_TO_FLOAT = 1f / 32768f
    }
}
