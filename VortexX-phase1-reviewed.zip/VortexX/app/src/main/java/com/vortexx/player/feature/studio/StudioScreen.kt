package com.vortexx.player.feature.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.vortexx.player.core.capabilities.DeviceCapabilities
import com.vortexx.player.core.capabilities.EffectInfo
import com.vortexx.player.core.capabilities.EqualizerInfo
import com.vortexx.player.core.capabilities.OutputDevice
import com.vortexx.player.core.capabilities.SpatialAudioInfo
import com.vortexx.player.ui.designsystem.components.InfoLine
import com.vortexx.player.ui.designsystem.components.InlineNotice
import com.vortexx.player.ui.designsystem.components.LoadingState
import com.vortexx.player.ui.designsystem.components.NoticeTone
import com.vortexx.player.ui.designsystem.components.SecondaryButton
import com.vortexx.player.ui.designsystem.components.SectionHeader
import com.vortexx.player.ui.designsystem.components.VortexCard
import com.vortexx.player.ui.designsystem.components.VortexTopBar
import com.vortexx.player.ui.designsystem.theme.VortexColors
import com.vortexx.player.ui.designsystem.theme.VortexSpacing
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class StudioUi(
    val equalizer: EqualizerInfo?,
    val effects: List<EffectInfo>,
    val outputs: List<OutputDevice>,
    val spatial: SpatialAudioInfo,
)

@HiltViewModel
class StudioViewModel @Inject constructor(
    private val capabilities: DeviceCapabilities,
) : ViewModel() {
    private val _ui = MutableStateFlow<StudioUi?>(null)
    val ui: StateFlow<StudioUi?> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            _ui.value = withContext(Dispatchers.Default) {
                StudioUi(
                    equalizer = capabilities.equalizer(),
                    effects = capabilities.audioEffects(),
                    outputs = capabilities.outputDevices(),
                    spatial = capabilities.spatialAudio(),
                )
            }
        }
    }
}

/**
 * Phase 1 Audio Studio: an honest capability report. No sliders are shown until
 * the processing chain behind them exists (Phase 3), so nothing here pretends to
 * change the sound.
 */
@Composable
fun StudioScreen(
    onBack: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    viewModel: StudioViewModel = hiltViewModel(),
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        VortexTopBar(title = "Audio Studio", subtitle = "Processing capabilities of this device", onBack = onBack)
        val state = ui
        if (state == null) {
            LoadingState("Inspecting audio effects…")
            return@Column
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = VortexSpacing.xl)) {
            item {
                InlineNotice(
                    text = "Audio processing controls arrive in Phase 3. This screen reports what the device offers; it does not alter playback.",
                    tone = NoticeTone.Caution,
                    modifier = Modifier.padding(horizontal = VortexSpacing.lg, vertical = VortexSpacing.sm),
                )
            }

            item { SectionHeader("Device equalizer") }
            item {
                StudioCard {
                    val eq = state.equalizer
                    if (eq == null) {
                        Text("No platform equalizer is available on this device.", style = MaterialTheme.typography.bodyMedium)
                    } else {
                        Text("${eq.bandCount} bands exposed by the platform", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Range ${"%.1f".format(eq.minLevelDb)} to +${"%.1f".format(eq.maxLevelDb)} dB. A custom 10/15/31-band engine would need its own PCM processor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = VortexColors.TextSecondary,
                        )
                        Spacer(Modifier.height(VortexSpacing.lg))
                        BandLayout(eq.centerFrequenciesHz)
                        if (eq.presetNames.isNotEmpty()) {
                            Spacer(Modifier.height(VortexSpacing.md))
                            InfoLine("Built-in presets", eq.presetNames.joinToString())
                        }
                    }
                }
            }

            item { SectionHeader("Available effects") }
            item {
                StudioCard {
                    if (state.effects.isEmpty()) {
                        Text("The platform reported no audio effects.", style = MaterialTheme.typography.bodyMedium)
                    }
                    state.effects.distinctBy { it.kind to it.name }.forEach { InfoLine(it.kind, "${it.name} — ${it.implementor}") }
                }
            }

            item { SectionHeader("Output and spatial audio") }
            item {
                StudioCard {
                    state.outputs.firstOrNull()?.let { InfoLine("Primary output", listOf(it.typeName, it.productName).filter { s -> s.isNotBlank() }.joinToString(" — ")) }
                    InfoLine("Spatializer", state.spatial.level)
                    if (state.spatial.apiAvailable) {
                        InfoLine("Available / enabled", "${if (state.spatial.available) "Yes" else "No"} / ${if (state.spatial.enabled) "Yes" else "No"}")
                    }
                    Spacer(Modifier.height(VortexSpacing.md))
                    SecondaryButton(text = "Full diagnostics", onClick = onOpenDiagnostics, icon = Icons.Rounded.Analytics)
                }
            }

            item { SectionHeader("Phase 3 plan") }
            item {
                StudioCard {
                    listOf(
                        "Equalizer using only the bands this device exposes, with Flat, Bass, Vocal, Classical, Rock, Cinema, Podcast, Night and custom presets",
                        "Bass boost and virtualizer where the platform supports them",
                        "Loudness and dynamics via DynamicsProcessing with headroom to prevent clipping",
                        "Bypass switch, persistent profiles and automatic disable during encoded passthrough",
                    ).forEach { line ->
                        Row(Modifier.padding(vertical = VortexSpacing.xs)) {
                            Text("•", color = VortexColors.Accent, modifier = Modifier.width(16.dp))
                            Text(line, style = MaterialTheme.typography.bodyMedium, color = VortexColors.TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

/** Static band map (frequency labels only) — a layout preview, not a control. */
@Composable
private fun BandLayout(frequenciesHz: List<Int>) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(72.dp)
            .semantics { contentDescription = "Band centres: ${frequenciesHz.joinToString { label(it) }}" },
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom,
    ) {
        frequenciesHz.forEach { hz ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .width(6.dp)
                        .height(40.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(VortexColors.Divider),
                )
                Spacer(Modifier.height(VortexSpacing.xs))
                Text(label(hz), style = MaterialTheme.typography.labelSmall, color = VortexColors.TextSecondary)
            }
        }
    }
}

private fun label(hz: Int): String = if (hz >= 1000) "${"%.1f".format(hz / 1000f).removeSuffix(".0")}k" else "$hz"

@Composable
private fun StudioCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    VortexCard(
        modifier = Modifier
            .padding(horizontal = VortexSpacing.lg)
            .widthIn(max = 840.dp)
            .fillMaxWidth(),
        content = content,
    )
}
