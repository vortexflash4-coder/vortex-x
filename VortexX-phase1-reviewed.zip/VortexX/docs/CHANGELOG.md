# Changelog

## 2026-11-11 — Phase 1 review pass

Status: **Written** (not compiled; see `docs/BUILD_STATUS.md`).

### Changed
- `.github/workflows/android-ci.yml`: every Gradle step now writes its full log to `ci-logs/`. The run always ends with a job summary and a logs artifact, even when the build fails. The run is still marked failed when `assembleDebug`, `testDebugUnitTest` or `assembleDebugAndroidTest` fails. Unit tests and the instrumentation-test compile run only after the APK builds, so the Errors box shows the first real failure.
- Artifacts: `vortex-x-debug-apk` (unchanged). `vortex-x-logs-and-reports` replaces `vortex-x-reports` and now also contains the Gradle logs.
- `feature/music/CollectionScreen.kt`: `SongActionsHost` is called directly instead of inside an empty `Box` (no behaviour change; removed unused import).
- `README.md`: phone-only build instructions now cover the zip-upload route.

### Added
- `.github/scripts/ci-summary.sh`: job summary with "APK built" (name + size) or "APK was not built", unit-test counts with failed test names, and an Errors box trimmed to `file:line`. Up to 10 errors also appear as annotations on the run page.
- `docs/phone-build/build-from-zip.yml`: workflow for a repository that contains only the project ZIP. Uploading the ZIP from a phone browser builds the APK with the same checks and summary.
- `docs/BUILD_STATUS.md`, `docs/CHANGELOG.md`.

### Static review result
No definite compile error found in the 57 Kotlin files, the manifest or the resources. This does not prove the project compiles; the first CI run decides.
