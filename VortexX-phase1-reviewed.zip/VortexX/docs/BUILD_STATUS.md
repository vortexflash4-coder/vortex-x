# Build status — VORTEX X Phase 1

Last updated: 2026-11-11

## Evidence levels

| Level | Meaning |
|---|---|
| **Written** | The code exists in this repository. |
| **Compiled** | A green GitHub Actions run built it (`assembleDebug`). |
| **Unit-tested** | JVM tests for it passed in CI (`testDebugUnitTest`). |
| **Device-tested** | The owner confirmed it on a real phone. |

## Current state

**Nothing has been compiled yet.** The authoring environment has no GitHub account linked and cannot reach Maven Central, Google Maven or the Gradle distribution server, so no build or test has run. The first GitHub Actions run is the compile gate.

What was done instead (2026-11-11): a line-by-line static review of all 57 Kotlin files (51 app, 3 unit-test, 3 instrumented-test), the manifest, resources and Gradle files against the pinned versions. Checks: every project import resolves to a declared symbol; every `Object.member` reference exists; Compose scope rules (`weight`/`align` only inside Row/Column/Box); state-delegate imports; exhaustive `when` over enums and sealed types; Hilt/Room/KSP annotations; Media3 `@UnstableApi` opt-ins; resource XML well-formedness; icon names. The JVM unit-test expectations were also traced by hand against the logic they test. One cleanup was made (see CHANGELOG). A static review is not a compile: treat every row below as **Written** only.

| Feature | Written | Compiled | Unit-tested | Device-tested |
|---|---|---|---|---|
| Design system (tokens, components, previews) | Yes | No | — | No |
| Navigation (bottom bar / rail, 12 destinations) | Yes | No | — | No |
| Media permissions + first-launch screen | Yes | No | — | No |
| Music library (MediaStore, search, sort, grouping) | Yes | No | Tests written, not run (`LibraryLogicTest`) | No |
| Background playback (MediaSessionService, notification, focus, noisy) | Yes | No | — | No |
| Queue (jump, reorder, remove, clear, save) | Yes | No | — | No |
| Playlists and favourites (Room) | Yes | No | Instrumented tests written, not run (`VortexDatabaseTest`) | No |
| Video player (PlayerView, scaling, rotation lock, resume) | Yes | No | Resume rules: tests written, not run (`PoliciesAndFormatTest`) | No |
| Media Explorer (folders, open file via picker) | Yes | No | Folder merge: tests written, not run | No |
| Audio Studio (capability report only) | Yes | No | — | No |
| Diagnostics (decoders, outputs, spatializer, HDR) | Yes | No | — | No |
| Settings (4 levels, search, reset) | Yes | No | Tests written, not run (`SettingsTest`) | No |
| Playback error explanations | Yes | No | Tests written, not run | No |
| CI job summary (APK built/not built, test counts, Errors box) | Yes | No | Script tested locally on sample logs | — |

## When the first CI run finishes

- **Green:** change the "Compiled" column to Yes for every row, record the run link and APK size here, then install the APK and fill "Device-tested" from `docs/TESTING.md` (manual table).
- **Red:** copy the job summary's Errors box into the chat. Fixes return as complete files (or a full ZIP when more than 10 files change).
