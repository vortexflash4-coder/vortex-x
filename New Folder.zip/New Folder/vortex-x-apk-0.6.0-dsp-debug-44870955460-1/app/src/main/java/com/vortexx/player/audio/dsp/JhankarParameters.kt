package com.vortexx.player.audio.dsp

/** Ranges and defaults of the Jhankar Sound Studio. Every control on screen takes its limits from here. */
object JhankarTone {
    const val BANDS = 10
    val DEFAULT_FREQ_HZ: FloatArray = floatArrayOf(31.5f, 63f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    const val MIN_FREQ_HZ = 20f
    const val MAX_FREQ_HZ = 20000f
    const val MIN_Q = 0.3f
    const val MAX_Q = 8f
    const val DEFAULT_Q = 1.1f
    const val MAX_BAND_DB = 12f
    const val MAX_PREAMP_DB = 12f
    const val MAX_SUB_DB = 6f
    const val MIN_OUTPUT_DB = -12f
    const val MAX_OUTPUT_DB = 6f
    const val MIN_WIDTH = 50
    const val MAX_WIDTH = 200
    const val MAX_MONO_HZ = 250
    const val MIN_MONO_HZ = 60
    const val MIN_WOOFER_GUARD_HZ = 30
    const val MAX_WOOFER_GUARD_HZ = 65
    const val DEFAULT_INTENSITY = 80
}

/** One band of the Jhankar equalizer: band 1 is a low shelf, band 10 a high shelf, the others are bell filters. */
data class JhankarBand(val freqHz: Float, val gainDb: Float, val q: Float)

/**
 * Complete setting of the Jhankar & True-HD Tower engine for one output profile.
 * Includes Dolby Atmos 3D spatial height/room virtualization, local tower cabinet de-boxiness,
 * sub-sonic woofer excursion guard, and dynamic piezo/sibilance de-harsher.
 */
data class JhankarParameters(
    val engine: Boolean = false,
    val intensity: Int = JhankarTone.DEFAULT_INTENSITY,
    val eqOn: Boolean = true,
    val preampDb: Float = 0f,
    val autoHeadroom: Boolean = true,
    val bands: List<JhankarBand> = FLAT_BANDS,
    val bassOn: Boolean = true,
    val dynamicBass: Int = 0,
    val subBassDb: Float = 0f,
    val bassHarmonics: Int = 0,
    val vocalClarity: Int = 0,
    val hfDetail: Int = 0,
    val airHarmonics: Int = 0,
    val stereoOn: Boolean = true,
    val widthPercent: Int = 100,
    val monoBelowHz: Int = 0,
    val transient: Int = 0,
    val compression: Int = 0,
    val loudness: Int = 0,
    val outputGainDb: Float = 0f,
    val atmos3d: Int = 0,
    val cabinetDeMud: Int = 0,
    val wooferGuardHz: Int = 0,
    val deHarsh: Int = 0,
) {
    fun withBand(index: Int, band: JhankarBand): JhankarParameters =
        copy(bands = bands.mapIndexed { i, b -> if (i == index) clampBand(band) else b })

    fun clamped(): JhankarParameters = copy(
        intensity = clampPercent(intensity),
        preampDb = clampPreamp(preampDb),
        bands = if (bands.size == JhankarTone.BANDS) bands.map { clampBand(it) } else FLAT_BANDS,
        dynamicBass = clampPercent(dynamicBass),
        subBassDb = clampSub(subBassDb),
        bassHarmonics = clampPercent(bassHarmonics),
        vocalClarity = clampPercent(vocalClarity),
        hfDetail = clampPercent(hfDetail),
        airHarmonics = clampPercent(airHarmonics),
        widthPercent = clampWidth(widthPercent),
        monoBelowHz = clampMono(monoBelowHz),
        transient = clampPercent(transient),
        compression = clampPercent(compression),
        loudness = clampPercent(loudness),
        outputGainDb = clampOutput(outputGainDb),
        atmos3d = clampPercent(atmos3d),
        cabinetDeMud = clampPercent(cabinetDeMud),
        wooferGuardHz = clampWooferGuard(wooferGuardHz),
        deHarsh = clampPercent(deHarsh),
    )

    fun withFlatEq(): JhankarParameters = copy(preampDb = 0f, bands = FLAT_BANDS)

    fun sameSoundAs(other: JhankarParameters): Boolean = copy(engine = false) == other.copy(engine = false)

    private fun hasExtendedFields(): Boolean =
        atmos3d != 0 || cabinetDeMud != 0 || wooferGuardHz != 0 || deHarsh != 0

    fun encode(): String {
        val base = listOf(
            if (hasExtendedFields()) FORMAT_V2 else FORMAT_V1,
            flag(engine), intensity, flag(eqOn), preampDb, flag(autoHeadroom),
            flag(bassOn), dynamicBass, subBassDb, bassHarmonics,
            vocalClarity, hfDetail, airHarmonics,
            flag(stereoOn), widthPercent, monoBelowHz,
            transient, compression, loudness, outputGainDb,
            bands.joinToString("|") { "${it.freqHz},${it.gainDb},${it.q}" },
        )
        return if (hasExtendedFields()) {
            (base + listOf(atmos3d, cabinetDeMud, wooferGuardHz, deHarsh)).joinToString(";")
        } else {
            base.joinToString(";")
        }
    }

    companion object {
        private const val FORMAT_V1 = "J1"
        private const val FORMAT_V2 = "J2"
        private const val PARTS_V1 = 21
        private const val PARTS_V2 = 25

        val FLAT_BANDS: List<JhankarBand> =
            JhankarTone.DEFAULT_FREQ_HZ.map { JhankarBand(it, 0f, JhankarTone.DEFAULT_Q) }

        val OFF = JhankarParameters()

        private fun flag(on: Boolean) = if (on) "1" else "0"

        fun clampFreq(hz: Float): Float =
            if (hz.isNaN()) 1000f else hz.coerceIn(JhankarTone.MIN_FREQ_HZ, JhankarTone.MAX_FREQ_HZ)

        fun clampQ(q: Float): Float = if (q.isNaN()) JhankarTone.DEFAULT_Q else q.coerceIn(JhankarTone.MIN_Q, JhankarTone.MAX_Q)

        fun clampBandDb(db: Float): Float = if (db.isNaN()) 0f else db.coerceIn(-JhankarTone.MAX_BAND_DB, JhankarTone.MAX_BAND_DB)

        fun clampPreamp(db: Float): Float = if (db.isNaN()) 0f else db.coerceIn(-JhankarTone.MAX_PREAMP_DB, JhankarTone.MAX_PREAMP_DB)

        fun clampSub(db: Float): Float = if (db.isNaN()) 0f else db.coerceIn(-JhankarTone.MAX_SUB_DB, JhankarTone.MAX_SUB_DB)

        fun clampOutput(db: Float): Float =
            if (db.isNaN()) 0f else db.coerceIn(JhankarTone.MIN_OUTPUT_DB, JhankarTone.MAX_OUTPUT_DB)

        fun clampPercent(value: Int): Int = value.coerceIn(0, 100)

        fun clampWidth(value: Int): Int = value.coerceIn(JhankarTone.MIN_WIDTH, JhankarTone.MAX_WIDTH)

        /** 0 = off, otherwise 60…250 Hz. */
        fun clampMono(hz: Int): Int = if (hz <= 0) 0 else hz.coerceIn(JhankarTone.MIN_MONO_HZ, JhankarTone.MAX_MONO_HZ)

        /** 0 = off, otherwise 30…65 Hz sub-sonic woofer protection HPF. */
        fun clampWooferGuard(hz: Int): Int = if (hz <= 0) 0 else hz.coerceIn(JhankarTone.MIN_WOOFER_GUARD_HZ, JhankarTone.MAX_WOOFER_GUARD_HZ)

        fun clampBand(band: JhankarBand): JhankarBand =
            JhankarBand(clampFreq(band.freqHz), clampBandDb(band.gainDb), clampQ(band.q))

        fun decode(raw: String?): JhankarParameters? {
            if (raw == null) return null
            val p = raw.trim().split(';')
            val isV1 = p.size == PARTS_V1 && p[0] == FORMAT_V1
            val isV2 = p.size == PARTS_V2 && p[0] == FORMAT_V2
            if (!isV1 && !isV2) return null
            val bandTexts = p[20].split('|')
            if (bandTexts.size != JhankarTone.BANDS) return null
            val bands = ArrayList<JhankarBand>(JhankarTone.BANDS)
            for (text in bandTexts) {
                val v = text.split(',')
                if (v.size != 3) return null
                val f = v[0].toFloatOrNull() ?: return null
                val g = v[1].toFloatOrNull() ?: return null
                val q = v[2].toFloatOrNull() ?: return null
                bands += clampBand(JhankarBand(f, g, q))
            }
            return try {
                JhankarParameters(
                    engine = p[1] == "1",
                    intensity = clampPercent(p[2].toInt()),
                    eqOn = p[3] == "1",
                    preampDb = clampPreamp(p[4].toFloat()),
                    autoHeadroom = p[5] == "1",
                    bands = bands,
                    bassOn = p[6] == "1",
                    dynamicBass = clampPercent(p[7].toInt()),
                    subBassDb = clampSub(p[8].toFloat()),
                    bassHarmonics = clampPercent(p[9].toInt()),
                    vocalClarity = clampPercent(p[10].toInt()),
                    hfDetail = clampPercent(p[11].toInt()),
                    airHarmonics = clampPercent(p[12].toInt()),
                    stereoOn = p[13] == "1",
                    widthPercent = clampWidth(p[14].toInt()),
                    monoBelowHz = clampMono(p[15].toInt()),
                    transient = clampPercent(p[16].toInt()),
                    compression = clampPercent(p[17].toInt()),
                    loudness = clampPercent(p[18].toInt()),
                    outputGainDb = clampOutput(p[19].toFloat()),
                    atmos3d = if (isV2) clampPercent(p[21].toInt()) else 0,
                    cabinetDeMud = if (isV2) clampPercent(p[22].toInt()) else 0,
                    wooferGuardHz = if (isV2) clampWooferGuard(p[23].toInt()) else 0,
                    deHarsh = if (isV2) clampPercent(p[24].toInt()) else 0,
                )
            } catch (_: NumberFormatException) {
                null
            }
        }
    }
}

enum class OutputProfile(val label: String, val summary: String) {
    Tower("Bluetooth Tower", "True-HD Studio clarity, sub-40 Hz woofer guard, anti-boxiness, 3D Atmos stage"),
    PartySpeaker("Party Speaker", "Tight mid-bass punch, clear percussion, piezo tweeter guard, zero clipping"),
    PremiumStereo("Premium Stereo", "Wide 3D Dolby Atmos stage, detailed Hindi vocals, natural dynamics"),
    Headphone("Headphones", "3D spatial binaural stage, crystal vocal clarity, safe peak level");

    companion object {
        fun fromName(name: String?): OutputProfile = entries.firstOrNull { it.name == name } ?: PremiumStereo
    }
}

data class JhankarPreset(val name: String, val note: String, val parameters: JhankarParameters, val builtIn: Boolean)

data class JhankarPresetEdit(val presets: List<JhankarPreset>, val result: PresetResult)

object JhankarPresets {
    const val MAX_USER_PRESETS = 12
    const val MAX_NAME_LENGTH = 24

    private fun bands(gains: FloatArray, q: Float = JhankarTone.DEFAULT_Q): List<JhankarBand> =
        JhankarTone.DEFAULT_FREQ_HZ.mapIndexed { i, f -> JhankarBand(f, gains[i], q) }

    private fun built(
        name: String,
        note: String,
        gains: FloatArray,
        intensity: Int,
        dynamicBass: Int = 0,
        subBassDb: Float = 0f,
        bassHarmonics: Int = 0,
        vocalClarity: Int = 0,
        hfDetail: Int = 0,
        airHarmonics: Int = 0,
        widthPercent: Int = 100,
        monoBelowHz: Int = 0,
        transient: Int = 0,
        compression: Int = 0,
        loudness: Int = 0,
        outputGainDb: Float = 0f,
        atmos3d: Int = 0,
        cabinetDeMud: Int = 0,
        wooferGuardHz: Int = 0,
        deHarsh: Int = 0,
    ) = JhankarPreset(
        name,
        note,
        JhankarParameters(
            intensity = intensity,
            bands = bands(gains),
            dynamicBass = dynamicBass,
            subBassDb = subBassDb,
            bassHarmonics = bassHarmonics,
            vocalClarity = vocalClarity,
            hfDetail = hfDetail,
            airHarmonics = airHarmonics,
            widthPercent = widthPercent,
            monoBelowHz = monoBelowHz,
            transient = transient,
            compression = compression,
            loudness = loudness,
            outputGainDb = outputGainDb,
            atmos3d = atmos3d,
            cabinetDeMud = cabinetDeMud,
            wooferGuardHz = wooferGuardHz,
            deHarsh = deHarsh,
        ),
        builtIn = true,
    )

    // Band centres: 31.5, 63, 125, 250, 500, 1k, 2k, 4k, 8k, 16k Hz.
    val JHANKAR_ORIGINAL = built(
        "Jhankar Original", "True-HD 3D Atmos Jhankar: sparkling chimes, tight dholak punch, crystal vocals",
        floatArrayOf(2.0f, 3.5f, 1.5f, -2.5f, -1.0f, 0.5f, 1.5f, 2.0f, 2.0f, 2.5f),
        intensity = 82, dynamicBass = 50, subBassDb = 1.0f, bassHarmonics = 45, vocalClarity = 45, hfDetail = 40,
        airHarmonics = 50, widthPercent = 135, monoBelowHz = 130, transient = 45, compression = 35, loudness = 15,
        atmos3d = 75, cabinetDeMud = 65, wooferGuardHz = 36, deHarsh = 60,
    )
    val HINDI_90S = built(
        "Hindi 90s Remastered", "Restores crystal 90s Jhankar chimes and warm analog vocals in 3D space",
        floatArrayOf(0.5f, 2.5f, 2.0f, -2.0f, -1.0f, 1.0f, 2.0f, 2.2f, 2.0f, 2.5f),
        intensity = 80, dynamicBass = 45, bassHarmonics = 40, vocalClarity = 50, hfDetail = 40, airHarmonics = 45,
        widthPercent = 125, monoBelowHz = 120, transient = 35, compression = 30, loudness = 15,
        atmos3d = 65, cabinetDeMud = 60, wooferGuardHz = 36, deHarsh = 55,
    )
    val BOLLYWOOD_LIVE = built(
        "Bollywood Live Stage", "Dolby Atmos 3D concert hall: overhead height, wide stage, snapping beats",
        floatArrayOf(2.0f, 3.2f, 1.0f, -2.0f, -0.5f, 1.0f, 1.8f, 2.0f, 2.2f, 2.5f),
        intensity = 85, dynamicBass = 45, bassHarmonics = 40, vocalClarity = 40, hfDetail = 40, airHarmonics = 55,
        widthPercent = 148, monoBelowHz = 130, transient = 45, compression = 35, loudness = 15,
        atmos3d = 88, cabinetDeMud = 60, wooferGuardHz = 38, deHarsh = 55,
    )
    val DHOLAK_TABLA = built(
        "Dholak & Tabla Punch", "Fast transient snap on tabla & ghungroo with chest-thumping dholak kick",
        floatArrayOf(1.5f, 3.2f, 2.5f, -2.0f, -1.5f, 0.5f, 2.0f, 3.0f, 2.0f, 2.0f),
        intensity = 85, dynamicBass = 40, bassHarmonics = 35, vocalClarity = 35, hfDetail = 40, widthPercent = 122,
        monoBelowHz = 130, transient = 75, compression = 35,
        atmos3d = 55, cabinetDeMud = 65, wooferGuardHz = 40, deHarsh = 50,
    )
    val CRYSTAL_VOCALS = built(
        "Crystal Clear Vocals", "Studio-front Hindi vocals, zero boxiness, silky de-harshed treble",
        floatArrayOf(-1.0f, 0.5f, -0.5f, -3.0f, -1.5f, 1.5f, 2.0f, 1.8f, 2.0f, 2.5f),
        intensity = 80, dynamicBass = 20, vocalClarity = 65, hfDetail = 45, airHarmonics = 40, widthPercent = 118,
        transient = 25, compression = 30,
        atmos3d = 45, cabinetDeMud = 80, wooferGuardHz = 38, deHarsh = 75,
    )
    val DEEP_BASS = built(
        "Deep Bass Jhankar", "Psychoacoustic sub-harmonics: deep chest bass without local woofer rattle",
        floatArrayOf(3.5f, 4.5f, 2.5f, -2.0f, -1.5f, 0.5f, 1.5f, 1.8f, 2.0f, 2.5f),
        intensity = 85, dynamicBass = 75, subBassDb = 1.5f, bassHarmonics = 70, vocalClarity = 35, hfDetail = 35,
        widthPercent = 120, monoBelowHz = 140, transient = 40, compression = 45, loudness = 15,
        atmos3d = 55, cabinetDeMud = 70, wooferGuardHz = 42, deHarsh = 60,
    )
    val WEDDING_DJ = built(
        "Wedding DJ Tower", "Local Tower → True-HD Studio: 40 Hz woofer guard, anti-boxiness, 3D Atmos power",
        floatArrayOf(2.0f, 4.0f, 2.0f, -2.5f, -1.5f, 1.0f, 1.8f, 2.0f, 2.0f, 2.0f),
        intensity = 85, dynamicBass = 65, subBassDb = 1.0f, bassHarmonics = 65, vocalClarity = 45, hfDetail = 35,
        airHarmonics = 45, widthPercent = 135, monoBelowHz = 130, transient = 50, compression = 50, loudness = 25,
        outputGainDb = -0.5f, atmos3d = 78, cabinetDeMud = 85, wooferGuardHz = 40, deHarsh = 75,
    )
    val STUDIO_MASTER = built(
        "Studio Master", "Reference True-HD mastering polish with subtle 3D air and tight dynamics",
        floatArrayOf(1.0f, 1.5f, 0.5f, -1.0f, 0f, 0.5f, 1.0f, 1.5f, 1.5f, 2.0f),
        intensity = 60, dynamicBass = 20, vocalClarity = 25, hfDetail = 25, airHarmonics = 20, widthPercent = 112,
        transient = 15, compression = 20, atmos3d = 35, cabinetDeMud = 35, wooferGuardHz = 34, deHarsh = 35,
    )
    val BALANCED_HIFI = built(
        "Balanced Hi-Fi", "Neutral and natural audiophile clarity with gentle room depth",
        floatArrayOf(0.5f, 1.0f, 0.5f, -0.5f, 0f, 0f, 0.5f, 1.0f, 1.0f, 1.5f),
        intensity = 45, dynamicBass = 15, vocalClarity = 15, hfDetail = 15, widthPercent = 108,
        atmos3d = 25, cabinetDeMud = 25, deHarsh = 25,
    )
    val CUSTOM_PROFESSIONAL = built(
        "Custom Professional", "A clean starting point for your own sound",
        floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        intensity = 60, dynamicBass = 20, vocalClarity = 20, hfDetail = 15, widthPercent = 105, compression = 20,
    )

    val BUILT_IN: List<JhankarPreset> = listOf(
        JHANKAR_ORIGINAL, HINDI_90S, BOLLYWOOD_LIVE, DHOLAK_TABLA, CRYSTAL_VOCALS,
        DEEP_BASS, WEDDING_DJ, STUDIO_MASTER, BALANCED_HIFI, CUSTOM_PROFESSIONAL,
    )

    /** Auto-applied when Bluetooth Tower / Speaker connects: turns any local tower into True-HD Studio quality. */
    fun defaultFor(profile: OutputProfile): JhankarParameters = when (profile) {
        OutputProfile.Tower -> WEDDING_DJ.parameters.copy(
            intensity = 85,
            outputGainDb = -0.5f,
            widthPercent = 135,
            subBassDb = 1.0f,
            atmos3d = 78,
            cabinetDeMud = 85,
            wooferGuardHz = 40,
            deHarsh = 75,
        )
        OutputProfile.PartySpeaker -> BOLLYWOOD_LIVE.parameters.copy(
            bands = bands(floatArrayOf(1.0f, 3.5f, 2.5f, -2.5f, -1.5f, 1.0f, 2.0f, 2.2f, 1.5f, 1.5f)),
            intensity = 85, dynamicBass = 55, subBassDb = 0f, bassHarmonics = 65, widthPercent = 128,
            hfDetail = 30, airHarmonics = 30, compression = 55, outputGainDb = -0.5f,
            atmos3d = 68, cabinetDeMud = 80, wooferGuardHz = 42, deHarsh = 80,
        )
        OutputProfile.PremiumStereo -> BALANCED_HIFI.parameters.copy(
            intensity = 65, widthPercent = 120, vocalClarity = 35, hfDetail = 30, airHarmonics = 25,
            compression = 20, transient = 20, atmos3d = 55, cabinetDeMud = 40, wooferGuardHz = 34, deHarsh = 40,
        )
        OutputProfile.Headphone -> CRYSTAL_VOCALS.parameters.copy(
            bands = bands(floatArrayOf(2.0f, 2.5f, 1.0f, -1.5f, -0.5f, 0.5f, 1.2f, 1.0f, 1.2f, 2.0f)),
            intensity = 65, dynamicBass = 25, vocalClarity = 35, hfDetail = 25, airHarmonics = 25, widthPercent = 115,
            monoBelowHz = 0, transient = 20, compression = 25, loudness = 0, outputGainDb = -3f,
            atmos3d = 60, cabinetDeMud = 35, wooferGuardHz = 30, deHarsh = 50,
        )
    }

    fun matching(parameters: JhankarParameters, user: List<JhankarPreset>): JhankarPreset? =
        BUILT_IN.firstOrNull { it.parameters.sameSoundAs(parameters) } ?: user.firstOrNull { it.parameters.sameSoundAs(parameters) }

    fun cleanName(raw: String): String =
        raw.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim().take(MAX_NAME_LENGTH).trim()

    fun isUsableName(name: String): Boolean =
        name.isNotEmpty() && BUILT_IN.none { it.name.equals(name, ignoreCase = true) }

    private fun indexOfName(presets: List<JhankarPreset>, name: String): Int =
        presets.indexOfFirst { it.name.equals(name, ignoreCase = true) }

    fun saveOutcome(presets: List<JhankarPreset>, rawName: String): PresetResult {
        val name = cleanName(rawName)
        if (!isUsableName(name)) return PresetResult.BadName
        if (indexOfName(presets, name) >= 0) return PresetResult.Overwritten
        return if (presets.size >= MAX_USER_PRESETS) PresetResult.Full else PresetResult.Saved
    }

    fun save(presets: List<JhankarPreset>, rawName: String, parameters: JhankarParameters): JhankarPresetEdit {
        val result = saveOutcome(presets, rawName)
        if (!result.done) return JhankarPresetEdit(presets, result)
        val name = cleanName(rawName)
        val sound = parameters.copy(engine = false)
        val index = indexOfName(presets, name)
        val edited = if (index >= 0) {
            presets.mapIndexed { i, p -> if (i == index) JhankarPreset(p.name, "Your saved sound", sound, builtIn = false) else p }
        } else {
            presets + JhankarPreset(name, "Your saved sound", sound, builtIn = false)
        }
        return JhankarPresetEdit(edited, result)
    }

    fun renameOutcome(presets: List<JhankarPreset>, oldName: String, rawNew: String): PresetResult {
        val from = indexOfName(presets, oldName)
        if (from < 0) return PresetResult.NotFound
        val name = cleanName(rawNew)
        if (!isUsableName(name)) return PresetResult.BadName
        val other = indexOfName(presets, name)
        return if (other >= 0 && other != from) PresetResult.NameTaken else PresetResult.Renamed
    }

    fun rename(presets: List<JhankarPreset>, oldName: String, rawNew: String): JhankarPresetEdit {
        val result = renameOutcome(presets, oldName, rawNew)
        if (!result.done) return JhankarPresetEdit(presets, result)
        val from = indexOfName(presets, oldName)
        val name = cleanName(rawNew)
        return JhankarPresetEdit(presets.mapIndexed { i, p -> if (i == from) p.copy(name = name) else p }, result)
    }

    fun delete(presets: List<JhankarPreset>, name: String): JhankarPresetEdit {
        val index = indexOfName(presets, name)
        if (index < 0) return JhankarPresetEdit(presets, PresetResult.NotFound)
        return JhankarPresetEdit(presets.filterIndexed { i, _ -> i != index }, PresetResult.Deleted)
    }

    fun encodeUser(presets: List<JhankarPreset>): String =
        presets.joinToString("\n") { it.name + "\t" + it.parameters.encode() }

    fun decodeUser(raw: String?): List<JhankarPreset> {
        if (raw.isNullOrBlank()) return emptyList()
        val presets = ArrayList<JhankarPreset>()
        for (line in raw.split('\n')) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val name = cleanName(line.substring(0, tab))
            val parameters = JhankarParameters.decode(line.substring(tab + 1)) ?: continue
            if (!isUsableName(name) || presets.any { it.name.equals(name, ignoreCase = true) }) continue
            presets += JhankarPreset(name, "Your saved sound", parameters, builtIn = false)
        }
        return presets.take(MAX_USER_PRESETS)
    }
}
