package com.vortexx.player.audio.engine

import android.content.Context
import com.vortexx.player.audio.dsp.OutputProfile
import com.vortexx.player.di.ApplicationScope
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class RouteKind(val label: String) {
    Speaker("Phone speaker"),
    Bluetooth("Bluetooth"),
    Wired("Wired"),
    Usb("USB"),
    Hdmi("HDMI"),
    Other("Other output"),
}

data class JhankarRouteState(
    val connected: Boolean = false,
    val kind: RouteKind = RouteKind.Speaker,
    val deviceName: String = "",
    val typeName: String = "",
    val exact: Boolean = false,
    val sampleRates: List<Int> = emptyList(),
    val outputSampleRate: Int = 0,
    val outputChannels: Int = 0,
    val suggested: OutputProfile = OutputProfile.PremiumStereo,
    val lastEvent: String = "No output change yet",
) {
    val codecText: String get() = if (kind == RouteKind.Bluetooth) "Not exposed by Android" else "n/a"
}

object JhankarRoutes {
    private val earbudHints = listOf("buds", "airpods", "ear", "neckband", "rockerz", "tws", "headphone", "wh-", "wf-")

    fun kindOf(typeName: String): RouteKind = when {
        typeName.startsWith("Bluetooth") || typeName == "Hearing aid" -> RouteKind.Bluetooth
        typeName.startsWith("Wired") || typeName == "Analog line out" -> RouteKind.Wired
        typeName.startsWith("USB") -> RouteKind.Usb
        typeName.startsWith("HDMI") || typeName == "Digital line out" -> RouteKind.Hdmi
        typeName == "Built-in speaker" || typeName == "Earpiece" -> RouteKind.Speaker
        else -> RouteKind.Other
    }

    fun defaultProfile(kind: RouteKind, typeName: String): OutputProfile = when (kind) {
        RouteKind.Bluetooth -> if (typeName == "Bluetooth LE headset" || typeName == "Hearing aid") OutputProfile.Headphone else OutputProfile.Tower
        RouteKind.Wired -> OutputProfile.Headphone
        RouteKind.Usb -> if (typeName == "USB headset") OutputProfile.Headphone else OutputProfile.PremiumStereo
        else -> OutputProfile.PremiumStereo
    }

    fun defaultProfileForDevice(kind: RouteKind, typeName: String, productName: String): OutputProfile {
        val base = defaultProfile(kind, typeName)
        if (kind == RouteKind.Bluetooth && base == OutputProfile.Tower && productName.isNotBlank()) {
            val lower = productName.lowercase()
            if (earbudHints.any { lower.contains(it) }) return OutputProfile.Headphone
        }
        return base
    }
}

@Singleton
class JhankarRouteMonitor @Inject constructor(
    @ApplicationContext context: Context,
    private val diagnostics: AudioDiagnostics,
    private val engine: AudioEngine,
    @ApplicationScope private val scope: CoroutineScope,
) {
    private val prefs = context.getSharedPreferences("jhankar_route", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(JhankarRouteState())
    val state: StateFlow<JhankarRouteState> = _state.asStateFlow()

    private var started = false
    private var lastKey: String? = null
    private var lastName = ""

    fun start() {
        if (started) return
        started = true
        diagnostics.startRouteTracking()
        scope.launch {
            engine.loaded.first { it }
            diagnostics.state.collect { path -> onPath(path) }
        }
    }

    fun rememberChoice(profile: OutputProfile) {
        val key = lastKey ?: return
        if (_state.value.kind == RouteKind.Bluetooth) prefs.edit().putString(key, profile.name).apply()
    }

    private fun onPath(path: AudioPathState) {
        val route = path.route
        val kind = route?.let { JhankarRoutes.kindOf(it.typeName) } ?: RouteKind.Speaker
        val name = route?.productName.orEmpty()
        val typeName = route?.typeName ?: "Built-in speaker"
        val key = "$kind:$name"
        val changed = key != lastKey
        val previous = _state.value
        var suggested = previous.suggested
        var event = previous.lastEvent
        if (changed) {
            val remembered = if (kind == RouteKind.Bluetooth) OutputProfile.entries.firstOrNull { it.name == prefs.getString(key, null) } else null
            suggested = remembered ?: JhankarRoutes.defaultProfileForDevice(kind, typeName, name)
            val label = name.ifEmpty { typeName }
            event = when {
                lastKey == null -> "Output: $label"
                kind == RouteKind.Speaker -> "Disconnected: ${lastName.ifEmpty { "external output" }}, back on phone speaker"
                suggested == OutputProfile.Tower -> "⚡ True-HD Tower DSP Triggered: $label"
                else -> "Connected: $label"
            }
            lastKey = key
            lastName = name.ifEmpty { typeName }
            engine.onOutputProfile(suggested)
            if (suggested == OutputProfile.Tower && engine.jhankarState.value.autoProfile) {
                engine.setJhankarEngine(true)
            }
        }
        _state.value = JhankarRouteState(
            connected = kind != RouteKind.Speaker,
            kind = kind,
            deviceName = name,
            typeName = typeName,
            exact = route?.exact ?: false,
            sampleRates = route?.sampleRates.orEmpty(),
            outputSampleRate = path.output?.sampleRate ?: 0,
            outputChannels = path.output?.channelCount ?: 0,
            suggested = suggested,
            lastEvent = event,
        )
    }
}
